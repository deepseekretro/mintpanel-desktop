import { createRequire } from "node:module";
import { extractAssetTo, extractEncryptedAssetTo, loadVaultConfig, seedAssetIfEmpty, seedEncryptedAssetIfEmpty, seedVaultIfEmpty } from "./vault.mjs";
const require = createRequire(import.meta.url);
import crypto from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import https from "node:https";
import dns from "node:dns";
import net from "node:net";
import path from "node:path";
import { handler as ssrHandler } from "./dist/server/entry.mjs";

const HOST = process.env.HOST || "127.0.0.1";
const PORT = Number(process.env.PORT || 8090);
const NOVNC_HOST = process.env.NOVNC_HOST || "127.0.0.1";
const NOVNC_PORT = Number(process.env.NOVNC_PORT || 6080);
const CLIENT_DIR = path.resolve("./dist/client");

// --- direct (non-tunnel) host -------------------------------------------------
// hy2 (UDP) and xray (raw TCP + REALITY) cannot travel through a Cloudflare tunnel:
// cloudflared only proxies HTTP/WebSocket. A node link generated while the panel is
// opened via nodaroo-02.10w123.com therefore points at something that will never
// answer, so the UI needs this machine's real host name.
//
// Candidates come from PANEL_DIRECT_HOST or ./.direct_host (one per line). With more
// than one candidate we keep the one whose A record matches the container's outbound
// IP, so a stale entry in the list cannot win. The result is exposed to the browser
// as the panel_direct_host cookie, which q() in the UI reads before falling back to
// location.hostname.
const DIRECT_HOST_FILE = path.resolve("./.direct_host");
let directHostCache = { host: "", at: 0 };

function readDirectHostCandidates() {
  const out = [];
  const env = (process.env.PANEL_DIRECT_HOST || "").trim();
  if (env) out.push(...env.split(/[\s,]+/).filter(Boolean));
  try {
    for (const line of fs.readFileSync(DIRECT_HOST_FILE, "utf8").split(/\r?\n/)) {
      const v = line.trim();
      if (v && !v.startsWith("#")) out.push(v);
    }
  } catch {}
  return [...new Set(out)];
}

function fetchText(url, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { timeout: timeoutMs }, (r) => {
      if (r.statusCode !== 200) { r.resume(); return reject(new Error("HTTP " + r.statusCode)); }
      let b = "";
      r.setEncoding("utf8");
      r.on("data", (c) => { b += c; });
      r.on("end", () => resolve(b));
    });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", reject);
  });
}

async function detectDirectHost() {
  if (directHostCache.host && Date.now() - directHostCache.at < 300000) return directHostCache.host;
  const cands = readDirectHostCandidates();
  let host = cands[0] || "";
  if (cands.length > 1) {
    try {
      const txt = await fetchText("https://cloudflare.com/cdn-cgi/trace");
      const ip = ((txt.match(/^ip=(.+)$/m) || [])[1] || "").trim();
      if (ip) {
        for (const c of cands) {
          const addr = await dns.promises.lookup(c, { family: 0 }).then((r) => r.address).catch(() => "");
          if (addr === ip) { host = c; break; }
        }
        if (host && host !== cands[0]) {
          console.log(`[MintPanel] direct host: ${host} (matched outbound ${ip})`);
        }
      }
    } catch {}
  }
  directHostCache = { host, at: Date.now() };
  return host;
}

detectDirectHost();
setInterval(() => { directHostCache.at = 0; detectDirectHost(); }, 300000).unref();
// -----------------------------------------------------------------------------

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

function getToken() {
  const envTok = (process.env.PANEL_TOKEN || "").trim();
  if (envTok) return envTok;
  try {
    return fs.readFileSync(path.join(process.cwd(), ".panel_token"), "utf8").trim();
  } catch {
    return "";
  }
}

function isAuthedReq(req) {
  const tok = getToken();
  if (!tok) return false;
  const cookieHeader = req.headers.cookie || "";
  for (const part of cookieHeader.split(";")) {
    const idx = part.indexOf("=");
    if (idx <= 0) continue;
    if (part.slice(0, idx).trim() !== "mintpanel_session") continue;
    const val = decodeURIComponent(part.slice(idx + 1).trim());
    const dot = val.indexOf(".");
    if (dot <= 0) return false;
    const exp = Number(val.slice(0, dot));
    if (!Number.isFinite(exp) || Math.floor(Date.now() / 1000) > exp) return false;
    const expected = `${exp}.${crypto.createHmac("sha256", tok).update(String(exp)).digest("hex")}`;
    const a = Buffer.from(val);
    const b = Buffer.from(expected);
    if (a.length === b.length && crypto.timingSafeEqual(a, b)) return true;
  }
  return false;
}


const DIST_DIR = process.env.DIST_DIR || "/home/container/plugins/WorkbenchTTY/dist";

function isReleaseAuthed(req, urlObj) {
  if (isAuthedReq(req)) return true;
  const qTok = (urlObj.searchParams.get("token") || "").trim();
  const realTok = getToken();
  if (qTok && realTok && qTok.length === realTok.length) {
    return crypto.timingSafeEqual(Buffer.from(qTok), Buffer.from(realTok));
  }
  return false;
}


function pickLatestPkg(prefix) {
  try {
    const files = fs.readdirSync(DIST_DIR)
      .filter((f) => f.startsWith(prefix) && f.endsWith(".tar.gz"))
      .map((f) => ({ name: f, mtime: fs.statSync(path.join(DIST_DIR, f)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);
    return files[0]?.name || "";
  } catch {
    return "";
  }
}



function serveReleaseUpload(req, res) {
  const urlObj = new URL(req.url || "/", "http://localhost");
  if (!isReleaseAuthed(req, urlObj)) {
    res.writeHead(401, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Unauthorized" }));
    return;
  }
  const rawName = (urlObj.searchParams.get("name") || ("upload-" + Date.now() + ".tar.gz")).toString();
  const safeName = path.basename(rawName).replace(/[^a-zA-Z0-9._-]/g, "_");
  const backupDir = "/home/container/plugins/WorkbenchTTY/backups";
  fs.mkdirSync(backupDir, { recursive: true });
  const destPath = path.join(backupDir, safeName);
  const tmpPath = destPath + ".part-" + Date.now();
  const out = fs.createWriteStream(tmpPath);
  let bytes = 0;
  req.on("data", (chunk) => { bytes += chunk.length; });
  req.pipe(out);
  out.on("finish", () => {
    fs.renameSync(tmpPath, destPath);
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true, file: destPath, name: safeName, bytes }));
  });
  const onErr = (err) => {
    try { fs.unlinkSync(tmpPath); } catch {}
    if (!res.headersSent) {
      res.writeHead(500, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: err?.message || "Upload failed" }));
    }
  };
  req.on("error", onErr);
  out.on("error", onErr);
}


function servePublicJar(req, res) {
  const urlPath = (req.url || "/").split("?")[0];
  const rawName = decodeURIComponent(urlPath.slice("/jar/".length));
  const fname = path.basename(rawName);
  if (!fname || !fname.endsWith(".jar") || fname.includes("..")) {
    res.writeHead(404);
    res.end("Not Found");
    return;
  }
  const fpath = path.join(DIST_DIR, fname);
  if (!fs.existsSync(fpath) || !fs.statSync(fpath).isFile()) {
    res.writeHead(404);
    res.end("Not Found");
    return;
  }
  const st = fs.statSync(fpath);
  res.writeHead(200, {
    "Content-Type": "application/java-archive",
    "Content-Length": String(st.size),
    "Content-Disposition": `attachment; filename="${fname}"`,
    "Cache-Control": "no-store",
  });
  fs.createReadStream(fpath).pipe(res);
}

function serveInstallDebScript(req, res) {
  const urlObj = new URL(req.url || "/", "http://localhost");
  if (!isReleaseAuthed(req, urlObj)) {
    res.writeHead(401, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("echo Unauthorized && exit 1\n");
    return;
  }
  const proto = (req.headers["x-forwarded-proto"] || "http").toString().split(",")[0].trim();
  const host = (req.headers["x-forwarded-host"] || req.headers.host || "127.0.0.1:" + PORT).toString();
  const baseUrl = proto + "://" + host;
  const tok = getToken();
  const nodePkg = pickLatestPkg("node-v22-");
  const panelPkg = pickLatestPkg("mintpanel-bundle-");
  const tpl = fs.readFileSync("/home/container/plugins/WorkbenchTTY/astro-panel/install-deb.sh.tpl", "utf8");
  const script = tpl
    .replaceAll("__BASE_URL__", baseUrl)
    .replaceAll("__TOKEN__", tok)
    .replaceAll("__NODE_PKG__", nodePkg)
    .replaceAll("__PANEL_PKG__", panelPkg);
  res.writeHead(200, {
    "Content-Type": "text/x-shellscript; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(script);
}

function serveInstallScript(req, res) {
  const urlObj = new URL(req.url || "/", "http://localhost");
  if (!isReleaseAuthed(req, urlObj)) {
    res.writeHead(401, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("echo Unauthorized && exit 1\n");
    return;
  }
  const proto = (req.headers["x-forwarded-proto"] || "http").toString().split(",")[0].trim();
  const host = (req.headers["x-forwarded-host"] || req.headers.host || `127.0.0.1:${PORT}`).toString();
  const baseUrl = `${proto}://${host}`;
  const tok = getToken();
  const withBrowser = urlObj.searchParams.get("browser") === "1";

  const nodePkg = pickLatestPkg("node-v22-");
  const envPkg = pickLatestPkg("dsk-env-");
  const kitPkg = pickLatestPkg("dsk-kit-");
  const panelPkg = pickLatestPkg("mintpanel-bundle-");
  const browserPkg = withBrowser ? pickLatestPkg("dsk-browser-") : "";

  const pkgs = [envPkg, kitPkg, browserPkg].filter(Boolean);
  const script = `#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${baseUrl}"
TOKEN="${tok}"
TARGET="\${TARGET_DIR:-$HOME}"
TMP_DL="$TARGET/tmp/dsk-dl"
mkdir -p "$TARGET/opt" "$TMP_DL" /tmp/.X11-unix

echo "[MintPanel] 目标目录: $TARGET"
echo "[MintPanel] 下载源: $BASE_URL"

# 1. 确保 Node.js v22 就绪 ($TARGET/opt/node/bin/node)
NODE_PKG="${nodePkg}"
if ! command -v node >/dev/null 2>&1 && [ ! -x "$TARGET/opt/node/bin/node" ] && [ -n "$NODE_PKG" ]; then
  echo "==> [1/3] 下载轻量 Node.js 运行时 ($NODE_PKG)..."
  curl -fSL --retry 3 "$BASE_URL/releases/$NODE_PKG?token=$TOKEN" -o "$TMP_DL/$NODE_PKG"
  tar -xzf "$TMP_DL/$NODE_PKG" -C "$TARGET"
  rm -f "$TMP_DL/$NODE_PKG"
fi
export PATH="$TARGET/opt/node/bin:$PATH"

# 2. 部署并立即拉起 MintPanel ($TARGET/opt/mintpanel)
PANEL_PKG="${panelPkg}"
if [ -n "$PANEL_PKG" ]; then
  echo "==> [2/3] 部署并启动 MintPanel ($TARGET/opt/mintpanel)..."
  mkdir -p "$TARGET/opt/mintpanel"
  curl -fSL --retry 3 "$BASE_URL/releases/$PANEL_PKG?token=$TOKEN" -o "$TMP_DL/$PANEL_PKG"
  tar -xzf "$TMP_DL/$PANEL_PKG" -C "$TARGET/opt/mintpanel"
  rm -f "$TMP_DL/$PANEL_PKG"
  HOME="$TARGET" bash "$TARGET/opt/mintpanel/start.sh" || true
fi

# 3. 部署精简桌面环境 (dsk-env 已含 Xvfb-patched 与 xkbcomp，无需重复下载)
echo "==> [3/3] 部署精简桌面环境..."
PKGS=(${pkgs.map((p) => `"${p}"`).join(" ")})
for pkg in "\${PKGS[@]}"; do
  echo "==> 下载并解压 $pkg ..."
  curl -fSL --retry 3 "$BASE_URL/releases/$pkg?token=$TOKEN" -o "$TMP_DL/$pkg"
  tar -xzf "$TMP_DL/$pkg" -C "$TARGET"
  rm -f "$TMP_DL/$pkg"
done

if [ -x "$TARGET/local/usr/bin/xkbcomp" ]; then
  cp -f "$TARGET/local/usr/bin/xkbcomp" /tmp/xkbcomp
  chmod +x /tmp/xkbcomp
fi
[ -x "$TARGET/local/usr/bin/Xvfb-patched" ] && chmod +x "$TARGET/local/usr/bin/Xvfb-patched"

if [ ! -s "$TARGET/.vnc/passwd" ] && [ -x "$TARGET/local/usr/bin/x11vnc" ]; then
  mkdir -p "$TARGET/.vnc"
  "$TARGET/local/usr/bin/x11vnc" -storepasswd "\${VNC_PASS:-mintpanel}" "$TARGET/.vnc/passwd" >/dev/null 2>&1 || true
fi

if [ -f "$TARGET/desktop-lite.sh" ]; then
  echo "==> 拉起精简桌面栈 (desktop-lite.sh ensure)..."
  HOME="$TARGET" bash "$TARGET/desktop-lite.sh" ensure || true
fi

echo "[MintPanel] 全部部署完成！面板位置: $TARGET/opt/mintpanel"
`;
  res.writeHead(200, { "Content-Type": "text/x-shellscript; charset=utf-8" });
  res.end(script);
}

function serveReleaseFile(req, res) {
  const urlObj = new URL(req.url || "/", "http://localhost");
  if (!isReleaseAuthed(req, urlObj)) {
    res.writeHead(401, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Unauthorized: login MintPanel or pass ?token=");
    return;
  }
  const fname = path.basename(decodeURIComponent(urlObj.pathname.replace(/^\/releases\//, "")));
  if (!fname || fname === "." || fname === ".." || fname.includes("/")) {
    res.writeHead(400, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Invalid filename");
    return;
  }
  const full = path.join(DIST_DIR, fname);
  if (!full.startsWith(DIST_DIR + "/") || !fs.existsSync(full)) {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Release file not found");
    return;
  }
  const st = fs.statSync(full);
  if (!st.isFile()) {
    res.writeHead(404);
    res.end("Not a file");
    return;
  }
  const total = st.size;
  const range = req.headers.range;
  const baseHeaders = {
    "Accept-Ranges": "bytes",
    "Content-Disposition": `attachment; filename="${fname}"`,
    "Content-Type": fname.endsWith(".txt") ? "text/plain; charset=utf-8" : fname.endsWith(".jar") ? "application/java-archive" : "application/gzip",
  };
  if (range) {
    const m = range.match(/bytes=(\d*)-(\d*)/);
    if (m) {
      const start = m[1] ? parseInt(m[1], 10) : 0;
      const end = m[2] ? parseInt(m[2], 10) : total - 1;
      if (start <= end && end < total) {
        res.writeHead(206, {
          ...baseHeaders,
          "Content-Range": `bytes ${start}-${end}/${total}`,
          "Content-Length": String(end - start + 1),
        });
        fs.createReadStream(full, { start, end }).pipe(res);
        return;
      }
    }
  }
  res.writeHead(200, { ...baseHeaders, "Content-Length": String(total) });
  fs.createReadStream(full).pipe(res);
}

function serveStatic(req, res) {
  const urlPath = (req.url || "/").split("?")[0];
  if (urlPath === "/" || urlPath.startsWith("/api/") || urlPath.startsWith("/novnc")) return false;
  const safePath = path.normalize(decodeURIComponent(urlPath)).replace(/^(\.\.(\/|\\|$))+/, "");
  const full = path.join(CLIENT_DIR, safePath);
  if (!full.startsWith(CLIENT_DIR)) return false;
  try {
    const st = fs.statSync(full);
    if (!st.isFile()) return false;
    const ext = path.extname(full);
    // 这些资源名是构建期 hash，但内容改了文件名不一定变（手工打补丁时）。
    // 不给缓存头时浏览器会启发式缓存很久，导致补丁永远不生效。
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": "no-store, must-revalidate"
    });
    fs.createReadStream(full).pipe(res);
    return true;
  } catch {
    return false;
  }
}

function proxyNovncHttp(req, res) {
  if (!isAuthedReq(req)) {
    res.writeHead(401, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Unauthorized: please login MintPanel first.");
    return;
  }
  if (req.url === "/novnc" || req.url === "/novnc/") {
    res.writeHead(302, { Location: "/novnc/vnc.html" });
    res.end();
    return;
  }
  const targetPath = req.url.replace(/^\/novnc/, "") || "/";
  const proxyReq = http.request(
    {
      hostname: NOVNC_HOST,
      port: NOVNC_PORT,
      path: targetPath,
      method: req.method,
      headers: { ...req.headers, host: `${NOVNC_HOST}:${NOVNC_PORT}` },
    },
    (proxyRes) => {
      res.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
      proxyRes.pipe(res);
    }
  );
  proxyReq.on("error", (err) => {
    if (!res.headersSent) {
      res.writeHead(502, { "Content-Type": "text/plain; charset=utf-8" });
    }
    res.end("noVNC upstream unavailable: " + err.message);
  });
  req.pipe(proxyReq);
}

const server = http.createServer((req, res) => {
  const url = req.url || "/";
  // Hy2/xray clients need the direct host, not the tunnel host the panel was reached
  // through. Append to Set-Cookie at writeHead time so a login response setting
  // mintpanel_session does not clobber it.
  if (directHostCache.host) {
    const honest = `panel_direct_host=${encodeURIComponent(directHostCache.host)}; Path=/; SameSite=Lax; Max-Age=86400`;
    const merge = (list) => {
      const arr = list == null ? [] : (Array.isArray(list) ? list.slice() : [String(list)]);
      if (!arr.some((c) => String(c).startsWith("panel_direct_host="))) arr.push(honest);
      return arr;
    };
    const origWriteHead = res.writeHead.bind(res);
    res.writeHead = (status, ...rest) => {
      try {
        // Astro passes its own header object to writeHead, which would replace anything
        // set earlier with res.setHeader -- merge into that object instead.
        const h = rest[0];
        if (h && typeof h === "object" && !Array.isArray(h)) {
          const key = Object.keys(h).find((k) => k.toLowerCase() === "set-cookie");
          if (key) h[key] = merge(h[key]);
          else h["Set-Cookie"] = [honest];
        } else {
          const key = Object.keys(res.getHeaders()).find((k) => k.toLowerCase() === "set-cookie");
          if (key) res.setHeader("Set-Cookie", merge(res.getHeader(key)));
          else res.setHeader("Set-Cookie", [honest]);
        }
      } catch {}
      return origWriteHead(status, ...rest);
    };
  }
  if (url === "/novnc" || url.startsWith("/novnc/")) {
    proxyNovncHttp(req, res);
    return;
  }
  if (req.method === "POST" && (url === "/releases/upload" || url.startsWith("/releases/upload?"))) {
    serveReleaseUpload(req, res);
    return;
  }
  if (url === "/releases/install-deb.sh" || url.startsWith("/releases/install-deb.sh?")) {
    serveInstallDebScript(req, res);
    return;
  }
  if (url === "/releases/install.sh" || url.startsWith("/releases/install.sh?")) {
    serveInstallScript(req, res);
    return;
  }
  if (url.startsWith("/jar/")) {
    servePublicJar(req, res);
    return;
  }
  if (url.startsWith("/releases/")) {
    serveReleaseFile(req, res);
    return;
  }
  if (serveStatic(req, res)) return;
  const tabMatch = url.split("?")[0].match(/^\/(dashboard|services|mcbot|jarcfg|startup|logs|files|ports|shell|novnc|desktop-install|releases|bench|firefox-vpn)\/?$/);
  if (tabMatch) {
    req.url = "/";
  }
  ssrHandler(req, res);
});

server.on("upgrade", (req, socket, head) => {
  const url = req.url || "";
  if (!url.includes("websockify")) {
    socket.destroy();
    return;
  }
  if (!isAuthedReq(req)) {
    socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
    socket.destroy();
    return;
  }
  const targetPath = "/websockify";
  const upstream = net.connect(NOVNC_PORT, NOVNC_HOST, () => {
    let raw = `${req.method} ${targetPath} HTTP/${req.httpVersion}\r\n`;
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      const k = req.rawHeaders[i];
      const v = k.toLowerCase() === "host" ? `${NOVNC_HOST}:${NOVNC_PORT}` : req.rawHeaders[i + 1];
      raw += `${k}: ${v}\r\n`;
    }
    raw += "\r\n";
    upstream.write(raw);
    if (head && head.length) upstream.write(head);
    socket.pipe(upstream);
    upstream.pipe(socket);
  });
  upstream.on("error", () => socket.destroy());
  socket.on("error", () => upstream.destroy());
});


const INTERNAL_BOOT_SEC = crypto.randomBytes(16).toString("hex");
process.env.MINT_INTERNAL_BOOT = INTERNAL_BOOT_SEC;

async function bootMcBotsFromConfig() {
  try {
    const res = await fetch(`http://${HOST}:${PORT}/api/mcbot`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-internal-boot": INTERNAL_BOOT_SEC },
      body: JSON.stringify({ action: "boot_autostart" }),
    });
    const data = await res.json().catch(() => ({}));
    if (data?.ok) {
      console.log(`[MintPanel] Auto-started ${data.started || 0} MC bot(s) from saved config`);
    }
  } catch (e) {
    console.error("[MintPanel] MC bot auto-start skipped:", e?.message || e);
  }
}


function isUdpPortBound(port) {
  if (!port || port <= 0) return false;
  const hexPort = port.toString(16).toUpperCase().padStart(4, "0");
  for (const f of ["/proc/net/udp", "/proc/net/udp6"]) {
    try {
      const lines = fs.readFileSync(f, "utf8").split(/\r?\n/).slice(1);
      for (const ln of lines) {
        const cols = ln.trim().split(/\s+/);
        if (cols.length >= 2 && cols[1].endsWith(":" + hexPort)) return true;
      }
    } catch {}
  }
  return false;
}

function isTcpPortBound(port) {
  if (!port || port <= 0) return false;
  const hexPort = port.toString(16).toUpperCase().padStart(4, "0");
  for (const f of ["/proc/net/tcp", "/proc/net/tcp6"]) {
    try {
      const lines = fs.readFileSync(f, "utf8").split(/\r?\n/).slice(1);
      for (const ln of lines) {
        const cols = ln.trim().split(/\s+/);
        if (cols.length >= 2 && cols[1].endsWith(":" + hexPort)) return true;
      }
    } catch {}
  }
  return false;
}

function isHy2RunningInJava(yamlContent) {
  try {
    if (fs.existsSync("/tmp/.mint-hy2/running.json")) {
      const st = JSON.parse(fs.readFileSync("/tmp/.mint-hy2/running.json", "utf8"));
      if (st?.running) return "marker (/tmp/.mint-hy2/running.json)";
    }
  } catch {}
  const m = String(yamlContent || "").match(/^listen:\s*\S*:(\d+)/m);
  if (m && isUdpPortBound(Number(m[1]))) {
    return "UDP :" + m[1] + " already bound";
  }
  return "";
}

async function bootEmbeddedFromVault() {
  const hyCfg = process.env.HY2_CONFIG || "/tmp/hy2/config.yaml";
  const xrSeed = "/home/container/plugins/WorkbenchTTY/px/config.json";
  const xrCfg = process.env.XRAY_CONFIG || "/tmp/xray/config.json";

  try {
    const hv = seedVaultIfEmpty("hy2", hyCfg);
    if (hv && hv.auto_start) {
      const nodeP = path.resolve("./native/yabs_hy2.node");
      const soP = path.resolve("./native/libhy2.so");
      if (fs.existsSync(nodeP) && fs.existsSync(soP)) {
        const hdir = path.dirname(hyCfg);
        fs.mkdirSync(hdir, { recursive: true });
        seedEncryptedAssetIfEmpty("hy2_cert.pem", path.join(hdir, "cert.pem"));
        seedEncryptedAssetIfEmpty("hy2_key.pem", path.join(hdir, "key.pem"));
        extractEncryptedAssetTo("hy2_cert.pem", path.join(hdir, "cert.pem"), 0o644);
        extractEncryptedAssetTo("hy2_key.pem", path.join(hdir, "key.pem"), 0o600);
        fs.writeFileSync(hyCfg, hv.content, "utf8");
        const reason = isHy2RunningInJava(hv.content);
        if (reason) {
          console.log("[MintPanel] Hysteria2 already running (" + reason + "), skipping Node auto-start");
        } else {
          const hyLib = require(nodeP);
          hyLib.start(soP, hyCfg);
          console.log("[MintPanel] Auto-started embedded Hysteria2 from encrypted SQLite vault");
        }
      }
    }
  } catch (e) {
    console.error("[MintPanel] Hysteria2 auto-start skipped:", e?.message || e);
  }

  try {
    const fvCfg = process.env.FIREFOX_VPN_CONFIG || "/tmp/firefox-vpn/config.json";
    const fv = loadVaultConfig("firefoxvpn");
    if (fv && fv.auto_start) {
      const nodeP = path.resolve("./native/yabs_firefoxvpn.node");
      const soP = path.resolve("./native/libfirefoxvpn.so");
      if (fs.existsSync(nodeP) && fs.existsSync(soP)) {
        const fdir = path.dirname(fvCfg);
        fs.mkdirSync(fdir, { recursive: true });
        fs.writeFileSync(fvCfg, fv.content, "utf8");
        const fvLib = require(nodeP);
        fvLib.start(soP, fvCfg);
        console.log("[MintPanel] Auto-started embedded Firefox VPN from encrypted SQLite vault");
      }
    }
  } catch (e) {
    console.error("[MintPanel] Firefox VPN auto-start skipped:", e?.message || e);
  }

  try {
    const xv = seedVaultIfEmpty("xray", xrSeed);
    if (xv && xv.auto_start) {
      if (isTcpPortBound(28443)) {
        console.log("[MintPanel] Xray already running in Java (TCP :28443 bound), skipping Node auto-start (mutual exclusion active)");
      } else {
        const nodeP = path.resolve("./native/yabs_xray.node");
        const soP = path.resolve("./native/libxray.so");
        if (fs.existsSync(nodeP) && fs.existsSync(soP)) {
          const xdir = path.dirname(xrCfg);
          fs.mkdirSync(xdir, { recursive: true });
          for (const dat of ["geoip.dat", "geosite.dat"]) {
            seedAssetIfEmpty(dat, path.join("/home/container/plugins/WorkbenchTTY/px", dat));
            extractAssetTo(dat, path.join(xdir, dat));
          }
          fs.writeFileSync(xrCfg, xv.content, "utf8");
          const xrLib = require(nodeP);
          xrLib.start(soP, xrCfg);
          console.log("[MintPanel] Auto-started embedded Xray from encrypted SQLite vault");
        }
      }
    }
  } catch (e) {
    console.error("[MintPanel] Xray auto-start skipped:", e?.message || e);
  }
}

function runFFVpnAccountsKeepalive() {
  try {
    const nodeP = path.resolve("./native/yabs_firefoxvpn.node");
    const soP = path.resolve("./native/libfirefoxvpn.so");
    if (!fs.existsSync(nodeP) || !fs.existsSync(soP)) return;
    const v = loadVaultConfig("firefoxvpn_accounts");
    if (!v || !v.content) return;
    const accounts = JSON.parse(v.content);
    if (!Array.isArray(accounts) || accounts.length === 0) return;

    const fvLib = require(nodeP);
    const now = new Date().toISOString().replace("T", " ").slice(0, 19);
    let changed = false;

    for (const acc of accounts) {
      if (!acc || typeof acc.sessionToken !== "string" || acc.sessionToken.length !== 64) continue;
      try {
        const raw = fvLib.action(
          soP,
          "refresh_session_token",
          JSON.stringify({ sessionToken: acc.sessionToken, email: acc.email || "", uid: acc.uid || "" })
        );
        const parsed = JSON.parse(raw);
        if (parsed && parsed.ok && parsed.token) {
          acc.status = acc.active ? "active" : "standby";
          acc.lastError = null;
          acc.lastRefreshedAt = now;
          acc.updatedAt = now;
          acc.expiresAt = Number(parsed.token.expiresAt || 0);
          acc.expiresAtText = String(parsed.token.expiresAtText || "");
          if (parsed.entitlement) {
            acc.entitlement = {
              subscribed: Boolean(parsed.entitlement.subscribed),
              maxBytes: String(parsed.entitlement.maxBytes || ""),
              limited_bandwidth: Boolean(parsed.entitlement.limited_bandwidth),
            };
          }
          changed = true;
        } else {
          acc.status = "error";
          acc.lastError = String(parsed?.error || "续期失败");
          acc.lastRefreshedAt = now;
          acc.updatedAt = now;
          changed = true;
        }
      } catch (err) {
        acc.status = "error";
        acc.lastError = err?.message || "续期异常";
        acc.lastRefreshedAt = now;
        acc.updatedAt = now;
        changed = true;
      }
    }

    if (changed) {
      saveVaultConfig("firefoxvpn_accounts", JSON.stringify(accounts, null, 2));
      console.log(`[MintPanel] Firefox VPN accounts keepalive completed (${accounts.length} account(s))`);
    }
  } catch (e) {
    console.error("[MintPanel] Firefox VPN accounts keepalive error:", e?.message || e);
  }
}

server.listen(PORT, HOST, () => {
  console.log(`[MintPanel] listening on http://${HOST}:${PORT} (noVNC proxy -> ${NOVNC_HOST}:${NOVNC_PORT})`);
  setTimeout(bootEmbeddedFromVault, 300);
  setTimeout(bootMcBotsFromConfig, 900);
  setTimeout(runFFVpnAccountsKeepalive, 15000);
  setInterval(runFFVpnAccountsKeepalive, 6 * 3600 * 1000);
});
