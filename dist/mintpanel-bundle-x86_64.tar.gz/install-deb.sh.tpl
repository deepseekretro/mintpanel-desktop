#!/usr/bin/env bash
set -euo pipefail

BASE_URL="__BASE_URL__"
TOKEN="__TOKEN__"
TARGET="${MINTPANEL_DIR:-$HOME}"
PANEL_PORT="${MINTPANEL_PORT:-8090}"
VNC_PORT="${VNC_PORT:-5900}"
NOVNC_PORT="${NOVNC_PORT:-6080}"
DISPLAY_NUM="${DISPLAY_NUM:-99}"

OPT_DIR="$TARGET/opt"
OPT_NODE="$OPT_DIR/node"
OPT_PANEL="$OPT_DIR/mintpanel"
OPT_DSK="$OPT_DIR/desktop"
STAGE="$TARGET/.mintpanel-deb-stage-$"

cleanup() {
  rm -rf "$STAGE"
}
trap cleanup EXIT

echo "=================================================="
echo " MintPanel + Online .deb /opt Flattened Deployer"
echo " Target : $OPT_DIR"
echo " Source : $BASE_URL"
echo "=================================================="

command -v curl >/dev/null || { echo "[ERR] curl is required"; exit 1; }
command -v apt-get >/dev/null || { echo "[ERR] apt-get is required"; exit 1; }
command -v dpkg-deb >/dev/null || { echo "[ERR] dpkg-deb is required"; exit 1; }

mkdir -p "$OPT_NODE" "$OPT_PANEL" "$OPT_DSK/bin" "$OPT_DSK/lib" "$OPT_DSK/share" "$OPT_DSK/etc" "$STAGE/debs" "$STAGE/root"

OPT_CF="$OPT_DIR/cloudflared"

INSTALL_BROWSER="${INSTALL_BROWSER:-}"
if [ -z "$INSTALL_BROWSER" ]; then
  if [ -r /dev/tty ]; then
    printf "是否安装 Camoufox 浏览器及默认扩展 (uBlock Origin + Cookie-Editor)? [Y/n]: " >/dev/tty
    read -r INSTALL_BROWSER </dev/tty || INSTALL_BROWSER="y"
  else
    INSTALL_BROWSER="y"
  fi
fi
case "$INSTALL_BROWSER" in
  [nN]|[nN][oO]|0) INSTALL_BROWSER="0" ;;
  *) INSTALL_BROWSER="1" ;;
esac

# ------------------------------------------------------------------
# Stop existing MintPanel / Desktop / cloudflared / Camoufox processes before overwrite
# ------------------------------------------------------------------
echo "[0/7] 停止已有相关进程准备覆盖安装..."
if [ -f "$OPT_PANEL/.panel.pid" ]; then
  OLD_PANEL_PID=$(cat "$OPT_PANEL/.panel.pid" 2>/dev/null || true)
  [ -n "$OLD_PANEL_PID" ] && kill "$OLD_PANEL_PID" 2>/dev/null || true
  rm -f "$OPT_PANEL/.panel.pid"
fi
for pidf in "$OPT_DSK"/logs/*.pid; do
  [ -f "$pidf" ] || continue
  OLD_DSK_PID=$(cat "$pidf" 2>/dev/null || true)
  [ -n "$OLD_DSK_PID" ] && kill "$OLD_DSK_PID" 2>/dev/null || true
  rm -f "$pidf"
done
pkill -f "cloudflared.*127\.0\.0\.1:$PANEL_PORT" 2>/dev/null || true
if [ "$INSTALL_BROWSER" = "1" ]; then
  pkill -9 -f "camoufox/fly-supervise\.py" 2>/dev/null || true
  pkill -9 -f "camoufox/cf-ui\.mjs" 2>/dev/null || true
  pkill -9 -f "camoufox-bin" 2>/dev/null || true
fi
sleep 1

# ------------------------------------------------------------------
# Step 1: Deploy Node.js & MintPanel into $TARGET/opt/{node,mintpanel}
# ------------------------------------------------------------------
echo "[1/7] Downloading & installing official Node.js v22 -> $OPT_NODE ..."
if [ ! -x "$OPT_NODE/bin/node" ]; then
  NODE_TAR=$(curl -fsSL "https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt" | awk '/linux-x64\.tar\.gz$/{print $2; exit}')
  [ -n "$NODE_TAR" ] || { echo "[ERR] Failed to resolve official Node.js v22 tarball"; exit 1; }
  echo "  -> Official: https://nodejs.org/dist/latest-v22.x/$NODE_TAR"
  curl -fsSL "https://nodejs.org/dist/latest-v22.x/$NODE_TAR" -o "$STAGE/node.tar.gz"
  tar -xzf "$STAGE/node.tar.gz" -C "$OPT_NODE" --strip-components=1
  if [ ! -x "$OPT_NODE/bin/node" ] && [ -d "$OPT_NODE/node/bin" ]; then
    mv "$OPT_NODE/node"/* "$OPT_NODE/"
    rmdir "$OPT_NODE/node" 2>/dev/null || true
  fi
  rm -f "$STAGE/node.tar.gz"
fi
NODE_BIN="$OPT_NODE/bin/node"
echo "  -> Node: $($NODE_BIN -v)"

echo "[2/7] Downloading & installing MintPanel -> $OPT_PANEL ..."
  curl -fsSL "$BASE_URL/releases/__PANEL_PKG__?token=$TOKEN" -o "$STAGE/panel.tar.gz"
  tar -xzf "$STAGE/panel.tar.gz" -C "$OPT_PANEL"
  rm -f "$STAGE/panel.tar.gz"

cat > "$OPT_PANEL/start.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
cd "$OPT_PANEL"
if [ -f "$OPT_PANEL/.panel.pid" ]; then
  OLD_PID=\$(cat "$OPT_PANEL/.panel.pid" 2>/dev/null || true)
  if [ -n "\$OLD_PID" ] && kill -0 "\$OLD_PID" 2>/dev/null; then
    kill "\$OLD_PID" 2>/dev/null || true
    sleep 1
  fi
fi
export PORT="\${PORT:-$PANEL_PORT}"
export HOST="\${HOST:-127.0.0.1}"
export WORKBENCH_DIR="\${WORKBENCH_DIR:-$OPT_PANEL}"
nohup "$OPT_NODE/bin/node" "$OPT_PANEL/server.mjs" >> "$OPT_PANEL/panel.log" 2>&1 &
echo \$! > "$OPT_PANEL/.panel.pid"
echo "[MintPanel] started PID \$(cat "$OPT_PANEL/.panel.pid") on \$HOST:\$PORT"
EOF
chmod +x "$OPT_PANEL/start.sh"

# Seed random Hysteria2 + Xray into encrypted SQLite vault (.panel_vault.db) if missing
echo "  -> Seeding random Hysteria2 & Xray into encrypted SQLite vault..."
(
  cd "$OPT_PANEL"
  if [ ! -s "$OPT_PANEL/.panel_token" ]; then
    "$NODE_BIN" -e 'console.log(require("node:crypto").randomBytes(16).toString("hex"))' > "$OPT_PANEL/.panel_token"
    chmod 600 "$OPT_PANEL/.panel_token"
  fi
  "$NODE_BIN" --experimental-sqlite --input-type=module <<'SEEDEOF'
import crypto from "node:crypto";
import fs from "node:fs";
import { execFileSync } from "node:child_process";
import { loadVaultConfig, saveVaultConfig, seedEncryptedAssetIfEmpty } from "./vault.mjs";

if (!loadVaultConfig("hy2")) {
  const tmp = "/tmp/.hy2-seed-" + process.pid;
  fs.mkdirSync(tmp, { recursive: true });
  execFileSync("openssl", ["req", "-x509", "-newkey", "rsa:2048", "-keyout", tmp + "/key.pem", "-out", tmp + "/cert.pem", "-days", "3650", "-nodes", "-subj", "/CN=bing.com"], { stdio: "ignore" });
  seedEncryptedAssetIfEmpty("hy2_cert.pem", tmp + "/cert.pem");
  seedEncryptedAssetIfEmpty("hy2_key.pem", tmp + "/key.pem");
  fs.rmSync(tmp, { recursive: true, force: true });
  const hyPort = 20000 + crypto.randomInt(25000);
  const hyPass = crypto.randomBytes(18).toString("base64url");
  const hyYaml = [
    "listen: :" + hyPort,
    "tls:",
    "  cert: /tmp/hy2/cert.pem",
    "  key: /tmp/hy2/key.pem",
    "auth:",
    "  type: password",
    "  password: " + hyPass,
    "masquerade:",
    "  type: proxy",
    "  proxy:",
    "    url: https://bing.com/",
    "    rewriteHost: true"
  ].join("\n") + "\n";
  saveVaultConfig("hy2", hyYaml, true);
  console.log("  -> Seeded random Hysteria2 on UDP :" + hyPort);
}

if (!loadVaultConfig("xray")) {
  const { privateKey } = crypto.generateKeyPairSync("x25519");
  const pkcs8 = privateKey.export({ format: "der", type: "pkcs8" });
  const privB64 = pkcs8.subarray(pkcs8.length - 32).toString("base64url");
  const xrPort = 20000 + crypto.randomInt(25000);
  const uuid = crypto.randomUUID();
  const shortId = crypto.randomBytes(4).toString("hex");
  const xrJson = {
    log: { loglevel: "warning" },
    inbounds: [{
      listen: "0.0.0.0",
      port: xrPort,
      protocol: "vless",
      settings: {
        clients: [{ id: uuid, flow: "xtls-rprx-vision" }],
        decryption: "none"
      },
      streamSettings: {
        network: "tcp",
        security: "reality",
        realitySettings: {
          show: false,
          dest: "www.microsoft.com:443",
          xver: 0,
          serverNames: ["www.microsoft.com"],
          privateKey: privB64,
          shortIds: [shortId]
        }
      }
    }],
    outbounds: [{ protocol: "freedom", tag: "direct" }]
  };
  saveVaultConfig("xray", JSON.stringify(xrJson, null, 2), true);
  console.log("  -> Seeded random Xray VLESS+REALITY on TCP :" + xrPort);
}
SEEDEOF
)

"$OPT_PANEL/start.sh"

# ------------------------------------------------------------------
# Step 3: Online fetch .deb packages via apt-get --print-uris
# ------------------------------------------------------------------
echo "[3/7] Resolving & downloading .deb packages online..."
APT_PKGS="xvfb x11-xkb-utils xkb-data x11vnc openbox tint2 patchelf xterm x11-utils novnc python3-websockify fonts-dejavu-core fonts-wqy-microhei libasound2t64 wmctrl unzip"
APT_OPTS=(-y --no-install-recommends)

URIS=$(apt-get --print-uris "${APT_OPTS[@]}" install $APT_PKGS 2>/dev/null | awk "/^'http/{gsub(/'/,\"\",\$1); print \$1}" || true)
if [ -z "$URIS" ]; then
  echo "  -> System apt lists empty or unavailable, updating into $STAGE/apt-state ..."
  mkdir -p "$STAGE/apt-state/lists/partial" "$STAGE/apt-state/cache/archives/partial"
  APT_STATE_OPTS=(
    -o Dir::State::lists="$STAGE/apt-state/lists"
    -o Dir::Cache::archives="$STAGE/apt-state/cache/archives"
    -o Dir::State::status=/dev/null
    -o Acquire::AllowInsecureRepositories=true
  )
  apt-get "${APT_STATE_OPTS[@]}" update >/dev/null 2>&1 || true
  URIS=$(apt-get --print-uris "${APT_OPTS[@]}" "${APT_STATE_OPTS[@]}" install $APT_PKGS 2>/dev/null | awk "/^'http/{gsub(/'/,\"\",\$1); print \$1}" || true)
fi

if [ -z "$URIS" ]; then
  echo "[ERR] Failed to resolve .deb URIs via apt-get"
  exit 1
fi

URI_COUNT=$(printf "%s\n" "$URIS" | wc -l)
echo "  -> Downloading $URI_COUNT .deb packages (8 parallel)..."
printf "%s\n" "$URIS" | xargs -P 8 -I{} sh -c '
  u="$1"
  f="$2/$(basename "$u")"
  curl -fsSL --retry 2 "$u" -o "$f"
' _ {} "$STAGE/debs"

echo "[4/7] Extracting & flattening into $OPT_DSK (zero usr/bin)..."
if [ -f "$OPT_DSK/logs/xvfb.pid" ] && kill -0 "\$(cat "$OPT_DSK/logs/xvfb.pid" 2>/dev/null)" 2>/dev/null; then
  exit 0
fi

for pidf in "$OPT_DSK"/logs/*.pid; do
  [ -f "$pidf" ] || continue
  old=$(cat "$pidf" 2>/dev/null || true)
  [ -n "$old" ] && kill "$old" 2>/dev/null || true
done
sleep 0.5
for deb in "$STAGE/debs"/*.deb; do
  dpkg-deb -x "$deb" "$STAGE/root"
done

# Flatten binaries -> $OPT_DSK/bin
for d in "$STAGE/root/usr/bin" "$STAGE/root/bin" "$STAGE/root/usr/sbin" "$STAGE/root/sbin"; do
  [ -d "$d" ] && cp -a "$d"/. "$OPT_DSK/bin/"
done

# Flatten shared libraries & plugin subdirs -> $OPT_DSK/lib
for d in "$STAGE/root/usr/lib/x86_64-linux-gnu" "$STAGE/root/lib/x86_64-linux-gnu" "$STAGE/root/usr/lib" "$STAGE/root/lib"; do
  if [ -d "$d" ]; then
    for item in "$d"/*; do
      [ -e "$item" ] || [ -L "$item" ] || continue
      base=$(basename "$item")
      case "$base" in
        x86_64-linux-gnu|pkgconfig|systemd|udev|tmpfiles.d|sysusers.d|mime) continue ;;
        *) cp -a "$item" "$OPT_DSK/lib/" ;;
      esac
    done
  fi
done

# Flatten share & etc -> $OPT_DSK/{share,etc}
[ -d "$STAGE/root/usr/share" ] && cp -a "$STAGE/root/usr/share"/. "$OPT_DSK/share/"
[ -d "$STAGE/root/etc" ] && cp -a "$STAGE/root/etc"/. "$OPT_DSK/etc/"

# Patch RPATH on all binaries & libs using extracted patchelf so no LD_LIBRARY_PATH is needed
PATCHELF="$OPT_DSK/bin/patchelf"
if [ -x "$PATCHELF" ]; then
  echo "  -> Patching ELF RPATH -> $OPT_DSK/lib ..."
  for f in "$OPT_DSK/bin"/*; do
    [ -f "$f" ] && [ ! -L "$f" ] || continue
    LD_LIBRARY_PATH="$OPT_DSK/lib" "$PATCHELF" --set-rpath "$OPT_DSK/lib" --force-rpath "$f" >/dev/null 2>&1 || true
  done
  for f in "$OPT_DSK/lib"/*.so*; do
    [ -f "$f" ] && [ ! -L "$f" ] || continue
    case "$(basename "$f")" in
      libc.so*|libpthread.so*|libdl.so*|libm.so*|librt.so*|ld-linux*) continue ;;
    esac
    LD_LIBRARY_PATH="$OPT_DSK/lib" "$PATCHELF" --set-rpath "$OPT_DSK/lib" --force-rpath "$f" >/dev/null 2>&1 || true
  done
  for sub in "$OPT_DSK/lib/xorg/modules" "$OPT_DSK/lib/dri"; do
    if [ -d "$sub" ]; then
      find "$sub" -type f -name "*.so*" -exec env LD_LIBRARY_PATH="$OPT_DSK/lib" "$PATCHELF" --set-rpath "$OPT_DSK/lib" --force-rpath {} \; >/dev/null 2>&1 || true
    fi
  done
fi

# Patch Xvfb hardcoded /usr/bin -> /tmp\0\0\0\0 using Node.js and place xkbcomp in /tmp/xkbcomp
if [ -x "$OPT_DSK/bin/Xvfb" ] && [ -x "$OPT_DSK/bin/xkbcomp" ]; then
  echo "  -> Patching Xvfb -> Xvfb-patched + /tmp/xkbcomp ..."
  "$NODE_BIN" -e '
    const fs = require("fs");
    let buf = fs.readFileSync(process.argv[1]);
    const needle = Buffer.from("/usr/bin");
    const repl = Buffer.from("/tmp\0\0\0\0");
    let idx = 0, count = 0;
    while ((idx = buf.indexOf(needle, idx)) !== -1) {
      repl.copy(buf, idx);
      idx += needle.length;
      count++;
    }
    fs.writeFileSync(process.argv[2], buf, { mode: 0o755 });
    console.log("  -> Patched", count, "occurrences in Xvfb-patched");
  ' "$OPT_DSK/bin/Xvfb" "$OPT_DSK/bin/Xvfb-patched"
  cp -a "$OPT_DSK/bin/xkbcomp" /tmp/xkbcomp
  chmod +x /tmp/xkbcomp
  if [ -x "$PATCHELF" ]; then
    LD_LIBRARY_PATH="$OPT_DSK/lib" "$PATCHELF" --set-rpath "$OPT_DSK/lib" --force-rpath /tmp/xkbcomp >/dev/null 2>&1 || true
  fi
fi

# ------------------------------------------------------------------
# Step 5: Write desktop launcher & start desktop stack
# ------------------------------------------------------------------
echo "[5/7] Writing $OPT_DSK/start-desktop.sh & starting desktop..."
PY_BIN=""
for cand in "$(command -v python3 2>/dev/null || true)" "$TARGET/python/bin/python3" "/usr/bin/python3"; do
  if [ -n "$cand" ] && [ -x "$cand" ]; then
    PY_BIN="$cand"
    break
  fi
done


mkdir -p "$OPT_DSK/etc/xdg/openbox"
mkdir -p "$TARGET/.config/openbox"
cat > "$OPT_DSK/etc/xdg/openbox/menu.xml" <<OBMENU
<?xml version="1.0" encoding="UTF-8"?>
<openbox_menu xmlns="http://openbox.org/3.4/menu">
<menu id="root-menu" label="Camoufox">
  <item label="关闭当前窗口">
    <action name="Execute"><execute>$OPT_DSK/bin/wmctrl -c :ACTIVE:</execute></action>
  </item>
  <menu id="client-list-combined-menu" label="所有窗口"/>
  <menu id="client-list-menu" label="本桌面的窗口"/>
  <separator/>
  <item label="Camoufox 159">
    <action name="Execute"><execute>$TARGET/camoufox/start-ui.sh</execute></action>
  </item>
  <item label="排列两窗口（左右并排）">
    <action name="Execute"><execute>$TARGET/camoufox/arrange-windows.sh</execute></action>
  </item>
  <item label="终端 (xterm)">
    <action name="Execute"><execute>$OPT_DSK/bin/xterm</execute></action>
  </item>
  <separator/>
  <item label="重载 openbox 配置">
    <action name="Reconfigure"/>
  </item>
</menu>
</openbox_menu>
OBMENU
cp -f "$OPT_DSK/etc/xdg/openbox/menu.xml" "$TARGET/.config/openbox/menu.xml"
cp -f "$OPT_DSK/etc/xdg/openbox/rc.xml" "$TARGET/.config/openbox/rc.xml"

cat > "$OPT_DSK/etc/xdg/openbox/rc.xml" <<OBRC
<?xml version="1.0" encoding="UTF-8"?>
<openbox_config xmlns="http://openbox.org/3.4/rc">
  <resistance><strength>10</strength><screen_edge_strength>20</screen_edge_strength></resistance>
  <focus><focusNew>yes</focusNew><followMouse>no</followMouse><focusLast>yes</focusLast><underMouse>no</underMouse></focus>
  <placement><policy>Smart</policy><center>yes</center></placement>
  <theme><name>Clearlooks</name><titleLayout>NLIMC</titleLayout><keepBorder>yes</keepBorder><animateIconify>yes</animateIconify></theme>
  <menu><file>$OPT_DSK/etc/xdg/openbox/menu.xml</file><hideDelay>200</hideDelay><middle>no</middle><submenuShowDelay>100</submenuShowDelay></menu>
  <mouse>
    <dragThreshold>8</dragThreshold><doubleClickTime>200</doubleClickTime>
    <context name="Root">
      <mousebind button="Right" action="Press"><action name="ShowMenu"><menu>root-menu</menu></action></mousebind>
      <mousebind button="Middle" action="Press"><action name="ShowMenu"><menu>client-list-combined-menu</menu></action></mousebind>
    </context>
    <context name="Titlebar">
      <mousebind button="Left" action="Drag"><action name="Move"/></mousebind>
      <mousebind button="Left" action="DoubleClick"><action name="ToggleMaximize"/></mousebind>
      <mousebind button="Right" action="Press"><action name="ShowMenu"><menu>client-menu</menu></action></mousebind>
    </context>
    <context name="Close"><mousebind button="Left" action="Press"><action name="Close"/></mousebind></context>
    <context name="Iconify"><mousebind button="Left" action="Press"><action name="Iconify"/></mousebind></context>
    <context name="Maximize"><mousebind button="Left" action="Press"><action name="ToggleMaximize"/></mousebind></context>
  </mouse>
  <keyboard><chainQuitKey>C-g</chainQuitKey><keybind key="A-F4"><action name="Close"/></keybind><keybind key="F1"><action name="ShowMenu"><menu>root-menu</menu></action></keybind></keyboard>
  <applications/>
</openbox_config>
OBRC


mkdir -p "$OPT_DSK/etc/fonts"
cat > "$OPT_DSK/etc/fonts/fonts.conf" <<FCCONF
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <dir>$OPT_DSK/share/fonts</dir>
  <dir>$TARGET/.fonts</dir>
  <dir>/usr/share/fonts</dir>
  <cachedir>/tmp/fontconfig-cache</cachedir>
  <include ignore_missing="yes">$OPT_DSK/etc/fonts/conf.d</include>
  <alias><family>sans-serif</family><prefer><family>Noto Sans SC</family><family>Arimo</family><family>WenQuanYi Micro Hei</family><family>DejaVu Sans</family></prefer></alias>
  <alias><family>sans</family><prefer><family>Noto Sans SC</family><family>Arimo</family><family>WenQuanYi Micro Hei</family><family>DejaVu Sans</family></prefer></alias>
  <alias><family>system-ui</family><prefer><family>Noto Sans SC</family><family>Arimo</family><family>WenQuanYi Micro Hei</family><family>DejaVu Sans</family></prefer></alias>
  <alias><family>monospace</family><prefer><family>Cousine</family><family>WenQuanYi Micro Hei Mono</family><family>DejaVu Sans Mono</family></prefer></alias>
</fontconfig>
FCCONF
FONTCONFIG_FILE="$OPT_DSK/etc/fonts/fonts.conf" fc-cache -f "$OPT_DSK/share/fonts" >/dev/null 2>&1 || true

mkdir -p "$OPT_DSK/etc/xdg/tint2" "$TARGET/.local/share/applications" "$TARGET/.config/tint2"
cat > "$TARGET/.local/share/applications/camoufox.desktop" <<DESKEOF
[Desktop Entry]
Type=Application
Name=Camoufox
Comment=Launch Camoufox Browser
Exec=$TARGET/camoufox/start-ui.sh
Icon=firefox
Terminal=false
Categories=Network;WebBrowser;
DESKEOF

cat > "$OPT_DSK/etc/xdg/tint2/tint2rc" <<TINT2RC
#---- Background ----
rounded = 0
border_width = 0
background_color = #1b1d21 92
border_color = #000000 0
panel_monitor = all
panel_position = bottom center horizontal
panel_size = 100% 30
panel_margin = 0 0
panel_padding = 6 2 6
panel_items = LTSC
panel_background_id = 1
wm_menu = 1

#---- Taskbar ----
taskbar_mode = single_desktop
taskbar_padding = 2 2 2
taskbar_background_id = 0
taskbar_name = 0
task_icon = 1
task_text = 1
task_width = 220
task_centered = 1

#---- Task ----
task_font = sans 9
task_font_color = #c8ccd2 100
task_active_font_color = #ffffff 100
task_background_id = 0

#---- Launcher ----
launcher_padding = 4 2 4
launcher_background_id = 0
launcher_icon_size = 18
launcher_item_app = $TARGET/.local/share/applications/camoufox.desktop

#---- Clock ----
time1_format = %H:%M
time1_font = sans 9
clock_font_color = #c8ccd2 100
clock_padding = 8 2
clock_background_id = 0

#---- Separator ----
separator_style = empty

# Task mouse bindings
mouse_left = toggle_iconify
mouse_middle = close
mouse_right = none
TINT2RC
cp -f "$OPT_DSK/etc/xdg/tint2/tint2rc" "$TARGET/.config/tint2/tint2rc"

cat > "$OPT_DSK/start-desktop.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
OPT_DSK="$OPT_DSK"
export PATH="$OPT_DSK/bin:\$PATH"
export LD_LIBRARY_PATH="$OPT_DSK/lib\${LD_LIBRARY_PATH:+:\$LD_LIBRARY_PATH}"
export XDG_DATA_DIRS="$TARGET/.local/share:$OPT_DSK/share:/usr/local/share:/usr/share"
export XDG_CONFIG_HOME="$OPT_DSK/etc/xdg"
export FONTCONFIG_PATH="$OPT_DSK/etc/fonts"
export FONTCONFIG_FILE="$OPT_DSK/etc/fonts/fonts.conf"
export DISPLAY=":$DISPLAY_NUM"

mkdir -p /tmp/.X11-unix "$OPT_DSK/logs"
[ -x "$OPT_DSK/bin/xkbcomp" ] && cp -af "$OPT_DSK/bin/xkbcomp" /tmp/xkbcomp

for pidf in "$OPT_DSK"/logs/*.pid; do
  [ -f "\$pidf" ] || continue
  old=\$(cat "\$pidf" 2>/dev/null || true)
  [ -n "\$old" ] && kill "\$old" 2>/dev/null || true
done
sleep 0.5

XVFB_BIN="$OPT_DSK/bin/Xvfb-patched"
[ -x "\$XVFB_BIN" ] || XVFB_BIN="$OPT_DSK/bin/Xvfb"
"\$XVFB_BIN" ":$DISPLAY_NUM" -screen 0 1920x1080x24 -ac -nolisten tcp -xkbdir "$OPT_DSK/share/X11/xkb" > "$OPT_DSK/logs/xvfb.log" 2>&1 &
echo \$! > "$OPT_DSK/logs/xvfb.pid"
sleep 1.5

OB_CFG_ARG=""
[ -f "$OPT_DSK/etc/xdg/openbox/rc.xml" ] && OB_CFG_ARG="--config-file $OPT_DSK/etc/xdg/openbox/rc.xml"
"$OPT_DSK/bin/openbox" \$OB_CFG_ARG > "$OPT_DSK/logs/openbox.log" 2>&1 &
echo \$! > "$OPT_DSK/logs/openbox.pid"

"$OPT_DSK/bin/x11vnc" -display ":$DISPLAY_NUM" -forever -shared -nopw -rfbport "$VNC_PORT" -listen 127.0.0.1 > "$OPT_DSK/logs/x11vnc.log" 2>&1 &
echo \$! > "$OPT_DSK/logs/x11vnc.pid"

if [ -n "$PY_BIN" ] && [ -d "$OPT_DSK/lib/python3/dist-packages/websockify" ]; then
  PYTHONPATH="$OPT_DSK/lib/python3/dist-packages" "$PY_BIN" -m websockify --web "$OPT_DSK/share/novnc" "127.0.0.1:$NOVNC_PORT" "127.0.0.1:$VNC_PORT" > "$OPT_DSK/logs/websockify.log" 2>&1 &
  echo \$! > "$OPT_DSK/logs/websockify.pid"
fi

echo "[Desktop] Started on DISPLAY=:$DISPLAY_NUM, VNC=127.0.0.1:$VNC_PORT, noVNC=127.0.0.1:$NOVNC_PORT"
EOF
chmod +x "$OPT_DSK/start-desktop.sh"
"$OPT_DSK/start-desktop.sh"


# ------------------------------------------------------------------
# Step 6: Download cloudflared -> $OPT_DIR/cloudflared & start tunnel
# ------------------------------------------------------------------
OPT_CF="$OPT_DIR/cloudflared"
mkdir -p "$OPT_CF/bin"
echo "[6/7] Downloading cloudflared -> $OPT_CF/bin/cloudflared ..."
if [ ! -x "$OPT_CF/bin/cloudflared" ]; then
  curl -fsSL "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64" -o "$OPT_CF/bin/cloudflared"
  chmod +x "$OPT_CF/bin/cloudflared"
fi

pkill -f "cloudflared.*127\.0\.0\.1:$PANEL_PORT" 2>/dev/null || true
cat > "$OPT_PANEL/tunnel.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
cd "$OPT_PANEL"
if [ -f "$OPT_PANEL/.cf.pid" ]; then
  OLD_CF=\$(cat "$OPT_PANEL/.cf.pid" 2>/dev/null || true)
  if [ -n "\$OLD_CF" ] && kill -0 "\$OLD_CF" 2>/dev/null; then
    kill "\$OLD_CF" 2>/dev/null || true
    sleep 0.5
  fi
fi
rm -f "$OPT_PANEL/cf-panel.log"
nohup "$OPT_CF/bin/cloudflared" tunnel --no-autoupdate --url "http://127.0.0.1:$PANEL_PORT" </dev/null >"$OPT_PANEL/cf-panel.log" 2>&1 &
echo \$! > "$OPT_PANEL/.cf.pid"

URL=""
for i in \$(seq 1 25); do
  URL=\$(grep -oE "https://[a-zA-Z0-9.-]+\.trycloudflare\.com" "$OPT_PANEL/cf-panel.log" 2>/dev/null | head -n 1 || true)
  if [ -n "\$URL" ]; then
    break
  fi
  sleep 1
done

curl -fsS "http://127.0.0.1:$PANEL_PORT/" >/dev/null 2>&1 || true
TOK=\$(cat "$OPT_PANEL/.panel_token" 2>/dev/null || true)
echo "PANEL_URL=\$URL"
echo "PANEL_TOKEN=\$TOK"
EOF
chmod +x "$OPT_PANEL/tunnel.sh"
"$OPT_PANEL/tunnel.sh"


# ------------------------------------------------------------------
# Step 7: Preserve manually uploaded Java JAR + Optional Camoufox Browser (with 2 extensions)
# ------------------------------------------------------------------
echo "[7/7] 保留手动上传的 Java 插件（不覆盖 /home/container/plugins/*.jar）"

if [ "$INSTALL_BROWSER" = "1" ]; then
  echo "[browser] 正在从官方源安装 Camoufox + 默认双扩展 (AMO) + 自动化脚本..."
  mkdir -p "$TARGET/camoufox/profile-ui/extensions" "$TARGET/tmp" "$TARGET/.cache/camoufox"

  if [ ! -f "$TARGET/camoufox/package.json" ]; then
    cat > "$TARGET/camoufox/package.json" <<'PKGEOF'
{
  "name": "camoufox",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "camoufox-js": "^0.13.0"
  }
}
PKGEOF
  fi

  if [ ! -d "$TARGET/camoufox/node_modules/camoufox-js" ]; then
    echo "[browser] 安装 npm camoufox-js ..."
    (cd "$TARGET/camoufox" && PATH="$OPT_NODE/bin:$PATH" npm install --omit=dev --no-audit --no-fund)
  fi

  if [ ! -x "$TARGET/cf-new/camoufox-bin" ]; then
    echo "[browser] 从 GitHub 官方拉取 Camoufox v159.0-beta.42 -> $TARGET/cf-new ..."
    mkdir -p "$TARGET/cf-new"
    curl -fsSL -L "https://github.com/daijro/camoufox/releases/download/v159.0-beta.42/camoufox-159.0-beta.42-lin.x86_64.zip" -o "$TARGET/tmp/camoufox-159.zip"
    if command -v unzip >/dev/null 2>&1; then
      unzip -oq "$TARGET/tmp/camoufox-159.zip" -d "$TARGET/cf-new"
    else
      "$OPT_DSK/bin/unzip" -oq "$TARGET/tmp/camoufox-159.zip" -d "$TARGET/cf-new"
    fi
    chmod +x "$TARGET/cf-new/"{camoufox-bin,gfxtest,glxtest,vaapitest,pingsender,plugin-container} 2>/dev/null || true
    rm -f "$TARGET/tmp/camoufox-159.zip"
  fi

  mkdir -p "$TARGET/.fonts"
  echo "[browser] 下载 Camoufox 白名单字体 (Arimo / Cousine / Tinos / NotoSansSC)..."
  [ -s "$TARGET/.fonts/Arimo-Regular.ttf" ] || curl -fsSL "https://raw.githubusercontent.com/google/fonts/main/ofl/arimo/Arimo%5Bwght%5D.ttf" -o "$TARGET/.fonts/Arimo-Regular.ttf" || true
  [ -s "$TARGET/.fonts/Cousine-Regular.ttf" ] || curl -fsSL "https://raw.githubusercontent.com/google/fonts/main/ofl/cousine/Cousine-Regular.ttf" -o "$TARGET/.fonts/Cousine-Regular.ttf" || true
  [ -s "$TARGET/.fonts/Tinos-Regular.ttf" ] || curl -fsSL "https://raw.githubusercontent.com/google/fonts/main/ofl/tinos/Tinos-Regular.ttf" -o "$TARGET/.fonts/Tinos-Regular.ttf" || true
  [ -s "$TARGET/.fonts/NotoSansSC-VF.ttf" ] || curl -fsSL "https://raw.githubusercontent.com/google/fonts/main/ofl/notosanssc/NotoSansSC%5Bwght%5D.ttf" -o "$TARGET/.fonts/NotoSansSC-VF.ttf" || true
  FONTCONFIG_FILE="$OPT_DSK/etc/fonts/fonts.conf" fc-cache -f >/dev/null 2>&1 || true

  EXT_DIR="$TARGET/camoufox/profile-ui/extensions"
  echo "[browser] 从 Mozilla AMO 官方下载默认双扩展..."
  [ -s "$EXT_DIR/uBlock0@raymondhill.net.xpi" ] ||     curl -fsSL -L "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi" -o "$EXT_DIR/uBlock0@raymondhill.net.xpi"
  [ -s "$EXT_DIR/{c3c10168-4186-445c-9c5b-63f12b8e2c87}.xpi" ] ||     curl -fsSL -L "https://addons.mozilla.org/firefox/downloads/latest/cookie-editor/latest.xpi" -o "$EXT_DIR/{c3c10168-4186-445c-9c5b-63f12b8e2c87}.xpi"

  curl -fsSL "$BASE_URL/releases/cf-ui.mjs?token=$TOKEN" -o "$TARGET/camoufox/cf-ui.mjs"
  curl -fsSL "$BASE_URL/releases/fly-supervise.py?token=$TOKEN" -o "$TARGET/camoufox/fly-supervise.py"
  chmod +x "$TARGET/camoufox/fly-supervise.py"

  cat > "$TARGET/camoufox/start-ui.sh" <<UIEOF
#!/usr/bin/env bash
unset LD_LIBRARY_PATH LD_PRELOAD
set -uo pipefail
H="$TARGET"
LOG="\$H/camoufox/ui.log"
mkdir -p "\$H/tmp" "\$H/camoufox" "\$H/.cache/camoufox/addons" "\$H/.cache/camoufox/fontconfig"
[ -s "\$H/.cache/camoufox/version.json" ] || printf %s '{"version":"152.0.4","build":"beta.30","prerelease":true,"sha256":null,"created_at":null}' > "\$H/.cache/camoufox/version.json"
for b in "\$H/.cache/camoufox/" "\$H/.cache/camoufox/browsers/*/*/" "\$H/cf-new/"; do
  [ -d "\$b" ] || continue
  for conf in "\${b}fontconfig/lin" "\${b}fontconfig/linux64"; do
    mkdir -p "\$conf" 2>/dev/null || continue
    cat > "\$conf/fonts.conf" <<FEOF
<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>
  <dir>$OPT_DSK/share/fonts</dir>
  <dir>/usr/share/fonts</dir>
  <dir>\$H/.fonts</dir>
  <cachedir>\$H/.cache/fontconfig</cachedir>
  <include ignore_missing="yes">$OPT_DSK/etc/fonts/conf.d</include>
  <include ignore_missing="yes">/etc/fonts/conf.d</include>
  <alias><family>sans-serif</family><prefer><family>Noto Sans SC</family><family>Arimo</family><family>WenQuanYi Micro Hei</family><family>DejaVu Sans</family></prefer></alias>
  <alias><family>sans</family><prefer><family>Noto Sans SC</family><family>Arimo</family><family>WenQuanYi Micro Hei</family><family>DejaVu Sans</family></prefer></alias>
  <alias><family>system-ui</family><prefer><family>Noto Sans SC</family><family>Arimo</family><family>WenQuanYi Micro Hei</family><family>DejaVu Sans</family></prefer></alias>
  <alias><family>monospace</family><prefer><family>Cousine</family><family>WenQuanYi Micro Hei Mono</family><family>DejaVu Sans Mono</family></prefer></alias>
</fontconfig>
FEOF
  done
done
if pgrep -f "camoufox/cf-ui.mjs" >/dev/null 2>&1; then
  exit 0
fi
PY_BIN="\$(command -v python3 || echo "\$H/python/bin/python3")"
WRAP=""
[ -x "\$PY_BIN" ] && [ -f "\$H/camoufox/fly-supervise.py" ] && WRAP="\$PY_BIN \$H/camoufox/fly-supervise.py"
CF_BIN=""
[ -x "\$H/cf-new/camoufox-bin" ] && CF_BIN="\$H/cf-new/camoufox-bin"
setsid env DISPLAY=":\${DISPLAY_NUM:-$DISPLAY_NUM}" TMPDIR="\$H/tmp" TZ=Asia/Kolkata \
  LD_LIBRARY_PATH="$OPT_DSK/lib:\$H/gui/lib2" PATH="$OPT_NODE/bin:$OPT_DSK/bin:\$PATH" \
  AUTO="\${AUTO:-1}" \${CF_BIN:+CF_EXE="\$CF_BIN"} \
  CF_SECOND="\${CF_SECOND:-https://dash.pingless.org/afk}" \
  \$WRAP node --experimental-sqlite "\$H/camoufox/cf-ui.mjs" >>"\$LOG" 2>&1 </dev/null &
sleep 1
( sleep 10; DISPLAY=":\${DISPLAY_NUM:-$DISPLAY_NUM}" bash "\$H/camoufox/arrange-windows.sh" >>"\$LOG" 2>&1
  sleep 6; DISPLAY=":\${DISPLAY_NUM:-$DISPLAY_NUM}" bash "\$H/camoufox/arrange-windows.sh" >>"\$LOG" 2>&1 ) </dev/null &
echo "\$(date +%H:%M:%S) 菜单: 已提交启动" >>"\$LOG"
UIEOF
  cat > "$TARGET/camoufox/arrange-windows.sh" <<'ARGEOF'
#!/usr/bin/env bash
set -uo pipefail
H="${MINTPANEL_DIR:-$HOME}"
D="$H/opt/desktop"
unset LD_LIBRARY_PATH LD_PRELOAD
WM="$D/bin/wmctrl"
X="env DISPLAY=${DISPLAY:-:99} LD_LIBRARY_PATH=$D/lib:$H/gui/lib2"
[ -x "$WM" ] || exit 1
for i in $(seq 1 20); do
  n=$($X "$WM" -l 2>/dev/null | grep -c "Camoufox" || true)
  [ "$n" -ge 2 ] && break
  sleep 1
done
mapfile -t ids < <($X "$WM" -l 2>/dev/null | grep -i "camoufox" | awk '{print tolower($1)}' | sort)
main="${ids[0]:-}"
second="${ids[1]:-}"
[ -n "$second" ] && $X "$WM" -i -r "$second" -e 0,0,0,940,1020
[ -n "$main" ] && $X "$WM" -i -r "$main" -e 0,950,0,950,1020
ARGEOF
  chmod +x "$TARGET/camoufox/arrange-windows.sh"

  chmod +x "$TARGET/camoufox/start-ui.sh"

  if [ -s "$EXT_DIR/uBlock0@raymondhill.net.xpi" ] && [ -s "$EXT_DIR/{c3c10168-4186-445c-9c5b-63f12b8e2c87}.xpi" ]; then
    echo "  -> 默认双扩展已从官方就位: uBlock0@raymondhill.net.xpi + {c3c10168-4186-445c-9c5b-63f12b8e2c87}.xpi"
  else
    echo "  -> [WARN] 扩展目录缺少 .xpi 文件: $EXT_DIR"
  fi
  echo "[browser] 启动 Camoufox 自动化..."
  HOME="$TARGET" DISPLAY_NUM="$DISPLAY_NUM" bash "$TARGET/camoufox/start-ui.sh" || true
else
  echo "[browser] 已跳过 Camoufox 浏览器安装 (INSTALL_BROWSER=0)"
fi

# ------------------------------------------------------------------
# Auto-start hook (.bashrc + ensure.sh) matching local container setup
# ------------------------------------------------------------------
cat > "$OPT_PANEL/ensure.sh" <<ENSEOF
#!/usr/bin/env bash
set -e
DIR="\$(cd "\$(dirname "\$0")" && pwd)"
NEED_START=1
if [ -f "\$DIR/.panel.pid" ]; then
  PID=\$(cat "\$DIR/.panel.pid" 2>/dev/null || true)
  if [ -n "\$PID" ] && kill -0 "\$PID" 2>/dev/null; then
    NEED_START=0
  fi
fi
if [ "\$NEED_START" = "1" ]; then
  if [ -x "\$DIR/start.sh" ]; then
    "\$DIR/start.sh"
  else
    nohup env NODE_OPTIONS="--openssl-legacy-provider --experimental-sqlite" HOST=127.0.0.1 PORT=$PANEL_PORT "$OPT_NODE/bin/node" "\$DIR/server.mjs" </dev/null >"\$DIR/panel.log" 2>&1 &
    echo \$! > "\$DIR/.panel.pid"
  fi
fi
if ! pgrep -f "cloudflared.*127\.0\.0\.1:$PANEL_PORT" >/dev/null 2>&1; then
  nohup "$OPT_CF/bin/cloudflared" tunnel --no-autoupdate --url "http://127.0.0.1:$PANEL_PORT" </dev/null >"\$DIR/cf-panel.log" 2>&1 &
fi
ENSEOF
chmod +x "$OPT_PANEL/ensure.sh"

BASHRC_FILE="$TARGET/.bashrc"
touch "$BASHRC_FILE"
if ! grep -q "mintpanel-autostart" "$BASHRC_FILE" 2>/dev/null; then
  cat >> "$BASHRC_FILE" <<RC_EOF

# >>> mintpanel-autostart >>>
[ -x "$OPT_DSK/start-desktop.sh" ] && bash "$OPT_DSK/start-desktop.sh" >/dev/null 2>&1
[ -x "$OPT_PANEL/ensure.sh" ] && bash "$OPT_PANEL/ensure.sh" >/dev/null 2>&1
[ -x "$TARGET/camoufox/start-ui.sh" ] && bash "$TARGET/camoufox/start-ui.sh" >/dev/null 2>&1
# <<< mintpanel-autostart <<<
RC_EOF
fi

echo "=================================================="
echo " Deploy complete!"
echo "   $OPT_NODE"
echo "   $OPT_PANEL (port $PANEL_PORT)"
echo "   $OPT_DSK (bin / lib / share / etc)"
echo "   $OPT_CF/bin/cloudflared"
echo "   Java plugin: preserved (manual upload)"
echo "   Browser    : $( [ "$INSTALL_BROWSER" = "1" ] && echo "installed ($TARGET/cf-new + 2 extensions)" || echo "skipped" )"
echo "=================================================="
