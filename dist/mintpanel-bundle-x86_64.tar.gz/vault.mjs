import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const DB_PATH = path.resolve(process.cwd(), ".panel_vault.db");

let cachedKey = null;
let dbInst = null;

function getToken() {
  const envTok = (process.env.PANEL_TOKEN || "").trim();
  if (envTok) return envTok;
  const tf = path.join(process.cwd(), ".panel_token");
  try {
    if (fs.existsSync(tf)) return fs.readFileSync(tf, "utf8").trim();
  } catch {}
  return "mintpanel-default-fallback-key";
}

function getKey() {
  if (cachedKey) return cachedKey;
  cachedKey = crypto.scryptSync(getToken(), "mintpanel-vault-v1", 32);
  return cachedKey;
}

function getDb() {
  if (dbInst) return dbInst;
  const { DatabaseSync } = require("node:sqlite");
  dbInst = new DatabaseSync(DB_PATH);
  dbInst.exec(`
    CREATE TABLE IF NOT EXISTS configs (
      name TEXT PRIMARY KEY,
      iv TEXT NOT NULL,
      tag TEXT NOT NULL,
      ciphertext TEXT NOT NULL,
      auto_start INTEGER NOT NULL DEFAULT 1,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS assets (
      name TEXT PRIMARY KEY,
      data BLOB NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);
  return dbInst;
}

function encryptText(plain) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", getKey(), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    iv: iv.toString("hex"),
    tag: tag.toString("hex"),
    ciphertext: enc.toString("hex"),
  };
}

function decryptText(ivHex, tagHex, ctHex) {
  const decipher = crypto.createDecipheriv("aes-256-gcm", getKey(), Buffer.from(ivHex, "hex"));
  decipher.setAuthTag(Buffer.from(tagHex, "hex"));
  const dec = Buffer.concat([decipher.update(Buffer.from(ctHex, "hex")), decipher.final()]);
  return dec.toString("utf8");
}

export function loadVaultConfig(name) {
  try {
    const db = getDb();
    const row = db.prepare("SELECT iv, tag, ciphertext, auto_start, updated_at FROM configs WHERE name = ?").get(name);
    if (!row) return null;
    return {
      content: decryptText(row.iv, row.tag, row.ciphertext),
      auto_start: Boolean(row.auto_start),
      updated_at: row.updated_at,
    };
  } catch {
    return null;
  }
}

export function saveVaultConfig(name, content, autoStart) {
  const db = getDb();
  const existing = db.prepare("SELECT auto_start FROM configs WHERE name = ?").get(name);
  const autoVal = typeof autoStart === "boolean" ? (autoStart ? 1 : 0) : existing ? existing.auto_start : 1;
  const { iv, tag, ciphertext } = encryptText(content);
  const now = new Date().toISOString().replace("T", " ").slice(0, 19);
  db.prepare(`
    INSERT INTO configs (name, iv, tag, ciphertext, auto_start, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(name) DO UPDATE SET
      iv = excluded.iv,
      tag = excluded.tag,
      ciphertext = excluded.ciphertext,
      auto_start = excluded.auto_start,
      updated_at = excluded.updated_at
  `).run(name, iv, tag, ciphertext, autoVal, now);
  return { ok: true, auto_start: Boolean(autoVal), updated_at: now };
}

export function setVaultAutoStart(name, enabled) {
  const db = getDb();
  db.prepare("UPDATE configs SET auto_start = ? WHERE name = ?").run(enabled ? 1 : 0, name);
  return { ok: true, auto_start: enabled };
}

export function seedVaultIfEmpty(name, filePath) {
  const cur = loadVaultConfig(name);
  if (cur) return cur;
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, "utf8");
      if (content.trim()) {
        saveVaultConfig(name, content, true);
        return loadVaultConfig(name);
      }
    }
  } catch {}
  return null;
}

export function seedAssetIfEmpty(name, filePath) {
  const db = getDb();
  const row = db.prepare("SELECT length(data) AS sz FROM assets WHERE name = ?").get(name);
  if (row && row.sz > 0) return true;
  try {
    if (fs.existsSync(filePath)) {
      const buf = fs.readFileSync(filePath);
      const now = new Date().toISOString().replace("T", " ").slice(0, 19);
      db.prepare(`
        INSERT INTO assets (name, data, updated_at) VALUES (?, ?, ?)
        ON CONFLICT(name) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at
      `).run(name, buf, now);
      return true;
    }
  } catch {}
  return false;
}

export function extractAssetTo(name, destPath) {
  const db = getDb();
  const row = db.prepare("SELECT data FROM assets WHERE name = ?").get(name);
  if (!row || !row.data) return false;
  const buf = Buffer.from(row.data);
  try {
    const st = fs.lstatSync(destPath);
    if (st.isSymbolicLink()) fs.unlinkSync(destPath);
    else if (st.isFile() && st.size === buf.length) return true;
  } catch {}
  fs.mkdirSync(path.dirname(destPath), { recursive: true });
  fs.writeFileSync(destPath, buf);
  return true;
}

export function seedEncryptedAssetIfEmpty(name, filePath) {
  const db = getDb();
  const row = db.prepare("SELECT length(data) AS sz FROM assets WHERE name = ?").get(name);
  if (row && row.sz > 0) return true;
  try {
    if (fs.existsSync(filePath)) {
      const plain = fs.readFileSync(filePath, "utf8");
      const encObj = encryptText(plain);
      const now = new Date().toISOString().replace("T", " ").slice(0, 19);
      db.prepare(`
        INSERT INTO assets (name, data, updated_at) VALUES (?, ?, ?)
        ON CONFLICT(name) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at
      `).run(name, Buffer.from(JSON.stringify(encObj), "utf8"), now);
      return true;
    }
  } catch {}
  return false;
}

export function extractEncryptedAssetTo(name, destPath, mode = 0o600) {
  const db = getDb();
  const row = db.prepare("SELECT data FROM assets WHERE name = ?").get(name);
  if (!row || !row.data) return false;
  try {
    const { iv, tag, ciphertext } = JSON.parse(Buffer.from(row.data).toString("utf8"));
    const plain = decryptText(iv, tag, ciphertext);
    fs.mkdirSync(path.dirname(destPath), { recursive: true });
    fs.writeFileSync(destPath, plain, { mode });
    return true;
  } catch {
    return false;
  }
}
