#!/usr/bin/env bash
set -e
cd /home/container/plugins/WorkbenchTTY/astro-panel
for pid in $(pgrep -f "bin-cloudflared.*8090" || true); do
  if [ "$pid" != "$$" ] && [ "$pid" != "$PPID" ]; then
    kill "$pid" 2>/dev/null || true
  fi
done
sleep 0.4
rm -f cf-panel.log
nohup /home/container/plugins/WorkbenchTTY/bin-cloudflared tunnel --no-autoupdate --metrics 127.0.0.1:20242 --url http://127.0.0.1:8090 </dev/null >cf-panel.log 2>&1 &

URL=""
for i in $(seq 1 20); do
  URL=$(grep -oE "https://[a-zA-Z0-9.-]+\.trycloudflare\.com" cf-panel.log 2>/dev/null | head -n 1 || true)
  if [ -n "$URL" ]; then
    break
  fi
  sleep 1
done

echo "PANEL_URL=$URL"
echo "PANEL_TOKEN=$(cat .panel_token)"
