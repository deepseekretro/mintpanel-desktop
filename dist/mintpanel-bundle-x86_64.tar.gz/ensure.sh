#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
NEED_START=1
if [ -f "$DIR/.panel.pid" ]; then
  PID=$(cat "$DIR/.panel.pid" 2>/dev/null || true)
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    NEED_START=0
  fi
fi
if [ "$NEED_START" = "1" ]; then
  "$DIR/start.sh"
fi
if ! pgrep -f "bin-cloudflared.*127\.0\.0\.1:8090" >/dev/null 2>&1; then
  nohup "$DIR/tunnel.sh" </dev/null >/dev/null 2>&1 &
fi
