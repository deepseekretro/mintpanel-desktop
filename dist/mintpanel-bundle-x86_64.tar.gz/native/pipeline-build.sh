#!/usr/bin/env bash
# 一键流水线：拉取固定版本源码 -> 注入 c-shared 补丁 -> 编译 libhy2.so / libxray.so / Node .node -> 打包 Java JAR
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_DIR="$(dirname "$HERE")"
PARENT_DIR="$(dirname "$PANEL_DIR")"

HY2_REPO="${HY2_REPO:-https://github.com/apernet/hysteria.git}"
HY2_TAG="${HY2_TAG:-app/v2.14.0}"
XRAY_REPO="${XRAY_REPO:-https://github.com/XTLS/Xray-core.git}"
XRAY_TAG="${XRAY_TAG:-v26.11.9}"

SRC_DIR="${SRC_DIR:-$HERE/.build-src}"
GO_BIN="${GO_BIN:-$PARENT_DIR/opt/go/bin/go}"
NODE_INC="${NODE_INC:-$PARENT_DIR/opt/node/include/node}"
ZIG_VER="${ZIG_VER:-0.14.0}"
ZIG_DIR="${ZIG_DIR:-$PARENT_DIR/opt/zig}"
export PATH="$PARENT_DIR/local/bin:$PARENT_DIR/local/usr/bin:$PARENT_DIR/opt/go/bin:$PATH"
export TMPDIR="${TMPDIR:-$PARENT_DIR/tmp}"
mkdir -p "$TMPDIR" "$SRC_DIR"

resolve_cc() {
  if [ -n "${CC:-}" ]; then
    echo "$CC"
    return 0
  fi
  if command -v gcc >/dev/null 2>&1; then
    echo "gcc"
    return 0
  fi
  if command -v clang >/dev/null 2>&1; then
    echo "clang"
    return 0
  fi
  if [ ! -x "$ZIG_DIR/zig" ]; then
    echo "[pipeline] 未检测到 gcc/clang，下载 zig-${ZIG_VER} 到 $ZIG_DIR ..." >&2
    local tgz="$TMPDIR/zig-linux-x86_64-${ZIG_VER}.tar.xz"
    curl -fsSL --max-time 180 -o "$tgz" "https://ziglang.org/download/${ZIG_VER}/zig-linux-x86_64-${ZIG_VER}.tar.xz"
    mkdir -p "$ZIG_DIR"
    python3 -c '
import lzma, os, tarfile, sys
src, dst = sys.argv[1], sys.argv[2]
with lzma.open(src) as xz, tarfile.open(fileobj=xz) as tf:
    for m in tf.getmembers():
        parts = m.name.split("/", 1)
        if len(parts) < 2 or not parts[1]:
            continue
        m.name = parts[1]
        tf.extract(m, dst, filter="tar")
' "$tgz" "$ZIG_DIR"
    rm -f "$tgz"
  fi
  cat > "$TMPDIR/zig-cc-wrapper.sh" <<ZWRAP
#!/usr/bin/env bash
exec "$ZIG_DIR/zig" cc -target x86_64-linux-gnu "\$@"
ZWRAP
  chmod +x "$TMPDIR/zig-cc-wrapper.sh"
  echo "$TMPDIR/zig-cc-wrapper.sh"
}

clone_pinned() {
  local repo="$1" tag="$2" dst="$3"
  if [ "${FRESH:-0}" = "1" ] && [ -d "$dst" ]; then
    rm -rf "$dst"
  fi
  if [ ! -d "$dst/.git" ]; then
    echo "[pipeline] clone $repo @ $tag -> $dst"
    git clone --depth 1 --branch "$tag" "$repo" "$dst"
  else
    echo "[pipeline] reset $dst -> $tag"
    git -C "$dst" reset --hard HEAD
    git -C "$dst" clean -fd
  fi
}

apply_patches() {
  local pdir="$1" repo_dir="$2"
  [ -d "$pdir" ] || return 0
  for p in "$pdir"/*.patch; do
    [ -f "$p" ] || continue
    echo "[pipeline] apply patch $(basename "$p")"
    git -C "$repo_dir" apply "$p"
  done
}

build_hy2() {
  local cc="$1"
  local dst="$SRC_DIR/hysteria"
  clone_pinned "$HY2_REPO" "$HY2_TAG" "$dst"
  apply_patches "$HERE/patches/hy2" "$dst"
  cp -f "$HERE/cgo/hy2/cshared_bridge.go" "$dst/app/cmd/cshared_bridge.go"
  mkdir -p "$dst/app/cshared"
  cp -f "$HERE/cgo/hy2/main.go" "$dst/app/cshared/main.go"

  echo "[pipeline] build libhy2.so ($HY2_TAG)"
  (
    cd "$dst/app"
    CGO_ENABLED=1 CC="$cc" "$GO_BIN" build -buildmode=c-shared -ldflags="-s -w" -o "$HERE/libhy2.so.tmp" ./cshared
  )
  mv -f "$HERE/libhy2.so.tmp" "$HERE/libhy2.so"
  rm -f "$HERE/libhy2.so.tmp.h" "$HERE/libhy2.so.h" "$HERE/libhy2.h"
}

build_xray() {
  local cc="$1"
  local dst="$SRC_DIR/xray-core"
  clone_pinned "$XRAY_REPO" "$XRAY_TAG" "$dst"
  apply_patches "$HERE/patches/xray" "$dst"
  mkdir -p "$dst/main/cshared"
  cp -f "$HERE/cgo/xray/main.go" "$dst/main/cshared/main.go"

  echo "[pipeline] build libxray.so ($XRAY_TAG)"
  (
    cd "$dst"
    CGO_ENABLED=1 CC="$cc" "$GO_BIN" build -buildmode=c-shared -ldflags="-s -w" -o "$HERE/libxray.so.tmp" ./main/cshared
  )
  mv -f "$HERE/libxray.so.tmp" "$HERE/libxray.so"
  rm -f "$HERE/libxray.so.tmp.h" "$HERE/libxray.so.h" "$HERE/libxray.h"
}

build_ffvpn() {
  local cc="$1"
  local dst="$HERE/firefox-vpn"
  echo "[pipeline] build libfirefoxvpn.so"
  (
    cd "$dst"
    CGO_ENABLED=1 CC="$cc" "$GO_BIN" build -tags cshared -buildmode=c-shared -ldflags="-s -w" -o "$HERE/libfirefoxvpn.so.tmp" .
  )
  mv -f "$HERE/libfirefoxvpn.so.tmp" "$HERE/libfirefoxvpn.so"
  rm -f "$HERE/libfirefoxvpn.so.tmp.h" "$HERE/libfirefoxvpn.so.h" "$HERE/libfirefoxvpn.h"
}

build_node() {
  local cc="$1"
  for name in yabs_hy2 yabs_xray yabs_cpu yabs_disk yabs_net yabs_firefoxvpn; do
    if [ "$name" = "yabs_net" ] && [ ! -f /usr/include/iperf_api.h ] && [ ! -f "$PARENT_DIR/local/usr/include/iperf_api.h" ]; then
      echo "[pipeline] skip yabs_net.node (缺少 iperf_api.h，保留现有预编译产物)"
      continue
    fi
    [ -f "$HERE/${name}.c" ] || continue
    echo "[pipeline] build ${name}.node"
    "$cc" -shared -fPIC -O2 -I"$NODE_INC" "$HERE/${name}.c" -ldl -o "$HERE/${name}.node.tmp"
    mv -f "$HERE/${name}.node.tmp" "$HERE/${name}.node"
  done
}

build_jar() {
  echo "[pipeline] build WorkbenchTTY-1.2.0-mint.jar"
  TMPDIR="$TMPDIR" bash "$PANEL_DIR/plugin-src/build-plugin.sh" "$PARENT_DIR/dist/WorkbenchTTY-1.2.0-mint.jar"
}

CC_RESOLVED="$(resolve_cc)"
echo "[pipeline] CC=$CC_RESOLVED GO=$GO_BIN"

TARGET="${1:-all}"
case "$TARGET" in
  hy2)  build_hy2 "$CC_RESOLVED" ;;
  xray) build_xray "$CC_RESOLVED" ;;
  ffvpn|firefoxvpn) build_ffvpn "$CC_RESOLVED" ;;
  node) build_node "$CC_RESOLVED" ;;
  jar)  build_jar ;;
  all)
    build_hy2 "$CC_RESOLVED"
    build_xray "$CC_RESOLVED"
    build_ffvpn "$CC_RESOLVED"
    build_node "$CC_RESOLVED"
    build_jar
    ;;
  *)
    echo "用法: $0 {all|hy2|xray|ffvpn|node|jar}"
    exit 1
    ;;
esac
echo "[pipeline] DONE ($TARGET)"
