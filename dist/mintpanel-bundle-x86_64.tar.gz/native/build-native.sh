#!/usr/bin/env bash
# Node.js N-API (.node) + Go c-shared (.so) + Java 插件 (.jar) 编译命令参考与一键脚本
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_DIR="$(dirname "$HERE")"
PARENT_DIR="$(dirname "$PANEL_DIR")"

NODE_INC="${NODE_INC:-$PARENT_DIR/opt/node/include/node}"
GO_BIN="${GO_BIN:-$PARENT_DIR/opt/go/bin/go}"
CC_BIN="${CC_BIN:-gcc}"

build_node_addons() {
  if ! command -v "$CC_BIN" >/dev/null 2>&1; then
    echo "缺少 gcc（CC_BIN=$CC_BIN），请在带 gcc 的构建机执行："
    echo "  gcc -shared -fPIC -O2 -I\"$NODE_INC\" \"$HERE/yabs_hy2.c\" -ldl -o \"$HERE/yabs_hy2.node\""
    echo "  gcc -shared -fPIC -O2 -I\"$NODE_INC\" \"$HERE/yabs_xray.c\" -ldl -o \"$HERE/yabs_xray.node\""
    return 1
  fi
  for name in yabs_hy2 yabs_xray yabs_cpu yabs_disk yabs_net yabs_firefoxvpn; do
    [ -f "$HERE/${name}.c" ] || continue
    echo "[CC] ${name}.c -> ${name}.node"
    "$CC_BIN" -shared -fPIC -O2 -I"$NODE_INC" "$HERE/${name}.c" -ldl -o "$HERE/${name}.node"
  done
}

print_go_so_commands() {
  cat <<GOCMD
# Go c-shared .so（同时供 Node yabs_*.node 与 Java EmbeddedHy2/EmbeddedXray 纯内存加载）
# 1) libhy2.so（导出 Hy2Start / Hy2StartYAML / Hy2Stop / Hy2StatusJSON / Hy2FreeStr）:
CGO_ENABLED=1 $GO_BIN build -buildmode=c-shared -ldflags="-s -w" -o "$HERE/libhy2.so" ./hy2-cgo

# 2) libxray.so（导出 XrayStart / XrayStop / XrayStatusJSON / XrayFreeStr）:
CGO_ENABLED=1 $GO_BIN build -buildmode=c-shared -ldflags="-s -w" -o "$HERE/libxray.so" ./xray-cgo

# 3) libfirefoxvpn.so（导出 FFVpnStart / FFVpnStartJSON / FFVpnStop / FFVpnStatusJSON / FFVpnActionJSON / FFVpnFreeStr）:
CGO_ENABLED=1 $GO_BIN build -tags cshared -buildmode=c-shared -ldflags="-s -w" -o "$HERE/libfirefoxvpn.so" ./firefox-vpn
GOCMD
}

build_java_jar() {
  TMPDIR="${TMPDIR:-$PARENT_DIR/tmp}" \
    bash "$PANEL_DIR/plugin-src/build-plugin.sh" \
    "${1:-$PARENT_DIR/dist/WorkbenchTTY-1.2.0-mint.jar}"
}

case "${1:-all}" in
  node) build_node_addons ;;
  go-cmd) print_go_so_commands ;;
  jar) build_java_jar "${2:-}" ;;
  all)
    print_go_so_commands
    echo ""
    build_node_addons || true
    echo ""
    echo "# Java 插件 JAR 编译命令:"
    echo "TMPDIR=\"$PARENT_DIR/tmp\" bash \"$PANEL_DIR/plugin-src/build-plugin.sh\" \"$PARENT_DIR/dist/WorkbenchTTY-1.2.0-mint.jar\""
    ;;
  *)
    echo "用法: $0 {all|node|go-cmd|jar [base.jar]}"
    exit 1
    ;;
esac
