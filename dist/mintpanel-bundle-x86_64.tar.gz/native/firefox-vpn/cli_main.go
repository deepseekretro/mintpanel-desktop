//go:build !cshared

package main

func main() {
	var (
		fxaToken = flag.String("fxa-token", os.Getenv("IPP_FXA_TOKEN"), "FxA access token（空则从 Firefox profile 读）")
		profile  = flag.String("profile", os.Getenv("IPP_PROFILE"), "Firefox profile 目录或其父目录")
		listen   = flag.String("listen", DefaultListenAddr, "本地代理监听地址（填 off 或空串则不自动启动）")
		useH3    = flag.Bool("h3", true, "用 HTTP/3 (QUIC) 隧道，单连接多路复用（默认开；节点不支持会自动降级）")
		h3Conns  = flag.Int("h3-conns", 4, "预热的 QUIC 连接条数（每条最多 64 路复用；长肥管道调大能提速）")
		node     = flag.String("node", "", "IPP 节点主机名（默认自动选）")
		ipMode   = flag.String("ip-mode", "auto", "出口 IP 策略（目标站侧）: auto/ipv4/ipv6/remote")
		nodeIP   = flag.String("node-ip", "auto", "连 Mozilla 节点用的 IP 族: auto/ipv4/ipv6")
		port     = flag.Int("node-port", 2499, "IPP 节点端口")
		loginPx  = flag.String("login-proxy", DefaultLoginProxy, "登录用的出站代理（http:// 或 socks5://，填 direct 则直连）")
		public   = flag.String("listen-public", "", "对外公开的无认证代理地址（如 0.0.0.0:1080，空=不启用）")
		listCC   = flag.Bool("list-servers", false, "列出可用节点后退出")
		status   = flag.Bool("status", false, "查询账号资格后退出")
		admin    = flag.String("admin", "", "管理界面监听地址（默认 127.0.0.1:随机端口；填 off 关闭）")
		open     = flag.Bool("open", true, "启动后自动在浏览器打开管理界面")
		warmN    = flag.Int("warm", defaultWarmSize, "节点预热条数（0=禁用，默认 10）")
		guiMode  = flag.Bool("gui", true, "用桌面窗口界面（默认开启；-gui=false 改用浏览器界面）")
		cfgFile  = flag.String("config", "", "配置文件路径（默认在系统配置目录）")
		remember = flag.Bool("remember", false, "记住登录（加密保存 sessionToken）")
	)
	flag.Parse()

	if !*useH3 {
		h3Enabled.Store(false)
	}
	if *h3Conns > 0 {
		h3WarmConns = *h3Conns
	}

	// 内核网络参数：socket 缓冲上限不够会让 QUIC 吞吐被 BDP 卡死
	tuneKernelBuffers()

	// 加载配置文件：配置文件提供默认值，命令行显式参数优先
	cfg, cfgErr := InitConfig(*cfgFile)
	if cfgErr != nil {
		log.Printf("[config] 读取失败: %v（按默认值继续）", cfgErr)
	} else if ConfigPath() != "" {
		if _, st := os.Stat(ConfigPath()); st == nil {
			log.Printf("[config] %s", ConfigPath())
		}
	}

	// 记录哪些参数是命令行显式给的
	set := map[string]bool{}
	flag.Visit(func(f *flag.Flag) { set[f.Name] = true })

	// 用配置文件补齐未显式指定的参数
	if !set["profile"] && cfg.Profile != "" {
		*profile = cfg.Profile
	}
	if !set["login-proxy"] && cfg.LoginProxy != "" {
		*loginPx = cfg.LoginProxy
	}
	if !set["listen"] && cfg.Listen != "" {
		*listen = cfg.Listen
	}
	if !set["ip-mode"] && cfg.IPMode != "" {
		*ipMode = cfg.IPMode
	}
	if !set["node-ip"] && cfg.NodeIP != "" {
		*nodeIP = cfg.NodeIP
	}
	if !set["warm"] && cfg.Warm > 0 {
		*warmN = cfg.Warm
	}
	if !set["node"] && cfg.Node != "" {
		*node = cfg.Node
	}
	if !set["node-port"] && cfg.NodePort > 0 {
		*port = cfg.NodePort
	}
	if *remember && !cfg.SaveToken {
		_ = UpdateConfig(func(c *Config) { c.SaveToken = true })
		cfg.SaveToken = true
	}

	// 已保存的 sessionToken 优先于从 profile 读取（省得依赖 Firefox 在场）
	if !set["fxa-token"] && *fxaToken == "" && cfg.SaveToken {
		if tok, terr := LoadedSessionToken(); terr != nil {
			log.Printf("[config] 已保存的 token 无法解密: %v", terr)
		} else if tok != "" {
			log.Printf("[config] 使用已保存的登录凭证（%s 加密）", effectiveCipher(cfg.TokenCipher))
			*fxaToken = tok
		}
	}

	netcfg := DefaultNetConfig()
	// 显式指定优先；direct/off/none 代表强制直连
	switch strings.ToLower(strings.TrimSpace(*loginPx)) {
	case "direct", "off", "none", "-":
		netcfg.ProxyURL = ""
	case "":
		// 保持 DefaultNetConfig 的结果
	default:
		netcfg.ProxyURL = strings.TrimSpace(*loginPx)
	}
	if netcfg.ProxyURL != "" {
		log.Printf("[auth] 登录出站走代理 %s", netcfg.ProxyURL)
	} else {
		log.Printf("[auth] 登录出站直连")
	}

	// 节点侧 IP 族（本机 -> Mozilla 节点）
	if m, err := ParseNodeIPMode(*nodeIP); err != nil {
		log.Printf("[warn] %v，改用 auto", err)
	} else {
		GlobalNodeIP.Set(m)
		if m != NodeIPAuto {
			log.Printf("[node] 连接节点强制使用 %s", m)
		}
	}

	// 全局唯一配置，界面改完立即对所有出站请求生效
	ns2 := NewNetStore(netcfg)

	ts, err := NewTokenSourceWithNet(*fxaToken, *profile, ns2.Get)
	if err != nil {
		// 不直接退出：否则用户永远进不了界面去改成正确的 profile。
		// 无 token 时仍起 UI（代理服务自然无法启动），方便在页面上扫描/切换 profile。
		log.Printf("[warn] %v", err)
		log.Printf("[warn] 将在无 token 状态下启动，请到界面里选择 Firefox profile")
		ts = NewTokenSourceEmpty(*fxaToken, *profile, ns2.Get)
	}
	if ts == nil {
		ts = NewTokenSourceEmpty(*fxaToken, *profile, ns2.Get)
	}
	if exp := ts.Expiry(); !exp.IsZero() {
		mode := "只读"
		if ts.CanRefresh() {
			mode = "可自动续期(sessionToken)"
		}
		log.Printf("[auth] token 有效期至 %s（剩余 %v，%s）",
			exp.Format("2006-01-02 15:04"),
			time.Until(exp).Truncate(time.Minute), mode)
	}

	g := NewGuardianWithNet(ts, ns2.Get)

	if *status {
		e, err := g.Status()
		if err != nil {
			log.Fatalf("status: %v", err)
		}
		fmt.Printf("uid=%d subscribed=%v limited_bandwidth=%v maxBytes=%s\n",
			e.UID, e.Subscribed, e.LimitedBandwidth, e.MaxBytes)
		return
	}

	if *listCC {
		list, err := FetchServers()
		if err != nil {
			log.Fatalf("servers: %v", err)
		}
		var out []string
		for _, c := range list {
			for _, ci := range c.Cities {
				for _, s := range ci.Servers {
					if s.Quarantined {
						continue
					}
					out = append(out, fmt.Sprintf("%-4s %-16s %s:%d",
						c.Code, c.Name, s.Hostname, s.Port))
				}
			}
		}
		sort.Strings(out)
		for _, l := range out {
			fmt.Println(l)
		}
		fmt.Printf("\n共 %d 个可用节点\n", len(out))
		return
	}

	// 构建完整节点列表（供管理页面选择）
	allNodes, err := FetchNodeList(*port)
	if err != nil {
		log.Printf("[warn] 拉取节点列表失败: %v", err)
	}

	// 选节点
	if *node == "" {
		if len(allNodes) == 0 {
			log.Fatal("没有可用节点")
		}
		// 不再是「列表里第一个」，而是实测最快的那个：
		// 节点间延迟差可达 40 倍（14ms vs 577ms），值得花几百毫秒探测。
		best := PickFastest(allNodes, 4*time.Second, allNodes[0])
		*node = best.Host
		log.Printf("[node] 自动选择 %s (%s)", best.Host, best.Code)
	}

	// 定位当前节点在列表里的完整信息
	cur := Node{Host: *node, Port: *port}
	for _, n := range allNodes {
		if n.Host == *node {
			cur = n
			break
		}
	}
	ns := NewNodeSwitch(allNodes, cur)

	pm, err := NewPassManager(g)
	if err != nil {
		log.Printf("[warn] pass 管理器初始化失败: %v（继续运行，稍后重试）", err)
	}
	defer pm.Close()

	d := &Dialer{ns: ns, port: *port, pm: pm, res: newResolver(IPMode(*ipMode))}

	// 自检: 建立一次隧道
	if c, err := d.Dial("ifconfig.me:443"); err != nil {
		log.Printf("[warn] 自检失败: %v", err)
	} else {
		c.Close()
		log.Printf("[ok] 隧道自检通过")
	}

	// HTTP/3 预热：一条 QUIC 连接承载多个 CONNECT stream，
	// 后续所有目标都复用它，不需要像 h1 那样囤一堆连接。
	if h3Enabled.Load() {
		// h3 万一探测失败，自动补启动 h1 预热池，避免退化成零预热
		if *warmN > 0 {
			h3FallbackHook = func() {
				warmer.size = *warmN
				warmer.Start(d)
				log.Printf("[warm] h3 不可用，已启动 HTTP/1.1 预热池 = %d 条", *warmN)
			}
		}
		if cur := ns.Current(); cur.Host != "" {
			warmH3(cur)
		}
		// h3 生效时 h1 预热池是纯浪费：那些连接一次都用不上，
		// 还在后台反复握手耗流量。降级到 h1 时才启动它。
		log.Printf("[warm] h3 已启用，跳过 HTTP/1.1 预热池（省流量）")
	} else {
		log.Printf("[h3] 已禁用（使用 HTTP/1.1 单目标隧道）")
		if *warmN > 0 {
			warmer.size = *warmN
			warmer.Start(d)
			log.Printf("[warm] 预热池大小 = %d 条", *warmN)
		} else {
			log.Printf("[warm] 已禁用节点预热")
		}
	}

	// 代理实例：监听由 ProxyService 控制（可在界面里启停/改端口）
	p := &Proxy{d: d, port: *port}
	svc := NewProxyService(p)

	// 原生桌面界面（MyGo）：开启后不再起 HTTP 管理页
	if *guiMode {
		// Start 内部已打印启动日志，这里不重复
		if err := svc.Start(*listen); err != nil {
			log.Printf("[warn] 代理启动失败: %v", err)
		}
		tr := newTokenRuntime(ts, ns2)
		if err := runGUI(guiOptions{
			ns:  ns,
			pm:  pm,
			tr:  tr,
			svc: svc,
			d:   d,
		}); err != nil {
			// 窗口起不来（缺 WebView2 运行时、无图形环境等）时不要直接退出，
			// 自动降级到浏览器界面，功能完全一致。
			log.Printf("[gui] 窗口启动失败: %v", err)
			log.Printf("[gui] 自动降级为浏览器界面")
			*guiMode = false
		} else {
			return
		}
	}

	// 管理页面（节点切换）
	// 默认监听 127.0.0.1 的随机空闲端口，避免固定端口冲突；
	// 传 -admin off 可彻底关闭。
	if !strings.EqualFold(*admin, "off") {
		listenAddr := *admin
		if listenAddr == "" {
			listenAddr = "127.0.0.1:0" // 0 = 让系统挑一个空闲端口
		}

		tr := newTokenRuntime(ts, ns2)
		a := &AdminServer{ns: ns, pm: pm, tr: tr, svc: svc, d: d}

		// 自己先 Listen，才能拿到实际端口（listenAddr 可能是 :0）
		ln, lerr := a.listenOn(listenAddr)
		if lerr != nil {
			log.Printf("[admin] 监听失败: %v", lerr)
		} else {
			actual := ln.Addr().String()
			uiURL := adminURL(actual)
			log.Printf("[ui] 管理界面 -> %s", uiURL)

			go func() {
				if err := a.serveOn(ln); err != nil {
					log.Printf("[admin] 退出: %v", err)
				}
			}()

			if *open {
				go openBrowser(uiURL)
			}
		}
	}

	// 启动代理监听
	// -listen 默认 127.0.0.1:10909；填 off/空串 则不自动启动（可在界面里点启动）
	switch strings.ToLower(strings.TrimSpace(*listen)) {
	case "", "off", "none", "-":
		log.Printf("[service] 未自动启动代理（可在界面里开启）")
	default:
		if err := svc.Start(*listen); err != nil {
			log.Printf("[service] 启动代理失败: %v（可在界面里重试）", err)
		}
	}

	// 额外公开监听（命令行指定时自动开）
	if *public != "" {
		if err := svc.StartPublic(*public); err != nil {
			log.Printf("[warn] 公开代理监听失败: %v", err)
		}
	}

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, syscall.SIGINT, syscall.SIGTERM)
	<-sig
	log.Printf("[exit] 共接受 %d 连接, %d 错误", p.TotalConns(), p.TotalErrs())
}
