package main

// openbrowser.go: 启动后自动打开管理界面
//
// Windows:  start "" "http://..."   （start 是 cmd 内建命令）
// macOS:    open "http://..."
// Linux:    xdg-open "http://..."
//
// 全部用系统自带命令，不引入第三方依赖。
// 失败不影响主流程（比如服务器上没桌面环境），只打日志。

import (
	"log"
	"net"
	"os/exec"
	"runtime"
	"time"
)

// openBrowser 尝试在默认浏览器里打开 url
func openBrowser(url string) {
	var cmd *exec.Cmd

	switch runtime.GOOS {
	case "windows":
		// start 是 cmd 内建命令，必须通过 cmd /c 调用。
		// 第一个空字符串参数是窗口标题占位，否则带引号的 URL 会被当成标题。
		cmd = exec.Command("cmd", "/c", "start", "", url)

	case "darwin":
		cmd = exec.Command("open", url)

	default:
		cmd = exec.Command("xdg-open", url)
	}

	// 不等待浏览器退出
	if err := cmd.Start(); err != nil {
		log.Printf("[ui] 自动打开浏览器失败: %v（请手动访问 %s）", err, url)
		return
	}
	go func() {
		if err := cmd.Wait(); err != nil {
			log.Printf("[ui] 浏览器进程结束: %v", err)
		}
	}()
	log.Printf("[ui] 已在浏览器打开 %s", url)
}

// adminURL 把监听地址转成可在浏览器打开的 URL
//
// 监听 0.0.0.0 / :: 时用 127.0.0.1 打开。
func adminURL(listen string) string {
	host, port, err := net.SplitHostPort(listen)
	if err != nil {
		return "http://" + listen + "/"
	}
	switch host {
	case "", "0.0.0.0", "::", "[::]":
		host = "127.0.0.1"
	}
	return "http://" + net.JoinHostPort(host, port) + "/"
}

// waitListening 等端口可连接，最多等 timeout
func waitListening(listen string, timeout time.Duration) bool {
	host, port, err := net.SplitHostPort(listen)
	if err != nil {
		return false
	}
	switch host {
	case "", "0.0.0.0", "::", "[::]":
		host = "127.0.0.1"
	}
	addr := net.JoinHostPort(host, port)

	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		c, err := net.DialTimeout("tcp", addr, 300*time.Millisecond)
		if err == nil {
			c.Close()
			return true
		}
		time.Sleep(120 * time.Millisecond)
	}
	return false
}
