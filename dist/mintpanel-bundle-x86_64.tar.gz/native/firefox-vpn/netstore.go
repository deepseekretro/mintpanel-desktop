package main

// netstore.go: 全局共享的出站配置
//
// 之前 netcfg 是按值在各处拷贝的：TokenSource 一份、Guardian 一份、
// tokenRuntime 一份。界面改代理只改了其中一份，于是出现
// “界面配了代理但取 pass 仍走直连”的问题。
//
// 现在统一用 NetStore 持有，各处只拿指针、按需读取。

import "sync"

// NetStore 线程安全的 NetConfig 容器
type NetStore struct {
	mu  sync.RWMutex
	cfg NetConfig
}

// NewNetStore 创建
func NewNetStore(initial NetConfig) *NetStore {
	return &NetStore{cfg: initial}
}

// Get 返回副本（调用方随便改不会影响全局）
func (s *NetStore) Get() *NetConfig {
	s.mu.RLock()
	defer s.mu.RUnlock()
	c := s.cfg
	return &c
}

// Set 覆盖
func (s *NetStore) Set(c NetConfig) {
	s.mu.Lock()
	s.cfg = c
	s.mu.Unlock()
}

// ProxyURL 当前代理地址
func (s *NetStore) ProxyURL() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.cfg.ProxyURL
}

// Timeout 当前超时
func (s *NetStore) Timeout() int {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.cfg.Timeout
}
