package main

// api_service.go: 代理服务的启停/改端口 API
//
//   GET  /api/service           当前状态
//   POST /api/service/start     {addr:"127.0.0.1:1080"}
//   POST /api/service/stop      {}
//   POST /api/service/restart   {addr:"127.0.0.1:1080"}
//
// 公开监听（无认证，慎用）：
//   POST /api/service/public/start   {addr:"0.0.0.0:7890"}
//   POST /api/service/public/stop

import (
	"encoding/json"
	"log"
	"net/http"
	"time"
)

type addrReq struct {
	Addr string `json:"addr"`
}

func (a *AdminServer) handleService(w http.ResponseWriter, r *http.Request) {
	if a.svc == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "服务管理未启用"})
		return
	}
	st := a.svc.State()
	pubRunning, pubAddr := a.svc.PublicState()
	writeJSON(w, map[string]any{
		"service": st,
		"public": map[string]any{
			"running": pubRunning,
			"addr":    pubAddr,
		},
		// lastUserAddr 上次用户输入的地址（界面回填用）
		"lastAddr": a.lastAddr,
	})
}

func (a *AdminServer) handleServiceAction(w http.ResponseWriter, r *http.Request) {
	if a.svc == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "服务管理未启用"})
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "方法不允许", http.StatusMethodNotAllowed)
		return
	}

	var req addrReq
	json.NewDecoder(r.Body).Decode(&req)

	var err error
	switch r.URL.Path {
	case "/api/service/start":
		if req.Addr != "" {
			a.lastAddr = req.Addr
		}
		err = a.svc.Start(req.Addr)

	case "/api/service/stop":
		err = a.svc.Stop()

	case "/api/service/restart":
		if req.Addr != "" {
			a.lastAddr = req.Addr
		}
		err = a.svc.Restart(req.Addr)

	case "/api/service/public/start":
		err = a.svc.StartPublic(req.Addr)

	case "/api/service/public/stop":
		err = a.svc.StopPublic()
	}

	if err != nil {
		st := a.svc.State()
		writeJSON(w, map[string]any{
			"ok":      false,
			"error":   err.Error(),
			"service": st,
		})
		return
	}

	st := a.svc.State()
	pubRunning, pubAddr := a.svc.PublicState()
	writeJSON(w, map[string]any{
		"ok":      true,
		"service": st,
		"public": map[string]any{
			"running": pubRunning,
			"addr":    pubAddr,
		},
	})
}

// handleIPMode IP 出口策略查询/切换
//
// GET  /api/ipmode  -> {"mode":"ipv4"}
// POST /api/ipmode  {"mode":"ipv4"}  (auto/ipv4/ipv6/remote)
func (a *AdminServer) handleIPMode(w http.ResponseWriter, r *http.Request) {
	if a.d == nil || a.d.res == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "解析器未启用"})
		return
	}

	switch r.Method {
	case http.MethodGet:
		writeJSON(w, map[string]any{"mode": a.d.res.Mode().String()})

	case http.MethodPost:
		var req struct {
			Mode string `json:"mode"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": "参数错误"})
			return
		}
		m, err := ParseIPMode(req.Mode)
		if err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		a.d.res.SetMode(m)
		writeJSON(w, map[string]any{"ok": true, "mode": m.String()})

	default:
		http.Error(w, "方法不允许", http.StatusMethodNotAllowed)
	}
}

// handleNodeIP 节点侧 IP 族查询/切换
//
// GET  /api/nodeip -> {"mode":"auto"}
// POST /api/nodeip {"mode":"ipv4"}
func (a *AdminServer) handleNodeIP(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		writeJSON(w, map[string]any{"mode": GlobalNodeIP.Get().String()})

	case http.MethodPost:
		var req struct {
			Mode string `json:"mode"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": "参数错误"})
			return
		}
		m, err := ParseNodeIPMode(req.Mode)
		if err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		GlobalNodeIP.Set(m)
		log.Printf("[node] 节点 IP 族 -> %s", m)
		writeJSON(w, map[string]any{"ok": true, "mode": m.String()})

	default:
		http.Error(w, "方法不允许", http.StatusMethodNotAllowed)
	}
}

// handlePass 返回当前 ProxyPass（调试用）
//
// GET /api/pass -> {"token":"...","expiresAt":...,"expiresIn":...}
func (a *AdminServer) handlePass(w http.ResponseWriter, r *http.Request) {
	if a.d == nil || a.d.pm == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "未就绪"})
		return
	}
	p := a.d.pm.Get()
	if p == nil || p.Token == "" {
		writeJSON(w, map[string]any{"ok": false, "error": "无有效 pass"})
		return
	}
	writeJSON(w, map[string]any{
		"ok":        true,
		"token":     p.Token,
		"expiresAt": p.Exp,
		"expiresIn": p.Exp - time.Now().Unix(),
	})
}

// handleWarm 预热状态
//
// GET /api/warm -> {"idle":2,"total":2,"used":0,"node":"...","targetSize":2}
func (a *AdminServer) handleWarm(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, warmer.Stats())
}
