package main

// nodedial.go: 本机 -> Mozilla 节点 这一腿的 IP 族选择
//
// 与 resolve.go 的 -ip-mode 是两件事：
//
//   -ip-mode   : 出口节点 -> 目标网站 用 IPv4 还是 IPv6
//   -node-ip   : 本机 -> Mozilla 节点 用 IPv4 还是 IPv6
//
// Mozilla 的 Fastly 节点是双栈的，例如：
//   icn145.m1.fastly-masque.net  A=23.235.42.37  AAAA=2a04:4e41:8001::37
//
// Go 默认用 Happy Eyeballs（先试 v6 再回退 v4），如果本机 v6 路由不通
// 会有一段明显延迟；反之强制 v4 可以更快建连，也能避免某些
// "v6 能连但 TLS 握手被中间设备搞坏" 的环境问题。

import (
	"context"
	"fmt"
	"net"
	"strings"
	"sync"
	"time"
)

// contextWithTimeout 短封装
func contextWithTimeout(d time.Duration) (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.Background(), d)
}

// NodeIPMode 节点侧 IP 族
type NodeIPMode string

const (
	// NodeIPAuto 系统默认（Happy Eyeballs，v6 优先）
	NodeIPAuto NodeIPMode = "auto"
	// NodeIPV4 强制 IPv4
	NodeIPV4 NodeIPMode = "ipv4"
	// NodeIPV6 强制 IPv6
	NodeIPV6 NodeIPMode = "ipv6"
)

// ParseNodeIPMode 解析
func ParseNodeIPMode(s string) (NodeIPMode, error) {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "", "auto", "default":
		return NodeIPAuto, nil
	case "ipv4", "v4", "4":
		return NodeIPV4, nil
	case "ipv6", "v6", "6":
		return NodeIPV6, nil
	}
	return NodeIPAuto, fmt.Errorf("未知的节点 IP 模式 %q（可选 auto/ipv4/ipv6）", s)
}

func (m NodeIPMode) String() string {
	if m == "" {
		return string(NodeIPAuto)
	}
	return string(m)
}

// nodeIPStore 线程安全的节点 IP 模式容器（界面可热改）
type nodeIPStore struct {
	mu   sync.RWMutex
	mode NodeIPMode
}

func newNodeIPStore(m NodeIPMode) *nodeIPStore {
	return &nodeIPStore{mode: m}
}

func (s *nodeIPStore) Get() NodeIPMode {
	if s == nil {
		return NodeIPAuto
	}
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.mode
}

func (s *nodeIPStore) Set(m NodeIPMode) {
	s.mu.Lock()
	s.mode = m
	s.mu.Unlock()
}

// GlobalNodeIP 全局节点 IP 族（main 里按 flag 初始化）
var GlobalNodeIP = newNodeIPStore(NodeIPAuto)

// dialNode 按策略连接节点
//
// host 用于 TLS SNI，addr 是 host:port 形式（可含域名）。
func dialNode(host, addr string, timeout time.Duration, mode NodeIPMode) (net.Conn, error) {
	if timeout <= 0 {
		timeout = 15 * time.Second
	}
	switch mode {
	case NodeIPV4:
		return dialNodeFamily(host, addr, timeout, "ip4")
	case NodeIPV6:
		return dialNodeFamily(host, addr, timeout, "ip6")
	default:
		return net.DialTimeout("tcp", addr, timeout)
	}
}

// dialNodeFamily 解析指定族后连接
func dialNodeFamily(host, addr string, timeout time.Duration, network string) (net.Conn, error) {
	h, port, err := net.SplitHostPort(addr)
	if err != nil {
		h, port = host, "2499"
	}

	// 已经是字面量就直接连
	if ip := net.ParseIP(h); ip != nil {
		return net.DialTimeout("tcp", addr, timeout)
	}

	ctx, cancel := contextWithTimeout(timeout)
	defer cancel()

	ips, err := net.DefaultResolver.LookupIP(ctx, network, h)
	if err != nil {
		return nil, fmt.Errorf("解析节点 %s 的 %s 地址失败: %w", h, network, err)
	}
	if len(ips) == 0 {
		return nil, fmt.Errorf("节点 %s 没有 %s 地址", h, network)
	}

	// 逐个试，取第一个成功的
	var lastErr error
	for _, ip := range ips {
		target := net.JoinHostPort(ip.String(), port)
		c, err := net.DialTimeout("tcp", target, timeout)
		if err == nil {
			return c, nil
		}
		lastErr = err
	}
	return nil, fmt.Errorf("连接节点 %s 失败: %w", h, lastErr)
}
