package main

// HTTP/3 隧道（QUIC 多路复用）
//
// 背景：
//   IPP 节点在 HTTP/1.1 上每个 CONNECT 都要单独占一条 TCP+TLS 连接。
//   浏览器播放视频时会并发几十个分片请求，每次都握手一次，延迟很痛。
//
//   实测发现节点其实支持 HTTP/3 上的扩展 CONNECT（RFC 9220）：
//     h2  → 400 Invalid CONNECT request   （协议层不认）
//     h3  → 400 parsing JWT failed        （认了 CONNECT，只是没给对 token）
//   所以可以用一条 QUIC 连接承载任意多个 CONNECT stream，握手只做一次。
//
// 设计：
//   - 每个节点维护若干条 QUIC 连接（h3Pool）
//   - 每次建隧道 = 在该连接上开一个 stream，发 CONNECT 头，然后双向拷贝
//   - 连接坏了自动摘除重建；流级失败不影响连接本身
//   - 与现有 HTTP/1.1 路径并存，h3 失败自动回退

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
)

var h3Enabled atomic.Bool
var h3PoolVersion atomic.Int64 // 切节点时自增，旧连接作废

// 一条 QUIC 连接同时承载的 stream 上限。超过就再开一条连接。
//
// 视频播放时浏览器会并发几十个分片请求，64 路很容易打满。
// 打满后才现开连接会有一次握手卡顿，所以启动时预热 h3WarmConns 条，
// 打满时可直接接管，无感知。
const h3MaxStreamsPerConn = 64

// 单个节点最多建多少条 QUIC 连接。
// 目标域名极分散时会不断新建连接，这里兜底防止打爆对端和本机。
const h3MaxConnsPerNode = 16

// 启动时预热的 QUIC 连接条数（可用 -h3-conns 覆盖）。
//
// 为什么要多条：QUIC 的拥塞控制是「每条连接独立」的，CUBIC 在
// RTT 120ms 这类长肥管道上，从初始窗口爬到满速要好几秒。
// 多条连接并行爬升，等于把「慢启动」摊薄，首屏和起播明显更快。
// 空闲 QUIC 连接的开销只有 25 秒一个 KeepAlive 包，代价可忽略。
var h3WarmConns = 4

// QUIC 连接空闲超时。视频可能长时间无数据但要保持，设大些，
// 真正的回收靠切换节点时的 dropAll。
const h3IdleTimeout = 5 * time.Minute

func init() { h3Enabled.Store(true) }

// ---------- h3Conn：一条到节点的 QUIC 连接 ----------

type h3Conn struct {
	node Node
	conn *quic.Conn
	cc   *http3.ClientConn

	mu      sync.Mutex
	closed  bool
	streams int
	created time.Time
}

func (c *h3Conn) isClosed() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.closed
}

func (c *h3Conn) close() {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return
	}
	c.closed = true
	c.mu.Unlock()

	if c.cc != nil {
		_ = c.cc.CloseWithError(0, "closed")
	}
	if c.conn != nil {
		_ = c.conn.CloseWithError(0, "closed")
	}
}

func (c *h3Conn) acquire() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.closed || c.streams >= h3MaxStreamsPerConn {
		return false
	}
	c.streams++
	return true
}

func (c *h3Conn) release() {
	c.mu.Lock()
	if c.streams > 0 {
		c.streams--
	}
	c.mu.Unlock()
}

// ---------- h3Pool ----------

type h3Pool struct {
	mu    sync.Mutex
	conns map[string][]*h3Conn // key = node.Host
}

func newH3Pool() *h3Pool { return &h3Pool{conns: make(map[string][]*h3Conn)} }

// pick 为某个目标挑一条连接。
//
// 分配策略：按目标域名哈希到固定连接（粘滞）。
//
// 为什么不能简单地「哪条空闲就用哪条」：
// QUIC 的拥塞控制是「每条连接一个窗口」，同一连接上的所有 stream
// 共享这个窗口。如果 YouTube 的视频分片和一个网页的几十个小请求
// 混在同一条连接上，小请求会抢走窗口份额，视频就卡。
//
// 按目标哈希后，同一站点始终走同一条连接：
//   - 视频站的流量独占一条连接的窗口，不被干扰
//   - 不同站点天然分流到不同连接，拥塞窗口互不影响
//   - 连接的创建和复用保持稳定，不会每次都换到新连接重建窗口
func (p *h3Pool) pick(node Node, target string) *h3Conn {
	p.mu.Lock()
	defer p.mu.Unlock()

	// 先清理已关闭的连接
	list := p.conns[node.Host]
	live := list[:0]
	for _, c := range list {
		if !c.isClosed() {
			live = append(live, c)
		}
	}
	p.conns[node.Host] = live
	if len(live) == 0 {
		return nil
	}

	// 按目标域名哈希挑一条，实现粘滞
	host := targetHost(target)
	idx := int(hashStr(host) % uint32(len(live)))

	c := live[idx]
	if c.acquire() {
		return c
	}
	// 目标指定的那条满了，找同节点其他还有空位的
	for i := 0; i < len(live); i++ {
		if i == idx {
			continue
		}
		if live[i].acquire() {
			return live[i]
		}
	}
	return nil
}

// targetHost 从 "example.com:443" 里取出域名部分
func targetHost(target string) string {
	if i := strings.LastIndexByte(target, ':'); i > 0 {
		return target[:i]
	}
	return target
}

// hashStr FNV-1a，够快且分布均匀
func hashStr(s string) uint32 {
	var h uint32 = 2166136261
	for i := 0; i < len(s); i++ {
		h ^= uint32(s[i])
		h *= 16777619
	}
	return h
}

// count 返回某节点当前存活连接数
func (p *h3Pool) count(host string) int {
	p.mu.Lock()
	defer p.mu.Unlock()
	n := 0
	for _, c := range p.conns[host] {
		if !c.isClosed() {
			n++
		}
	}
	return n
}

func (p *h3Pool) add(c *h3Conn) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.conns[c.node.Host] = append(p.conns[c.node.Host], c)
}

func (p *h3Pool) dropNode(host string) int {
	p.mu.Lock()
	list := p.conns[host]
	delete(p.conns, host)
	p.mu.Unlock()

	for _, c := range list {
		c.close()
	}
	return len(list)
}

func (p *h3Pool) dropAll() int {
	p.mu.Lock()
	all := p.conns
	p.conns = make(map[string][]*h3Conn)
	p.mu.Unlock()

	n := 0
	for _, list := range all {
		for _, c := range list {
			c.close()
			n++
		}
	}
	return n
}

func (p *h3Pool) Stats() map[string]any {
	p.mu.Lock()
	defer p.mu.Unlock()

	conns, streams := 0, 0
	for _, list := range p.conns {
		for _, c := range list {
			if c.isClosed() {
				continue
			}
			conns++
			c.mu.Lock()
			streams += c.streams
			c.mu.Unlock()
		}
	}
	return map[string]any{
		"enabled": h3Enabled.Load(),
		"conns":   conns,
		"streams": streams,
	}
}

var h3p = newH3Pool()

// ---------- 建连 ----------

// dialH3 建一条到节点的 QUIC 连接
func dialH3(node Node) (*h3Conn, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// QUIC 走 UDP，节点 IP 模式（v4/v6/auto）同样生效
	addr, err := resolveH3Addr(node.Addr(), string(GlobalNodeIP.Get()))
	if err != nil {
		return nil, fmt.Errorf("resolve: %w", err)
	}

	tlsCfg := &tls.Config{
		ServerName: node.Host,
		NextProtos: []string{http3.NextProtoH3},
		MinVersion: tls.VersionTLS13, // QUIC 强制 TLS 1.3
	}

	// 自己建 UDP socket 才能把内核缓冲拉满。
	// quic-go 的 DialAddr 内部 socket 用的是系统默认值（Linux ~200KB），
	// 高带宽 + 高丢包链路下会频繁丢包重传，吞吐上不去。
	udpAddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return nil, fmt.Errorf("resolve udp: %w", err)
	}
	pc, err := net.ListenUDP("udp", &net.UDPAddr{IP: net.IPv4zero, Port: 0})
	if err != nil {
		return nil, fmt.Errorf("listen udp: %w", err)
	}
	// 7MB 是 Linux 单 socket 缓冲的常见上限，内核会按 rmem_max 自动截断
	_ = pc.SetReadBuffer(7 * 1024 * 1024)
	_ = pc.SetWriteBuffer(7 * 1024 * 1024)

	qc, err := quic.Dial(ctx, pc, udpAddr, tlsCfg, quicCfg())
	if err != nil {
		pc.Close()
		return nil, fmt.Errorf("quic dial: %w", err)
	}

	tr := &http3.Transport{TLSClientConfig: tlsCfg}
	cc := tr.NewClientConn(qc)

	return &h3Conn{
		node:    node,
		conn:    qc,
		cc:      cc,
		created: time.Now(),
	}, nil
}

// quicCfg 返回调优后的 QUIC 配置。
//
// 默认窗口（stream 512KB / 连接 512KB）对视频这种持续高带宽太窄：
// 每次窗口用满都要等对端发 MAX_STREAM_DATA，等于把吞吐锁在 BDP 以内。
// 这里放大到 8MB/64MB，并允许对端推满。
func quicCfg() *quic.Config {
	const (
		streamWin = 8 * 1024 * 1024   // 8MB  单流窗口
		connWin   = 64 * 1024 * 1024  // 64MB 整条连接窗口
	)
	return &quic.Config{
		HandshakeIdleTimeout: 8 * time.Second,
		MaxIdleTimeout:       h3IdleTimeout,
		KeepAlivePeriod:      25 * time.Second,

		// 流控窗口：这是视频卡顿最常见的原因
		InitialStreamReceiveWindow:     streamWin,
		MaxStreamReceiveWindow:         streamWin,
		InitialConnectionReceiveWindow: connWin,
		MaxConnectionReceiveWindow:     connWin,

		// 允许更多并发 stream（每个分片请求一个）
		MaxIncomingStreams:    -1,
		MaxIncomingUniStreams: -1,

		// 初始包大小显式给 1252：既避开部分路径 1280 的碎片风险，
		// 又让 PMTUD 有明确的起点继续往上探（上限通常是 1500）。
		InitialPacketSize: 1252,

		// 保留 PMTUD（默认 false）。关掉它只能发 1200 字节的包，
		// 反而让每个包少装 25% 数据，得不偿失。
		DisablePathMTUDiscovery: false,
	}
}

// resolveH3Addr 解析地址，遵守 -ip-mode
func resolveH3Addr(addr, mode string) (string, error) {
	host, port, err := net.SplitHostPort(addr)
	if err != nil {
		return "", err
	}
	switch strings.ToLower(mode) {
	case "v4", "ipv4":
		ips, err := net.DefaultResolver.LookupIP(context.Background(), "ip4", host)
		if err != nil || len(ips) == 0 {
			return "", fmt.Errorf("no A record for %s", host)
		}
		return net.JoinHostPort(ips[0].String(), port), nil
	case "v6", "ipv6":
		ips, err := net.DefaultResolver.LookupIP(context.Background(), "ip6", host)
		if err != nil || len(ips) == 0 {
			return "", fmt.Errorf("no AAAA record for %s", host)
		}
		return net.JoinHostPort(ips[0].String(), port), nil
	default:
		return addr, nil
	}
}

// ---------- 隧道 ----------

// openTunnel 在 QUIC 连接上开一个 CONNECT stream
//
// 用底层 RequestStream 而不是 RoundTrip：CONNECT 隧道需要同时读写同一个
// stream，而 RoundTrip 返回的 resp.Body 只能读，写要另找门路。
// RequestStream 实现了 Read/Write/Close/SetDeadline，正好当 net.Conn 用。
func (c *h3Conn) openTunnel(target string, pass *ProxyPass) (net.Conn, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)

	rs, err := c.cc.OpenRequestStream(ctx)
	if err != nil {
		cancel()
		return nil, fmt.Errorf("h3 open stream: %w", err)
	}

	u, _ := url.Parse("https://" + c.node.Addr() + "/")
	req := &http.Request{
		Method: http.MethodConnect,
		URL:    u,
		Host:   target,
		Header: make(http.Header),
	}
	// 普通 CONNECT（非扩展 CONNECT）：Proto 留空，quic-go 据此不加 :protocol
	req.ProtoMajor, req.ProtoMinor = 3, 0
	req.Header.Set("Proxy-Authorization", pass.Bearer())

	if err := rs.SendRequestHeader(req); err != nil {
		cancel()
		rs.CancelRead(0)
		rs.CancelWrite(0)
		return nil, fmt.Errorf("h3 send CONNECT: %w", err)
	}

	resp, err := rs.ReadResponse()
	if err != nil {
		cancel()
		rs.CancelRead(0)
		rs.CancelWrite(0)
		return nil, fmt.Errorf("h3 read CONNECT response: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(io.LimitReader(rs, 256))
		cancel()
		rs.CancelRead(0)
		rs.CancelWrite(0)
		msg := fmt.Sprintf("h3 connect rejected: %d %s %s",
			resp.StatusCode, resp.Status, strings.TrimSpace(string(body)))
		// 节点把无效 pass 报成 400 parsing JWT failed
		if resp.StatusCode == 401 || resp.StatusCode == 407 ||
			containsFold(string(body), "jwt") || containsFold(string(body), "unauthorized") {
			return nil, fmt.Errorf("%w: %s", errPassRejected, msg)
		}
		return nil, errors.New(msg)
	}

	return &h3StreamConn{rs: rs, cancel: cancel, pool: c, remote: target}, nil
}

// h3StreamConn 把 HTTP/3 CONNECT stream 适配成 net.Conn
type h3StreamConn struct {
	rs     *http3.RequestStream
	cancel context.CancelFunc
	pool   *h3Conn
	remote string

	once sync.Once
}

func (s *h3StreamConn) Read(b []byte) (int, error)  { return s.rs.Read(b) }
func (s *h3StreamConn) Write(b []byte) (int, error) { return s.rs.Write(b) }

func (s *h3StreamConn) Close() error {
	var err error
	s.once.Do(func() {
		if s.pool != nil {
			s.pool.release()
		}
		s.rs.CancelRead(0)
		err = s.rs.Close()
		if s.cancel != nil {
			s.cancel()
		}
	})
	return err
}

func (s *h3StreamConn) LocalAddr() net.Addr  { return h3Addr("h3-local") }
func (s *h3StreamConn) RemoteAddr() net.Addr { return h3Addr(s.remote) }

// SetDeadline 系列：
// pipe 会周期性地把 10 分钟空闲超时透传下来，但 QUIC stream 的 deadline
// 是绝对时间点、且设置后不会自动续期，透传反而会在长视频上误断。
// 连接回收交给 QUIC 自身的 MaxIdleTimeout + 切换时的 dropAll，这里忽略。
func (s *h3StreamConn) SetDeadline(t time.Time) error      { return nil }
func (s *h3StreamConn) SetReadDeadline(t time.Time) error  { return nil }
func (s *h3StreamConn) SetWriteDeadline(t time.Time) error { return nil }

type h3Addr string

func (a h3Addr) Network() string { return "h3" }
func (a h3Addr) String() string  { return string(a) }

// ---------- 对外入口 ----------

// dialViaH3 尝试用 HTTP/3 建隧道
func dialViaH3(node Node, target string, pm *PassManager) (net.Conn, error) {
	if !h3Enabled.Load() {
		return nil, errors.New("h3 已禁用")
	}
	pass := pm.Get()
	if pass == nil {
		return nil, errors.New("no valid pass")
	}

	c := h3p.pick(node, target)
	if c == nil {
		// 上限保护：避免目标极其分散时无限建连。
		// h3MaxConnsPerNode 条 × 64 路 = 可观的并发容量，正常浏览器用不满。
		if h3p.count(node.Host) >= h3MaxConnsPerNode {
			return nil, fmt.Errorf("h3 连接数已达上限 %d", h3MaxConnsPerNode)
		}
		var err error
		c, err = dialH3(node)
		if err != nil {
			// 节点不支持 h3，全局降级到 h1（避免每次重试都超时一次）
			log.Printf("[h3] %s 不可用，降级 HTTP/1.1: %v", node.Host, err)
			h3Disable()
			return nil, err
		}
		// 新建的连接先占一个 stream 名额
		if !c.acquire() {
			c.close()
			return nil, errors.New("h3 连接已满")
		}
		h3p.add(c)
		log.Printf("[h3] 新建 QUIC 连接 -> %s（单连接最多 %d 路复用）",
			node.Host, h3MaxStreamsPerConn)
	}

	conn, err := c.openTunnel(target, pass)
	if err != nil {
		c.release()
		if errors.Is(err, errPassRejected) {
			return nil, err
		}
		// 连接可能已损坏，摘除
		c.close()
		return nil, err
	}
	return conn, nil
}

// h3Reset 切换节点时清空所有 QUIC 连接
func h3Reset() int {
	h3PoolVersion.Add(1)
	return h3p.dropAll()
}

// h3FallbackHook 在 h3 降级到 HTTP/1.1 时被调用，
// 用来补启动 h1 预热池（启动时因为 h3 可用而跳过了它）。
var h3FallbackHook func()

// h3Disable 关闭 h3 并补启动 h1 预热池（只会执行一次）
func h3Disable() {
	if !h3Enabled.CompareAndSwap(true, false) {
		return // 已经关过了
	}
	if h3FallbackHook != nil {
		h3FallbackHook()
	}
}

// warmH3 启动时预热 QUIC 连接，省掉首批请求的握手。
//
// 预热 h3WarmConns 条而不是一条：单条连接 64 路打满后要现开新连接，
// 那一次握手（1-2 RTT）正好落在视频起播最敏感的时刻。
// 多预热一条几乎不占资源，却能把这处卡顿消掉。
func warmH3(node Node) {
	if !h3Enabled.Load() {
		return
	}
	go func() {
		ok := 0
		for i := 0; i < h3WarmConns; i++ {
			c, err := dialH3(node)
			if err != nil {
				if ok == 0 {
					// 第一条就失败，说明节点不支持 h3，整体降级
					log.Printf("[h3] 节点 %s 不支持 HTTP/3，改用 HTTP/1.1（%v）", node.Host, err)
					h3Disable()
				}
				return
			}
			h3p.add(c)
			ok++
		}
		log.Printf("[h3] QUIC 已就绪 -> %s（%d 条，共可复用 %d 路）",
			node.Host, ok, ok*h3MaxStreamsPerConn)
	}()
}

func containsFold(s, sub string) bool {
	return strings.Contains(strings.ToLower(s), strings.ToLower(sub))
}
