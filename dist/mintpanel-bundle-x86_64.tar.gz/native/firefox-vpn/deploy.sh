#!/bin/bash
# 部署并测试 ipp-gost
# 用法: ./deploy.sh
set -e
cd "$(dirname "$0")"

TOKEN=$(cd /root && ./kaggle-01.sh 'python3 -c "
import json
d=json.load(open(\"/root/.config/mozilla/firefox/f6pobjhu.default-release/signedInUser.json\"))
print(d[\"accountData\"][\"oauthTokens\"][\"https://identity.mozilla.com/apps/vpn|profile\"][\"token\"])
"' 2>/dev/null | tr -d '\r\n')

if [ -z "$TOKEN" ]; then
  echo "无法获取 FxA token" >&2
  exit 1
fi
echo "token 长度: ${#TOKEN}"

cd /root
tar cz ipp-gost | ./kaggle-01.sh 'mkdir -p /root/ipp-gost && cd /root && tar xz && cd ipp-gost && go build -o ipp-gost . 2>&1 | tail -20 && ls -lh ipp-gost'
