// ipp-gost: Firefox IP Protection (IPP) 反向代理客户端
//
// 协议: TLS 1.3 + HTTP CONNECT + Proxy-Authorization: Bearer <ProxyPass JWT>
// 认证: FxA access token -> GET /api/v1/fpn/token -> ProxyPass (JWT, 10min)
// 节点: Remote Settings collection "vpn-serverlist" (Fastly *:2499)
//
// 用法:
//
//	ipp-gost -fxa-token <token> -listen 127.0.0.1:1080 -node icn145.m1.fastly-masque.net
package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const (
	guardianBase  = "https://vpn.mozilla.org"
	serverListURL = "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/vpn-serverlist/records"
	// ProxyPass 提前 2 分钟轮换(与 Firefox 源码 ProxyPass.ROTATION_TIME 一致)
	rotateBefore = 2 * time.Minute
)

// ---------- ProxyPass ----------

type ProxyPass struct {
	Token string `json:"token"`
	Nbf   int64  `json:"-"`
	Exp   int64  `json:"-"`
}

type jwtClaims struct {
	Sub string `json:"sub"`
	Aud string `json:"aud"`
	Iat int64  `json:"iat"`
	Nbf int64  `json:"nbf"`
	Exp int64  `json:"exp"`
	Iss string `json:"iss"`
}

// parseJWTClaims 只解 payload, 不验签(客户端无需验签)
func parseJWTClaims(tok string) (*jwtClaims, error) {
	parts := strings.Split(tok, ".")
	if len(parts) != 3 {
		return nil, errors.New("invalid JWT: need 3 parts")
	}
	payload, err := b64Decode(parts[1])
	if err != nil {
		return nil, err
	}
	var c jwtClaims
	if err := json.Unmarshal(payload, &c); err != nil {
		return nil, err
	}
	return &c, nil
}

func (p *ProxyPass) Valid() bool {
	now := time.Now().Unix()
	return now >= p.Nbf && now < p.Exp
}

func (p *ProxyPass) ShouldRotate() bool {
	return time.Now().Unix() >= p.Exp-int64(rotateBefore.Seconds())
}

func (p *ProxyPass) Bearer() string { return "Bearer " + p.Token }

// ---------- Guardian 客户端 ----------

type Guardian struct {
	ts *TokenSource

	// netcfg 每次请求动态取，保证界面改代理后立即生效
	getNet func() *NetConfig
}

type Entitlement struct {
	UID              int64  `json:"uid"`
	Subscribed       bool   `json:"subscribed"`
	MaxBytes         string `json:"maxBytes"`
	LimitedBandwidth bool   `json:"limited_bandwidth"`
}

func NewGuardian(ts *TokenSource) *Guardian {
	cfg := DefaultNetConfig()
	return NewGuardianWithNet(ts, func() *NetConfig { return &cfg })
}

// NewGuardianWithNet 允许指定出站配置
//
// 重要：vpn.mozilla.org 有地区限制，在某些地区直连会返回
// 451 unavailable_in_region，必须让这一层也走代理。
//
// 这里保存的是取值函数而非固定 client：client 由 netcfg 现算，
// 所以界面里改代理会立即影响后续取 pass 的请求。
func NewGuardianWithNet(ts *TokenSource, getNet func() *NetConfig) *Guardian {
	return &Guardian{ts: ts, getNet: getNet}
}

// client 按当前 netcfg 构建 client
func (g *Guardian) client() *http.Client {
	if g.getNet != nil {
		if nc := g.getNet(); nc != nil {
			if c, err := nc.client(); err == nil {
				return c
			}
		}
	}
	return &http.Client{Timeout: 30 * time.Second}
}

func (g *Guardian) do(method, path string) (*http.Response, error) {
	tok, err := g.ts.Get()
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequest(method, guardianBase+path, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+tok)
	req.Header.Set("Content-Type", "application/json")
	return g.client().Do(req)
}

// Status 查询资格
func (g *Guardian) Status() (*Entitlement, error) {
	resp, err := g.do("GET", "/api/v1/fpn/status")
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	switch resp.StatusCode {
	case 200:
		var e Entitlement
		if err := json.Unmarshal(body, &e); err != nil {
			return nil, err
		}
		return &e, nil
	case 401:
		return nil, errors.New("401 unauthorized: FxA token rejected")
	case 403:
		return nil, errors.New("403 not entitled: no IPP subscription")
	case 404:
		return nil, errors.New("404 no entitlement: not an IPP user")
	case 451:
		return nil, errors.New("451 region unavailable")
	default:
		return nil, fmt.Errorf("unexpected status %d: %s", resp.StatusCode, body)
	}
}

// FetchPass 取 ProxyPass
func (g *Guardian) FetchPass() (*ProxyPass, error) {
	resp, err := g.do("GET", "/api/v1/fpn/token")
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 {
		if resp.StatusCode == 429 {
			return nil, fmt.Errorf("429 quota exceeded, retry-after=%s",
				resp.Header.Get("Retry-After"))
		}
		return nil, fmt.Errorf("fetch pass failed: %d %s", resp.StatusCode, body)
	}
	var raw struct {
		Token string `json:"token"`
	}
	if err := json.Unmarshal(body, &raw); err != nil {
		return nil, err
	}
	c, err := parseJWTClaims(raw.Token)
	if err != nil {
		return nil, err
	}
	return &ProxyPass{Token: raw.Token, Nbf: c.Nbf, Exp: c.Exp}, nil
}

// ---------- 服务器列表 ----------

type Server struct {
	Hostname    string `json:"hostname"`
	Port        int    `json:"port"`
	Quarantined bool   `json:"quarantined"`
}

type City struct {
	Code    string   `json:"code"`
	Name    string   `json:"name"`
	Servers []Server `json:"servers"`
}

type Country struct {
	Code   string `json:"code"`
	Name   string `json:"name"`
	Cities []City `json:"cities"`
}

func FetchServers() ([]Country, error) {
	resp, err := http.Get(serverListURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var data struct {
		Data []Country `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, err
	}
	return data.Data, nil
}

// ---------- Pass 管理器(自动轮换) ----------

type PassManager struct {
	g    *Guardian
	mu   sync.RWMutex
	pass *ProxyPass
	stop chan struct{}
}

func NewPassManager(g *Guardian) (*PassManager, error) {
	pm := &PassManager{g: g, stop: make(chan struct{})}
	if err := pm.rotate(); err != nil {
		// 不致命：先启动，后台循环会继续重试
		// （常见原因：vpn.mozilla.org 地区限制 451，需要配 -login-proxy）
		log.Printf("[warn] 首次获取 pass 失败: %v", err)
		log.Printf("[warn] 将继续在后台重试；若为 451 地区限制，请用 -login-proxy 指定代理")
		go pm.loop()
		return pm, nil
	}
	go pm.loop()
	return pm, nil
}

func (pm *PassManager) rotate() error {
	p, err := pm.g.FetchPass()
	if err != nil {
		return err
	}
	pm.mu.Lock()
	pm.pass = p
	pm.mu.Unlock()
	lifetime := time.Duration(p.Exp-p.Nbf) * time.Second
	log.Printf("[pass] 获取成功 有效期=%v exp=%s", lifetime,
		time.Unix(p.Exp, 0).Format("15:04:05"))
	return nil
}

func (pm *PassManager) loop() {
	t := time.NewTicker(30 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-pm.stop:
			return
		case <-t.C:
			// 先确保 access token 不过期（与 Firefox 同步）
			if _, err := pm.g.ts.Get(); err != nil {
				log.Printf("[auth] token 续期失败: %v", err)
			}

			pm.mu.RLock()
			need := pm.pass == nil || pm.pass.ShouldRotate()
			pm.mu.RUnlock()
			if need {
				if err := pm.rotate(); err != nil {
					log.Printf("[pass] 轮换失败: %v", err)
				}
			}
		}
	}
}

func (pm *PassManager) Get() *ProxyPass {
	pm.mu.RLock()
	defer pm.mu.RUnlock()
	return pm.pass
}

// Refresh 强制重取一次 pass（界面改完代理后调用）
//
// 返回 nil 说明新配置能用；否则把错误原样带回去给界面展示
// （比如 451 就是代理所在地也被限制）。
func (pm *PassManager) Refresh() error {
	if pm == nil {
		return errors.New("pass 管理器未初始化")
	}
	return pm.rotate()
}

func (pm *PassManager) Close() { close(pm.stop) }

// ---------- 隧道拨号 ----------

type Dialer struct {
	ns   *NodeSwitch
	port int
	pm   *PassManager
	res  *resolver // 目标地址解析策略（IPv4/IPv6 出口）
}

// node 当前节点（每次拨号时读取，支持热切换）
func (d *Dialer) node() Node { return d.ns.Current() }

// Dial 通过当前 IPP 节点建立到 target 的隧道
func (d *Dialer) Dial(target string) (net.Conn, error) {
	// 按策略解析（IPv4/IPv6 强制）
	// 解析失败时继续用原域名（auto/remote 本来就不解析）
	if d.res != nil {
		if t2, err := d.res.Resolve(target); err == nil && t2 != "" {
			target = t2
		}
	}
	return dialViaNode(d.node(), target, d.pm)
}

// dialViaNode 通过指定节点建到 target 的隧道
//
// 抽出来是为了能在切换前先探测新节点（probe.go 的 testNode 会调它）。
// pass 被拒（401/407）时自动刷新 pass 并重试一次——
// 这覆盖了 pass 轮换瞬间的请求，避免偶发 502。
func dialViaNode(node Node, target string, pm *PassManager) (net.Conn, error) {
	c, err := dialViaNodeOnce(node, target, pm)
	if err == nil {
		return c, nil
	}
	if !errors.Is(err, errPassRejected) {
		return nil, err
	}

	// pass 被拒：强制刷新后重试一次
	log.Printf("[pass] 被拒（%v），刷新后重试", err)
	if rerr := pm.Refresh(); rerr != nil {
		log.Printf("[pass] 刷新失败: %v", rerr)
		return nil, err
	}
	return dialViaNodeOnce(node, target, pm)
}

// dialViaNodeOnce 单次尝试（不重试）
func dialViaNodeOnce(node Node, target string, pm *PassManager) (net.Conn, error) {
	pass := pm.Get()
	if pass == nil {
		return nil, errors.New("no valid pass")
	}

	// 首选 HTTP/3：一条 QUIC 连接上开多个 CONNECT stream，
	// 并发多分片（视频）时只握手一次，比 h1 每目标一条 TLS 快很多。
	if h3Enabled.Load() {
		c, err := dialViaH3(node, target, pm)
		if err == nil {
			return c, nil
		}
		if errors.Is(err, errPassRejected) {
			return nil, err
		}
		// h3 失败就静默回退到 HTTP/1.1 路径，不影响可用性
	}

	// 退路：优先用预热好的外层 TLS 连接，省掉 TCP + TLS 握手（约 1 RTT）
	//
	// 注意：一条外层 HTTP/1.1 连接只能承载一个目标（不能跨目标复用），
	// 所以这里取到的连接消费掉就作废，绝不会再放回池里。
	if tconn := warmer.Take(node); tconn != nil {
		c, err := connectOver(tconn, target, pass)
		if err == nil {
			return c, nil
		}
		// 预热的连接可能已失效（节点侧超时关闭），回退到新建
		tconn.Close()
		// pass 被拒就不必再新建连接了，直接往上抛
		if errors.Is(err, errPassRejected) {
			return nil, err
		}
	} else {
		// 池空（并发尖峰或刚启动），只能新建，记一笔便于调参
		burstNoteMiss()
	}

	// 新建：TCP + 外层 TLS
	burstEnter()
	tconn2, err := dialNodeTLS(node)
	burstLeave()
	if err != nil {
		return nil, err
	}
	c, err := connectOver(tconn2, target, pass)
	if err != nil {
		tconn2.Close()
		return nil, err
	}
	return c, nil
}

// dialNodeTLS 建一条到节点的外层 TLS 连接（不做 CONNECT）
func dialNodeTLS(node Node) (*tls.Conn, error) {
	addr := node.Addr()
	raw, err := dialNode(node.Host, addr, 15*time.Second, GlobalNodeIP.Get())
	if err != nil {
		return nil, fmt.Errorf("dial node (%s): %w", GlobalNodeIP.Get(), err)
	}

	// 小包立即发送，对交互式浏览有感知提升
	if tc, ok := raw.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
		_ = tc.SetKeepAlive(true)
		_ = tc.SetKeepAlivePeriod(30 * time.Second)
		// 加大 socket 缓冲，提升大流量（视频）吞吐。
		// 内核会按 net.ipv4.tcp_{r,w}mem 上限自动翻倍，失败不影响功能。
		_ = tc.SetReadBuffer(256 * 1024)
		_ = tc.SetWriteBuffer(256 * 1024)
	}

	tconn := tls.Client(raw, &tls.Config{
		ServerName: node.Host,
		MinVersion: tls.VersionTLS12,
		// 节点支持 h2 握手但不接受 h2 CONNECT（400 Invalid CONNECT request），
		// 与 Firefox 保持一致走 HTTP/1.1
		NextProtos: []string{"http/1.1"},
	})
	if err := tconn.Handshake(); err != nil {
		raw.Close()
		return nil, fmt.Errorf("tls handshake: %w", err)
	}
	return tconn, nil
}

// connectOver 在已握手的 TLS 连接上发 CONNECT vtarget
// errPassRejected 表示节点拒绝了 ProxyPass（401/407），需要换新的 pass 重试
var errPassRejected = errors.New("pass 被拒，需刷新")

func connectOver(tconn *tls.Conn, target string, pass *ProxyPass) (net.Conn, error) {
	// 发 CONNECT
	req := fmt.Sprintf("CONNECT %s HTTP/1.1\r\nHost: %s\r\n"+
		"Proxy-Authorization: %s\r\n\r\n", target, target, pass.Bearer())
	if _, err := tconn.Write([]byte(req)); err != nil {
		return nil, err
	}

	// 读响应头(必须逐字节, 避免吞掉隧道数据)
	br := bufio.NewReaderSize(tconn, pipeBufSize)
	resp, err := http.ReadResponse(br, &http.Request{Method: "CONNECT"})
	if err != nil {
		return nil, fmt.Errorf("read connect response: %w", err)
	}
	if resp.StatusCode != 200 {
		// 401/407 = pass 过期或无效，与网络故障区分开，便于上层重试
		if resp.StatusCode == 401 || resp.StatusCode == 407 {
			return nil, fmt.Errorf("%w: %d %s", errPassRejected, resp.StatusCode, resp.Status)
		}
		return nil, fmt.Errorf("connect rejected: %d %s", resp.StatusCode, resp.Status)
	}

	// br 可能已缓冲了隧道数据, 包一层
	if br.Buffered() > 0 {
		return &bufferedConn{Conn: tconn, r: br}, nil
	}
	return tconn, nil
}

type bufferedConn struct {
	net.Conn
	r *bufio.Reader
}

func (c *bufferedConn) Read(b []byte) (int, error) { return c.r.Read(b) }

// ---------- 本地代理服务 ----------

type Proxy struct {
	d        *Dialer
	port     int
	accepted atomic.Int64
	errors   atomic.Int64
	active   atomic.Int64 // 当前活跃隧道数
	bytesIn  atomic.Int64 // 累计下行字节（目标站 -> 客户端）
	bytesOut atomic.Int64 // 累计上行字节（客户端 -> 目标站）

	// 切换节点时用于排空：登记活跃连接，必要时强制断开
	connMu  sync.Mutex
	conns   map[int64]net.Conn
	connSeq atomic.Int64

	// 关闸：切换节点期间暂停接入新连接
	// RWMutex 读写语义：正常请求持读锁，切换时拿写锁，
	// 写锁到手即代表"没有请求在途"（读锁已全部释放）。
	gate     sync.RWMutex
	gating   atomic.Bool // 是否处于关闸状态（仅用于展示/日志）
}

// track 登记活跃连接，返回注销函数
func (p *Proxy) track(c net.Conn) func() {
	id := p.connSeq.Add(1)
	p.connMu.Lock()
	if p.conns == nil {
		p.conns = make(map[int64]net.Conn)
	}
	p.conns[id] = c
	p.connMu.Unlock()
	return func() {
		p.connMu.Lock()
		delete(p.conns, id)
		p.connMu.Unlock()
	}
}

// CloseAll 强制断开所有活跃连接，返回断开数量
func (p *Proxy) CloseAll() int {
	p.connMu.Lock()
	conns := make([]net.Conn, 0, len(p.conns))
	for _, c := range p.conns {
		conns = append(conns, c)
	}
	p.connMu.Unlock()

	for _, c := range conns {
		c.Close()
	}
	return len(conns)
}

// Gating 当前是否处于切换关闸中
func (p *Proxy) Gating() bool { return p.gating.Load() }

// DrainAndSwitch 关闸断连后执行切换（不等待排空，追求切换速度）
//
// 顺序不能颠倒：
//  1. 关闸      —— 拦住新连接，避免它们继续在当前节点建隧道
//  2. 停预热    —— 预热池里的空闲连接同样属于"当前节点"
//  3. 排空      —— 等活跃隧道自然结束；超时强制断开
//  4. 确认归零  —— 必须为 0 才继续
//  5. 切换节点
//  6. 预热新节点
//  7. 开闸
//
// 这样任意时刻不会有"新旧节点隧道并存"，Mozilla 侧不会看到
// 同一账号同时在两个地方建立连接。
func (p *Proxy) DrainAndSwitch(doSwitch func() error) (DrainInfo, error) {
	info := DrainInfo{Before: p.active.Load()}

	// 1. 关闸：等所有在途请求释放读锁
	p.gating.Store(true)
	gateCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	locked := make(chan struct{})
	go func() {
		p.gate.Lock()
		close(locked)
	}()
	select {
	case <-locked:
	case <-gateCtx.Done():
		p.gating.Store(false)
		return info, fmt.Errorf("关闸超时，放弃切换")
	}

	// 2. 停预热（预热连接也是当前节点的隧道）
	if warmer != nil {
		warmer.Pause()
	}

	// 3. 直接断开旧连接，不排队等待。
	//    用户要求切换要快：旧隧道立刻失效，客户端自行重连到新节点。
	//    等待排空会让视频这类长连接把切换拖到 8 秒以上，体验很差；
	//    断开后浏览器会重发请求，走新节点，只是有一下下卡顿。
	if n := p.CloseAll(); n > 0 {
		log.Printf("[switch] 直接断开 %d 条旧隧道", n)
		info.Forced = true
	}
	info.After = p.active.Load()

	// 4. 切换
	var serr error
	serr = doSwitch()

	// 5. 恢复（无论成功失败都要开闸，否则服务永久卡死）
	if warmer != nil {
		warmer.Resume()
	}
	p.gate.Unlock()
	p.gating.Store(false)

	return info, serr
}

// DrainInfo 排空统计
type DrainInfo struct {
	Before int64
	After  int64
	Forced bool
}

// maxTunnels 最大并发隧道数
//
// 超过后新连接直接被拒，防止目标站异常/客户端泄露导致内存耗尽。
// 普通浏览很少超过 50，给 256 留足余量。
const maxTunnels = 256

func (p *Proxy) Serve(l net.Listener) error {
	for {
		c, err := l.Accept()
		if err != nil {
			return err
		}
		p.accepted.Add(1)
		go p.handle(c)
	}
}

// TotalConns 累计接受连接数
func (p *Proxy) TotalConns() int64 { return p.accepted.Load() }

// TotalErrs 累计错误数
func (p *Proxy) TotalErrs() int64 { return p.errors.Load() }

// ActiveCount 当前活跃隧道数
func (p *Proxy) ActiveCount() int64 { return p.active.Load() }

func (p *Proxy) handle(c net.Conn) {
	defer c.Close()

	// 切换节点关闸期间，新连接等待；超时直接返回 503 让客户端重试
	if p.gating.Load() {
		waitCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		acq := make(chan struct{})
		go func() {
			p.gate.RLock()
			close(acq)
		}()
		select {
		case <-acq:
			p.gate.RUnlock()
		case <-waitCtx.Done():
			go func() {
				<-acq
				p.gate.RUnlock()
			}()
			cancel()
			p.errors.Add(1)
			c.Write([]byte("HTTP/1.1 503 Service Unavailable\r\nRetry-After: 2\r\n\r\n"))
			return
		}
		cancel()
	}

	// 并发隧道上限，防止异常情况把内存吃满
	if n := p.active.Add(1); n > maxTunnels {
		p.active.Add(-1)
		p.errors.Add(1)
		c.Write([]byte("HTTP/1.1 503 Service Unavailable\r\nRetry-After: 1\r\n\r\n"))
		return
	}
	defer p.active.Add(-1)
	defer p.track(c)()

	// 本地侧同样调优：关 Nagle、加大缓冲，避免成为瓶颈
	if tc, ok := c.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
		_ = tc.SetReadBuffer(256 * 1024)
		_ = tc.SetWriteBuffer(256 * 1024)
	}

	// 握手阶段给 30 秒；进入 pipe 后由空闲超时接管
	c.SetDeadline(time.Now().Add(30 * time.Second))

	// 读缓冲给大：这个 br 后面会传给 pipe 当上行源，
	// 默认 4KB 会让 pipe 的 128KB 缓冲形同虚设（每次只能拿到 ≤4KB）。
	br := bufio.NewReaderSize(c, pipeBufSize)

	// 协议嗅探：0x05 = SOCKS5，否则当 HTTP
	// （HTTP 方法首字节都是字母，不会撞车）
	if isSOCKS5(br) {
		p.handleSOCKS5(c, br)
		return
	}

	req, err := http.ReadRequest(br)
	if err != nil {
		p.errors.Add(1)
		return
	}

	// CONNECT 模式(HTTPS)
	if req.Method == "CONNECT" {
		target := req.Host
		if !strings.Contains(target, ":") {
			target += ":443"
		}
		up, err := p.d.Dial(target)
		if err != nil {
			p.errors.Add(1)
			c.Write([]byte("HTTP/1.1 502 Bad Gateway\r\n\r\n"))
			return
		}
		defer up.Close()

		c.Write([]byte("HTTP/1.1 200 Connection Established\r\n\r\n"))
		pipeCount(c, br, up, &p.bytesIn, &p.bytesOut)
		return
	}

	// 普通 HTTP 请求: 连目标后转发
	target := req.Host
	if !strings.Contains(target, ":") {
		target += ":80"
	}
	up, err := p.d.Dial(target)
	if err != nil {
		p.errors.Add(1)
		c.Write([]byte("HTTP/1.1 502 Bad Gateway\r\n\r\n"))
		return
	}
	defer up.Close()

	if err := req.Write(up); err != nil {
		return
	}
	io.Copy(c, up)
}

// idleTimeout 隧道空闲多久后关闭
//
// 之前是一个死的 10 分钟 SetDeadline，会把长连接（视频流、WebSocket
// 心跳间隔长的页面）误杀。改成真正的“空闲”判定：
// 有数据流动就续命，连续 idleTimeout 没数据才断。
const idleTimeout = 10 * time.Minute

// 转发缓冲区大小。视频（YouTube 4K 码率可达 40~80 Mbps）下，
// 32KB 太碎：一次 Read 常常只拿满一点，拷贝次数多、系统调用密集。
// 128KB 是内存占用与吞吐的平衡点（每连接双向共 256KB）。
const pipeBufSize = 128 * 1024

// deadline 续期的最小间隔。
// 原来每读写一次就 SetDeadline 两次（2 次 syscall），
// 1GB 传输 ≈ 13 万次多余 syscall，是视频卡顿的隐形原因。
// 改为按时间节流：1 秒内只续一次，长连接的活跃性与之前完全等价
// （idleTimeout 是 10 分钟，1 秒的精度绰绰有余）。
const deadlineRefresh = time.Second

// pipe 双向转发，带空闲超时
func pipe(c net.Conn, br *bufio.Reader, up net.Conn) {
	pipeCount(c, br, up, nil, nil)
}

// pipeCount 与 pipe 相同，额外把上下行字节数记到计数器里
// （down = 目标站 -> 客户端，up = 客户端 -> 目标站）
func pipeCount(c net.Conn, br *bufio.Reader, up net.Conn,
	down, upCnt *atomic.Int64) {
	var wg sync.WaitGroup
	wg.Add(2)

	// 节流式续期：多 goroutine（上行/下行）共享，用原子时间戳避免竞争
	var lastTouch atomic.Int64
	touchNow := func() {
		now := time.Now()
		last := time.Unix(0, lastTouch.Load())
		if now.Sub(last) < deadlineRefresh {
			return
		}
		// CAS 抢占续期权，避免两个方向同时 set
		if !lastTouch.CompareAndSwap(last.UnixNano(), now.UnixNano()) {
			return
		}
		d := now.Add(idleTimeout)
		c.SetDeadline(d)
		up.SetDeadline(d)
	}
	touchNow()

	// drain 把 src 拷到 dst，共用一块缓冲
	drain := func(dst io.Writer, src io.Reader, cnt *atomic.Int64) {
		defer wg.Done()
		buf := make([]byte, pipeBufSize)
		for {
			n, err := src.Read(buf)
			if n > 0 {
				touchNow()
				if _, werr := dst.Write(buf[:n]); werr != nil {
					return
				}
				if cnt != nil {
					cnt.Add(int64(n))
				}
			}
			if err != nil {
				return
			}
		}
	}

	// 上行：先发货 br 里残留的字节（CONNECT 请求后有极少量可能），
	// 之后绕过 br 直接读连接，避免多一层 4KB 中转拷贝。
	go func() {
		if br != nil && br.Buffered() > 0 {
			if n, err := io.CopyN(up, br, int64(br.Buffered())); err == nil {
				if upCnt != nil && n > 0 {
					upCnt.Add(n)
				}
			}
		}
		drain(up, c, upCnt)
	}()
	go drain(c, up, down)
	wg.Wait()
}

// ---------- 工具 ----------

func b64Decode(s string) ([]byte, error) {
	// JWT 用 base64url, 无 padding
	return base64.RawURLEncoding.DecodeString(s)
}

// ---------- main ----------

