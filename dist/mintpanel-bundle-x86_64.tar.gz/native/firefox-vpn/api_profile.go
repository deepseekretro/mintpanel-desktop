package main

// api_profile.go: Firefox profile 目录的发现与切换
//
// 跨平台场景：客户端跑在 Windows 上时，profile 在
//   %APPDATA%\Mozilla\Firefox\Profiles\xxxx.default-release\
// 跑在 Linux 上时在 ~/.config/mozilla/firefox/...
//
// 界面需要：
//   GET  /api/profiles        列出所有找到的 profile
//   POST /api/profile         切换/验证指定的 profile 目录

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"time"
)

// profileInfo 一个候选 profile
type profileInfo struct {
	// Root 用户能给的那个根目录（可能含多个 profile 子目录）
	Path string `json:"path"`
	// SignedInUserPath 实际定位到的 signedInUser.json
	SignedInUserPath string `json:"signedInUserPath,omitempty"`
	// HasToken 该 profile 里是否有 sessionToken
	HasToken bool `json:"hasToken"`
	// Email 已登录账号（可选）
	Email string `json:"email,omitempty"`
	// ModTime 文件修改时间
	ModTime string `json:"modTime,omitempty"`
	// Source 来源：auto（自动扫描）/ custom（用户指定）
	Source string `json:"source"`
}

// discoverProfiles 扫描所有已知位置，返回可用 profile 列表
func discoverProfiles() ([]profileInfo, []string) {
	var found []profileInfo
	var scanned []string
	seen := map[string]bool{}

	roots := defaultProfileRoots()
	for _, root := range roots {
		scanned = append(scanned, root)

		// 一次扫描出 root 下所有 signedInUser.json
		patterns := []string{
			filepath.Join(root, "signedInUser.json"),
			filepath.Join(root, "*", "signedInUser.json"),
		}
		for _, pat := range patterns {
			matches, _ := filepath.Glob(pat)
			for _, m := range matches {
				if seen[m] {
					continue
				}
				seen[m] = true

				info := profileInfo{
					Path:             filepath.Dir(m),
					SignedInUserPath: m,
					Source:           "auto",
				}
				si, err := os.Stat(m)
				if err == nil {
					info.ModTime = si.ModTime().Format("2006-01-02 15:04")
				}
				// 读一下有没有 token
				var su signedInUser
				if data, err := os.ReadFile(m); err == nil {
					if json.Unmarshal(data, &su) == nil {
						info.HasToken = su.AccountData.SessionToken != ""
						info.Email = su.AccountData.Email
					}
				}
				found = append(found, info)
			}
		}
	}

	// 有 token 的排前面，然后按修改时间倒序
	sort.Slice(found, func(i, j int) bool {
		if found[i].HasToken != found[j].HasToken {
			return found[i].HasToken
		}
		return found[i].ModTime > found[j].ModTime
	})

	return found, scanned
}

// resolveProfilePath 验证用户给的路径并定位 signedInUser.json
//
// 接受三种输入：
//   - profile 目录本身（含 signedInUser.json）
//   - profile 根目录（含 xxxx.default-release/ 子目录）
//   - signedInUser.json 文件路径
func resolveProfilePath(p string) (*profileInfo, error) {
	p = strings.TrimSpace(p)
	p = strings.Trim(p, `"'`) // 去掉 Windows 复制路径常带的引号
	if p == "" {
		return nil, os.ErrNotExist
	}

	// Windows 路径在本机（非 Windows）上没法访问，给个明确提示
	if runtime.GOOS != "windows" && len(p) > 1 && p[1] == ':' {
		// 可能是 WSL 里贴了 Windows 路径，尝试转换
		if conv := winPathToWSL(p); conv != "" {
			if _, err := os.Stat(conv); err == nil {
				p = conv
			}
		}
	}

	// 若给的是文件
	if strings.HasSuffix(strings.ToLower(p), "signedinuser.json") {
		if _, err := os.Stat(p); err != nil {
			return nil, err
		}
		p = filepath.Dir(p)
	}

	abs, err := filepath.Abs(p)
	if err == nil {
		p = abs
	}

	info := &profileInfo{Path: p, Source: "custom"}

	if f, err := findSignedInUser(p); err == nil {
		info.SignedInUserPath = f
		if si, err := os.Stat(f); err == nil {
			info.ModTime = si.ModTime().Format("2006-01-02 15:04")
		}
		var su signedInUser
		if data, err := os.ReadFile(f); err == nil {
			if json.Unmarshal(data, &su) == nil {
				info.HasToken = su.AccountData.SessionToken != ""
				info.Email = su.AccountData.Email
			}
		}
		return info, nil
	}

	// 没找到文件，但目录存在 —— 提示清楚
	if st, err := os.Stat(p); err == nil && st.IsDir() {
		return info, os.ErrNotExist
	}
	return nil, os.ErrNotExist
}

// winPathToWSL 把 C:\Users\x\... 转成 /mnt/c/Users/x/...
func winPathToWSL(p string) string {
	if len(p) < 3 || p[1] != ':' {
		return ""
	}
	drive := strings.ToLower(string(p[0]))
	rest := strings.ReplaceAll(p[2:], `\`, "/")
	return "/mnt/" + drive + rest
}

// ---------- HTTP ----------

func (a *AdminServer) handleProfiles(w http.ResponseWriter, r *http.Request) {
	found, scanned := discoverProfiles()

	type resp struct {
		Profiles []profileInfo `json:"profiles"`
		Scanned  []string      `json:"scanned"`
		OS       string        `json:"os"`
		Home     string        `json:"home"`
		Current  string        `json:"current"`
	}
	out := resp{Profiles: found, Scanned: scanned, OS: runtime.GOOS}
	out.Home, _ = os.UserHomeDir()
	if a.tr != nil && a.tr.ts != nil {
		out.Current = a.tr.ts.path
	}
	if out.Profiles == nil {
		out.Profiles = []profileInfo{}
	}
	writeJSON(w, out)
}

func (a *AdminServer) handleProfileSet(w http.ResponseWriter, r *http.Request) {
	if a.tr == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "未启用"})
		return
	}

	var req struct {
		Path string `json:"path"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": "参数错误"})
		return
	}

	info, err := resolveProfilePath(req.Path)
	if err != nil {
		msg := "路径无效或里面没有 signedInUser.json"
		if info != nil && info.Path != "" {
			msg = "目录存在，但没找到 signedInUser.json：" + info.Path
		}
		writeJSON(w, map[string]any{"ok": false, "error": msg})
		return
	}

	if !info.HasToken {
		writeJSON(w, map[string]any{
			"ok":    false,
			"error": "找到 signedInUser.json，但里面没有 sessionToken（该 profile 未登录 Firefox 账号）",
		})
		return
	}

	// 用新 profile 重建 TokenSource
	ts, err := NewTokenSourceWithNet("", info.Path, a.tr.getNet)
	if err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
		return
	}
	if _, err := ts.Get(); err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": "读取 token 失败: " + err.Error()})
		return
	}

	a.tr.ts = ts
	a.tr.lastErr = ""
	writeJSON(w, map[string]any{"ok": true, "profile": info, "status": a.tr.Status()})
}

var _ = time.Now
