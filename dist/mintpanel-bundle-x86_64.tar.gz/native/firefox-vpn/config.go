package main

// config.go: 本地配置文件（含加密的 sessionToken）
//
// 配置文件位置：
//   Windows : %APPDATA%\ipp-gost\config.json
//   Linux   : $XDG_CONFIG_HOME/ipp-gost/config.json（默认 ~/.config/ipp-gost）
//   macOS   : ~/Library/Application Support/ipp-gost/config.json
//
// sessionToken 属于账号级凭证（可无限换取 access token，消耗月度额度），
// 因此绝不落盘明文：
//   Windows : DPAPI（CryptProtectData，绑定当前用户，拷走也无法解密）
//   Linux   : machine-id + 用户名 派生密钥，AES-256-GCM
//   macOS   : 同 Linux（未做 Keychain 集成）
//
// 若用户显式选择 tokenCipher=plain 才会明文保存（不推荐，界面上有提示）。

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
)

// Config 持久化配置。字段省略空值时保持默认行为。
type Config struct {
	// Profile Firefox profile 目录（或其父目录）
	Profile string `json:"profile,omitempty"`
	// LoginProxy 登录（出站）代理，输 nodeIP 时用它连 Mozilla 登录接口
	LoginProxy string `json:"loginProxy,omitempty"`
	// Listen 本地代理监听地址
	Listen string `json:"listen,omitempty"`
	// IPMode 出口 IP 策略：auto/ipv4/ipv6/remote
	IPMode string `json:"ipMode,omitempty"`
	// NodeIP 连节点用的 IP 族：auto/ipv4/ipv6
	NodeIP string `json:"nodeIP,omitempty"`
	// Warm 预热池条数
	Warm int `json:"warm,omitempty"`
	// Node 上次使用的节点主机名
	Node string `json:"node,omitempty"`
	// NodePort 节点端口
	NodePort int `json:"nodePort,omitempty"`

	// SaveToken 是否记住登录（加密保存 sessionToken）
	SaveToken bool `json:"saveToken"`
	// TokenCipher 保存方式：auto/dpapi/aes/plain/none
	TokenCipher string `json:"tokenCipher,omitempty"`
	// SessionTokenEnc 加密后的 sessionToken（base64）
	SessionTokenEnc string `json:"sessionTokenEnc,omitempty"`
	// SessionTokenPlain 仅当 TokenCipher=plain 时使用
	SessionTokenPlain string `json:"sessionTokenPlain,omitempty"`
}

// 配置管理（全局单例）
var (
	cfgMu   sync.RWMutex
	cfgCur  Config
	cfgPath string
)

// ConfigPath 返回配置文件路径（不存在则返回默认路径）
func ConfigPath() string {
	cfgMu.RLock()
	p := cfgPath
	cfgMu.RUnlock()
	if p != "" {
		return p
	}
	return defaultConfigPath()
}

func defaultConfigPath() string {
	var dir string
	switch runtime.GOOS {
	case "windows":
		dir = os.Getenv("APPDATA")
		if dir == "" {
			if h, err := os.UserHomeDir(); err == nil {
				dir = filepath.Join(h, "AppData", "Roaming")
			}
		}
	case "darwin":
		if h, err := os.UserHomeDir(); err == nil {
			dir = filepath.Join(h, "Library", "Application Support")
		}
	default:
		dir = os.Getenv("XDG_CONFIG_HOME")
		if dir == "" {
			if h, err := os.UserHomeDir(); err == nil {
				dir = filepath.Join(h, ".config")
			}
		}
	}
	if dir == "" {
		dir = "."
	}
	return filepath.Join(dir, "ipp-gost", "config.json")
}

// SetConfigPath 覆盖配置路径（-config 参数）
func SetConfigPath(p string) {
	cfgMu.Lock()
	cfgPath = p
	cfgMu.Unlock()
}

// LoadConfig 读取配置。文件不存在不算错误（返回零值）。
func LoadConfig() (Config, error) {
	p := ConfigPath()
	b, err := os.ReadFile(p)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return Config{}, nil
		}
		return Config{}, fmt.Errorf("读取配置失败: %w", err)
	}
	var c Config
	if err := json.Unmarshal(b, &c); err != nil {
		return Config{}, fmt.Errorf("配置格式错误: %w", err)
	}
	return c, nil
}

// SaveConfig 原子写入配置文件（0600 权限）
func SaveConfig(c Config) error {
	p := ConfigPath()
	if err := os.MkdirAll(filepath.Dir(p), 0o700); err != nil {
		return fmt.Errorf("创建配置目录失败: %w", err)
	}
	b, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	tmp := p + ".tmp"
	// 0600: 仅本用户可读写
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return fmt.Errorf("写入配置失败: %w", err)
	}
	if err := os.Rename(tmp, p); err != nil {
		os.Remove(tmp)
		return fmt.Errorf("保存配置失败: %w", err)
	}
	return nil
}

// ---------- 全局访问 ----------

// GetConfig 返回内存中的当前配置副本
func GetConfig() Config {
	cfgMu.RLock()
	defer cfgMu.RUnlock()
	return cfgCur
}

// UpdateConfig 修改配置并落盘
func UpdateConfig(fn func(*Config)) error {
	cfgMu.Lock()
	fn(&cfgCur)
	c := cfgCur
	cfgMu.Unlock()
	return SaveConfig(c)
}

// InitConfig 启动时调用：加载配置文件到内存
func InitConfig(path string) (Config, error) {
	if path != "" {
		SetConfigPath(path)
	}
	c, err := LoadConfig()
	if err != nil {
		return c, err
	}
	cfgMu.Lock()
	cfgCur = c
	cfgMu.Unlock()
	return c, nil
}

// ---------- sessionToken 加解密 ----------

const (
	cipherAuto  = "auto"
	cipherDPAPI = "dpapi"
	cipherAES   = "aes"
	cipherPlain = "plain"
	cipherNone  = "none"
)

// errNoCipher 当前平台没有可用的加密后端
var errNoCipher = errors.New("当前平台没有可用的加密后端")

// effectiveCipher 解析实际使用的加密方式
func effectiveCipher(mode string) string {
	mode = strings.ToLower(strings.TrimSpace(mode))
	switch mode {
	case cipherDPAPI:
		if runtime.GOOS == "windows" {
			return cipherDPAPI
		}
		return cipherAES
	case cipherAES:
		return cipherAES
	case cipherPlain:
		return cipherPlain
	case cipherNone, "":
		return cipherNone
	default: // auto 及其它
		if runtime.GOOS == "windows" {
			return cipherDPAPI
		}
		return cipherAES
	}
}

// SaveSessionToken 按配置加密保存 sessionToken。
// 若 SaveToken=false 则清除已保存的 token。
func SaveSessionToken(tok string, mode string, remember bool) error {
	tok = strings.TrimSpace(tok)
	if !remember || tok == "" {
		return UpdateConfig(func(c *Config) {
			c.SaveToken = false
			c.SessionTokenEnc = ""
			c.SessionTokenPlain = ""
		})
	}
	use := effectiveCipher(mode)
	enc, plain := "", ""
	switch use {
	case cipherPlain:
		plain = tok
	case cipherNone:
		return UpdateConfig(func(c *Config) {
			c.SaveToken = true
			c.TokenCipher = cipherNone
			c.SessionTokenEnc = ""
			c.SessionTokenPlain = ""
		})
	default:
		e, err := encryptSecret(tok, use)
		if err != nil {
			return err
		}
		enc = e
	}
	return UpdateConfig(func(c *Config) {
		c.SaveToken = true
		c.TokenCipher = use
		c.SessionTokenEnc = enc
		c.SessionTokenPlain = plain
	})
}

// LoadedSessionToken 取出并解密已保存的 sessionToken（无则返回空）
func LoadedSessionToken() (string, error) {
	c := GetConfig()
	if !c.SaveToken {
		return "", nil
	}
	switch effectiveCipher(c.TokenCipher) {
	case cipherPlain:
		return c.SessionTokenPlain, nil
	case cipherNone:
		return "", nil
	}
	if c.SessionTokenEnc == "" {
		return "", nil
	}
	return decryptSecret(c.SessionTokenEnc, effectiveCipher(c.TokenCipher))
}

// ---------- 平台实现 ----------

// encryptSecret 加密（use=dpapi 或 aes）
func encryptSecret(plain, use string) (string, error) {
	switch use {
	case cipherDPAPI:
		return dpapiEncrypt(plain)
	case cipherAES:
		return aesEncrypt(plain, localKey())
	}
	return "", errNoCipher
}

// decryptSecret 解密
func decryptSecret(enc, use string) (string, error) {
	switch use {
	case cipherDPAPI:
		return dpapiDecrypt(enc)
	case cipherAES:
		return aesDecrypt(enc, localKey())
	}
	return "", errNoCipher
}

// localKey 由 machine-id + 用户名 + 固定盐 派生 32 字节密钥。
// 换机器（machine-id 变）或换用户则无法解密，等同于“绑定本机”。
func localKey() []byte {
	id := readMachineID()
	h := sha256.New()
	io.WriteString(h, "ipp-gost/v1|")
	io.WriteString(h, id)
	h.Write([]byte{0})
	io.WriteString(h, os.Getenv("USER"))
	if h2 := os.Getenv("USERNAME"); h2 != "" {
		io.WriteString(h, h2)
	}
	return h.Sum(nil)
}

// readMachineID 读系统机器标识
func readMachineID() string {
	for _, p := range []string{
		"/etc/machine-id",
		"/var/lib/dbus/machine-id",
	} {
		if b, err := os.ReadFile(p); err == nil {
			if s := strings.TrimSpace(string(b)); s != "" {
				return s
			}
		}
	}
	// Windows / macOS 回退：主机名 + 用户名（弱，但至少不是可移植的）
	host, _ := os.Hostname()
	return "host:" + host
}

// aesEncrypt AES-256-GCM，输出 base64(nonce|密文)
func aesEncrypt(plain string, key []byte) (string, error) {
	blk, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(blk)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ct := gcm.Seal(nil, nonce, []byte(plain), nil)
	return base64.StdEncoding.EncodeToString(append(nonce, ct...)), nil
}

// aesDecrypt 解密 base64(nonce|密文)
func aesDecrypt(enc string, key []byte) (string, error) {
	raw, err := base64.StdEncoding.DecodeString(enc)
	if err != nil {
		return "", fmt.Errorf("密文格式错误: %w", err)
	}
	blk, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(blk)
	if err != nil {
		return "", err
	}
	ns := gcm.NonceSize()
	if len(raw) < ns {
		return "", errors.New("密文长度不足")
	}
	pt, err := gcm.Open(nil, raw[:ns], raw[ns:], nil)
	if err != nil {
		return "", fmt.Errorf("解密失败（可能换了机器或用户）: %w", err)
	}
	return string(pt), nil
}
