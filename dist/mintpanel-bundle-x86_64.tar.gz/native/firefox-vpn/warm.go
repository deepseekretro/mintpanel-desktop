package main

// 节点预热
//
// 背景：每条隧道都是「节点 TLS 握手 + CONNECT 往返 + 内层 TLS 握手」，
// 首次访问一个目标要吃掉 3 个 RTT。预热就是提前把这些握手做掉，
// 让用户点开网页时第一字节更快到达。
//
// 注意：HTTP/1.1 CONNECT 一条 TCP 只能承载一个目标，不能跨目标复用，
// 所以这里预热的是「到节点的 TLS 连接」，不是完整隧道——
// 目标不同时仍需重新 CONNECT，但省掉了 TCP+外层 TLS 握手（约 1 RTT）。

import (
	"crypto/tls"
	"log"
	"net"
	"sync"
	"time"
)

// nodeWarmer 维护一批到当前节点的已握手 TLS 连接
//
// 重要：池里存的是「到节点的外层 TLS」，与目标站无关。
// 池大小固定（默认 2），不会随访问的目标站数量增长。
// 每条隧道（一个目标）用完即关，不缓存。
type nodeWarmer struct {
	mu    sync.Mutex
	idle  []warmConn // 空闲的外层 TLS 连接
	node  Node       // 这批连接对应的节点
	total int        // 累计预热成功次数
	used  int        // 累计被取用次数
	size   int        // 期望池大小
	stop   chan struct{}
	paused bool // 暂停（轮换排空期间为 true，不建新连接）
}

// warmConn 带创建时间，用于淘汰旧连接
type warmConn struct {
	c  *tls.Conn
	at time.Time
}

// maxWarmAge 空闲连接最长保留时间
//
// 节点侧对空闲隧道有超时（实测约 1~2 分钟），超龄的预热连接
// 即使 socket 没断，CONNECT 也会被拒。留 45 秒比较安全。
const maxWarmAge = 45 * time.Second

var warmer = &nodeWarmer{size: defaultWarmSize, stop: make(chan struct{})}

// defaultWarmSize 默认预热条数
//
// 现代网页同时发起 6~10 个不同域名的连接（主站 + CDN + 图片 + API +
// 字体 + 埋点），而一条 HTTP/1.1 CONNECT 只能承载一个目标，
// 所以池子要能覆盖常见的并发域名数才有实际收益。
//
// 2  条：仅对齐 Firefox 行为，多域名页面瞬间耗尽
// 10 条：能吃掉大部分握手成本（默认）
//
// 注意：池子只是“已握好手的空连接”，不随访问量增长，不会泄漏。
const defaultWarmSize = 10

// warmTargets 预热时握手的 TLS 目标（只做握手，不 CONNECT）
// 用节点自己的 host:2499，握手成功后连接仍可继续发任意 CONNECT
const warmDialTimeout = 10 * time.Second

// StartWarm 启动后台预热协程
func (w *nodeWarmer) Start(d *Dialer) {
	go func() {
		// 首次延迟一点，避免和启动日志抢戏
		time.Sleep(2 * time.Second)
		t := time.NewTicker(30 * time.Second)
		defer t.Stop()
		for {
			select {
			case <-w.stop:
				return
			case <-t.C:
				w.topUp(d)
			}
		}
	}()
}

// topUp 把池子补到 size 条
func (w *nodeWarmer) topUp(d *Dialer) {
	if d == nil {
		return
	}
	w.mu.Lock()
	paused := w.paused
	w.mu.Unlock()
	if paused {
		return
	}
	cur := d.node()

	w.mu.Lock()
	// 换了节点，旧连接全丢
	if w.node.Host != cur.Host && len(w.idle) > 0 {
		for _, wc := range w.idle {
			wc.c.Close()
		}
		w.idle = nil
	}
	w.node = cur
	w.dropStaleLocked()
	need := w.size - len(w.idle)
	w.mu.Unlock()

	if need <= 0 {
		return
	}

	for i := 0; i < need; i++ {
		c, err := w.dial(cur)
		if err != nil {
			// 预热失败静默处理，不打扰用户
			return
		}
		w.mu.Lock()
		w.idle = append(w.idle, warmConn{c: c, at: time.Now()})
		w.total++
		w.mu.Unlock()
	}
	log.Printf("[warm] 已预热 %d/%d 条到 %s", len(w.idle), w.size, cur.Host)
}

// dial 建一条到节点的外层 TLS 连接（不 CONNECT）
func (w *nodeWarmer) dial(node Node) (*tls.Conn, error) {
	raw, err := dialNode(node.Host, node.Addr(), warmDialTimeout, GlobalNodeIP.Get())
	if err != nil {
		return nil, err
	}
	if tc, ok := raw.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
		_ = tc.SetKeepAlive(true)
		_ = tc.SetKeepAlivePeriod(30 * time.Second)
	}
	tc := tls.Client(raw, &tls.Config{
		ServerName: node.Host,
		MinVersion: tls.VersionTLS12,
		NextProtos: []string{"http/1.1"},
	})
	if err := tc.Handshake(); err != nil {
		raw.Close()
		return nil, err
	}
	return tc, nil
}

// Take 取一条预热连接（没有就返回 nil，调用方自行新建）
//
// 取用后会立即触发一次异步补充，保持池子恒满。
// Pause 暂停预热（轮换排空期间调用，避免继续在旧节点建连接）
func (w *nodeWarmer) Pause() {
	w.mu.Lock()
	w.paused = true
	w.mu.Unlock()
}

// Resume 恢复预热
func (w *nodeWarmer) Resume() {
	w.mu.Lock()
	w.paused = false
	w.mu.Unlock()
}

// IsPaused 是否暂停中
func (w *nodeWarmer) IsPaused() bool {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.paused
}

func (w *nodeWarmer) Take(node Node) *tls.Conn {
	w.mu.Lock()

	// 节点换了就没用了
	if w.node.Host != node.Host {
		w.mu.Unlock()
		return nil
	}
	if len(w.idle) == 0 {
		w.mu.Unlock()
		return nil
	}

	// 先淘汰过期的（否则 CONNECT 会被节点拒）
	w.dropStaleLocked()
	if len(w.idle) == 0 {
		w.mu.Unlock()
		go w.refill(node)
		return nil
	}

	// 从尾部取（最新建的）
	wc := w.idle[len(w.idle)-1]
	w.idle = w.idle[:len(w.idle)-1]
	w.used++
	need := w.size - len(w.idle)
	w.mu.Unlock()
	c := wc.c

	// 检查连接是否还活着：写 0 字节探测
	_ = c.SetWriteDeadline(time.Now().Add(200 * time.Millisecond))
	if _, err := c.Write(nil); err != nil {
		c.Close()
		return nil
	}
	_ = c.SetWriteDeadline(time.Time{})

	// 异步补回来
	if need > 0 {
		go w.refill(node)
	}
	return c
}

// refill 把池子补到 size 条（已知目标节点）
func (w *nodeWarmer) refill(node Node) {
	for {
		w.mu.Lock()
		if w.node.Host != node.Host {
			w.mu.Unlock()
			return
		}
		need := w.size - len(w.idle)
		w.mu.Unlock()
		if need <= 0 {
			return
		}

		c, err := w.dial(node)
		if err != nil {
			return
		}
		w.mu.Lock()
		// 期间又换节点了，丢掉
		if w.node.Host != node.Host {
			w.mu.Unlock()
			c.Close()
			return
		}
		w.idle = append(w.idle, warmConn{c: c, at: time.Now()})
		w.total++
		w.mu.Unlock()
	}
}

// dropStaleLocked 淘汰超龄的空闲连接（调用方需持锁）
func (w *nodeWarmer) dropStaleLocked() {
	if len(w.idle) == 0 {
		return
	}
	now := time.Now()
	keep := w.idle[:0]
	for _, wc := range w.idle {
		if now.Sub(wc.at) > maxWarmAge {
			wc.c.Close()
			continue
		}
		keep = append(keep, wc)
	}
	w.idle = keep
}

// Stats 预热统计
func (w *nodeWarmer) Stats() map[string]any {
	w.mu.Lock()
	defer w.mu.Unlock()

	b := burstStats()
	miss := b["missPerMin"].(int)
	hitRate := 1.0
	if w.used+miss > 0 {
		hitRate = float64(w.used) / float64(w.used+miss)
	}

	return map[string]any{
		"idle":       len(w.idle),
		"total":      w.total,
		"used":       w.used,
		"node":       w.node.Host,
		"targetSize": w.size,
		"hitRate":    hitRate,
		"burst":      b,
		"paused":     w.paused,
	}
}

// Stop 停止预热
func (w *nodeWarmer) Stop() {
	w.mu.Lock()
	for _, wc := range w.idle {
		wc.c.Close()
	}
	w.idle = nil
	w.mu.Unlock()
	select {
	case <-w.stop:
	default:
		close(w.stop)
	}
}

// Reset 切换到新节点时调用：清空旧连接并立即为新节点预热
//
// 不做这一步的话，切换节点后预热池要等下一个 topUp 周期（30 秒）才更新，
// 期间取到的都是旧节点的连接，CONNECT 会被新节点拒绝。
func (w *nodeWarmer) Reset(node Node) {
	w.mu.Lock()
	for _, wc := range w.idle {
		wc.c.Close()
	}
	w.idle = nil
	w.node = node
	w.mu.Unlock()

	if w.size > 0 {
		go w.refill(node)
	}
}

// ---------- 并发尖峰处理 ----------
//
// 问题：预热池固定 2 条，但并发 30 路请求时池瞬间空掉，
// refill 要 200ms 才能补上，这期间的请求全部走「新建」路径。
//
// 实际上新建路径本来就存在（Take 返回 nil 时），所以功能没问题，
// 只是统计上看不出来、也没法控制上限。
//
// 这里加两个计数器：
//   - burst：最近 1 分钟内因池空而临时新建的次数
//   - peak ：历史最大并发建连数
//
// 不改变行为，只暴露真实情况，便于决定要不要调大 -warm。

var burst struct {
	mu    sync.Mutex
	count int
	since time.Time
	peak  int
	cur   int
}

func burstNoteMiss() {
	burst.mu.Lock()
	defer burst.mu.Unlock()
	now := time.Now()
	if now.Sub(burst.since) > time.Minute {
		burst.count = 0
		burst.since = now
	}
	burst.count++
}

func burstEnter() {
	burst.mu.Lock()
	defer burst.mu.Unlock()
	burst.cur++
	if burst.cur > burst.peak {
		burst.peak = burst.cur
	}
}

func burstLeave() {
	burst.mu.Lock()
	defer burst.mu.Unlock()
	burst.cur--
}

func burstStats() map[string]any {
	burst.mu.Lock()
	defer burst.mu.Unlock()
	now := time.Now()
	c := burst.count
	if now.Sub(burst.since) > time.Minute {
		c = 0
	}
	return map[string]any{
		"missPerMin": c,
		"inflight":   burst.cur,
		"peak":       burst.peak,
	}
}

// Resize 调整预热池大小（GUI 里实时改）
//
// size=0 表示关闭预热：关闭所有空闲连接并停止补充。
// 调大时立即补足到新尺寸。
func (w *nodeWarmer) Resize(n int, d *Dialer) {
	if w == nil {
		return
	}
	if n < 0 {
		n = 0
	}
	w.mu.Lock()
	w.size = n
	// 池子缩小时先关掉多余的
	for len(w.idle) > n {
		c := w.idle[len(w.idle)-1]
		w.idle = w.idle[:len(w.idle)-1]
		if c.c != nil {
			c.c.Close()
		}
	}
	w.mu.Unlock()

	// 调大时立即补足
	if n > 0 && d != nil {
		w.topUp(d)
	}
}
