//go:build windows

package main

// config_dpapi_windows.go: Windows 下用 DPAPI 加密 sessionToken
//
// CryptProtectData 的密钥由 Windows 从当前用户登录凭据派生：
//   - 同一台机器 + 同一用户才能解密
//   - 配置文件被拷到别的机器/别的账户无法解密
// 这正是我们要的"绑定本机"效果，无需自己管密钥。

import (
	"encoding/base64"
	"fmt"
	"unsafe"

	"golang.org/x/sys/windows"
)

// dpapiEntropy 额外的熵，进一步限定用途（防止别的程序拿同样的 blob 解）
var dpapiEntropy = []byte("ipp-gost/sessionToken/v1")

func dpapiBlobInit(b *windows.DataBlob) {
	b.Size = 0
	b.Data = nil
}

// dpapiEncrypt 加密为 base64(DPAPI blob)
func dpapiEncrypt(plain string) (string, error) {
	in := []byte(plain)
	entropy := dpapiEntropy

	var dataIn, entropyIn, dataOut windows.DataBlob
	dataIn.Size = uint32(len(in))
	if len(in) > 0 {
		dataIn.Data = &in[0]
	}
	entropyIn.Size = uint32(len(entropy))
	if len(entropy) > 0 {
		entropyIn.Data = &entropy[0]
	}

	// CRYPTPROTECT_UI_FORBIDDEN = 0x1
	const flags = 0x1

	if err := windows.CryptProtectData(&dataIn, nil, &entropyIn, 0, nil, flags, &dataOut); err != nil {
		return "", fmt.Errorf("DPAPI 加密失败: %w", err)
	}
	defer windows.LocalFree(windows.Handle(unsafe.Pointer(dataOut.Data)))

	buf := unsafe.Slice(dataOut.Data, dataOut.Size)
	return base64.StdEncoding.EncodeToString(buf), nil
}

// dpapiDecrypt 解密 base64(DPAPI blob)
func dpapiDecrypt(enc string) (string, error) {
	raw, err := base64.StdEncoding.DecodeString(enc)
	if err != nil {
		return "", fmt.Errorf("密文格式错误: %w", err)
	}
	entropy := dpapiEntropy

	var dataIn, entropyIn, dataOut windows.DataBlob
	if len(raw) > 0 {
		dataIn.Data = &raw[0]
	}
	dataIn.Size = uint32(len(raw))
	entropyIn.Size = uint32(len(entropy))
	if len(entropy) > 0 {
		entropyIn.Data = &entropy[0]
	}

	const flags = 0x1
	if err := windows.CryptUnprotectData(&dataIn, nil, &entropyIn, 0, nil, flags, &dataOut); err != nil {
		return "", fmt.Errorf("DPAPI 解密失败（可能换了机器或用户）: %w", err)
	}
	defer windows.LocalFree(windows.Handle(unsafe.Pointer(dataOut.Data)))

	return string(unsafe.Slice(dataOut.Data, dataOut.Size)), nil
}
