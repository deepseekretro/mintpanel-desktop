//go:build cshared

package main

/*
#include <stdlib.h>
*/
import "C"
import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"sync"
	"time"
	"unsafe"
)

type LogRingBuffer struct {
	mu    sync.Mutex
	lines []string
	max   int
}

func (b *LogRingBuffer) Write(p []byte) (n int, err error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	str := string(p)
	rawLines := strings.Split(str, "\n")
	for _, l := range rawLines {
		trimmed := strings.TrimRight(l, "\r\n")
		if trimmed != "" {
			b.lines = append(b.lines, trimmed)
		}
	}
	if len(b.lines) > b.max {
		b.lines = b.lines[len(b.lines)-b.max:]
	}
	return len(p), nil
}

func (b *LogRingBuffer) Lines() []string {
	b.mu.Lock()
	defer b.mu.Unlock()
	copied := make([]string, len(b.lines))
	copy(copied, b.lines)
	return copied
}

func (b *LogRingBuffer) Clear() {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.lines = nil
}

var ffLogBuf = &LogRingBuffer{max: 200}

func init() {
	log.SetOutput(io.MultiWriter(os.Stderr, ffLogBuf))
	log.Printf("[init] Firefox VPN Go C-Shared 模块已加载")
}

type ffExtraListenerConfig struct {
	ID     string `json:"id"`
	Listen string `json:"listen"`
	Node   string `json:"node"`
}

type ffBridgeConfig struct {
	Listen         string                  `json:"listen"`
	Public         string                  `json:"public"`
	Profile        string                  `json:"profile"`
	LoginProxy     string                  `json:"loginProxy"`
	SessionToken   string                  `json:"sessionToken"`
	FxaToken       string                  `json:"fxaToken"`
	Node           string                  `json:"node"`
	NodePort       int                     `json:"nodePort"`
	IPMode         string                  `json:"ipMode"`
	NodeIP         string                  `json:"nodeIP"`
	H3             *bool                   `json:"h3"`
	H3Conns        int                     `json:"h3Conns"`
	Warm           *int                    `json:"warm"`
	ExtraListeners []ffExtraListenerConfig `json:"extraListeners"`
}

type ffExtraRuntime struct {
	id     string
	listen string
	ns     *NodeSwitch
	d      *Dialer
	svc    *ProxyService
}

var (
	ffCachedPings     map[string]int64
	ffCachedPingsTime time.Time
	ffPingsMu         sync.Mutex

	ffMu        sync.Mutex
	ffRunning   bool
	ffCfgPath   string
	ffCfg       ffBridgeConfig
	ffStartTime time.Time
	ffLastErr   string

	ffNS          *NodeSwitch
	ffPM          *PassManager
	ffTR          *tokenRuntime
	ffSvc         *ProxyService
	ffD           *Dialer
	ffNet         *NetStore
	ffExtras      = map[string]*ffExtraRuntime{}
	ffExtrasOrder []string
)

func ffDefaultConfig(c ffBridgeConfig) ffBridgeConfig {
	if strings.TrimSpace(c.Listen) == "" {
		c.Listen = "127.0.0.1:10909"
	}
	if c.NodePort <= 0 {
		c.NodePort = 2499
	}
	if strings.TrimSpace(c.IPMode) == "" {
		c.IPMode = "auto"
	}
	if strings.TrimSpace(c.NodeIP) == "" {
		c.NodeIP = "auto"
	}
	if c.H3 == nil {
		v := true
		c.H3 = &v
	}
	if c.H3Conns <= 0 {
		c.H3Conns = 4
	}
	if c.Warm == nil {
		v := 10
		c.Warm = &v
	}
	return c
}

func ffEnsureRuntimeLocked(c ffBridgeConfig) error {
	c = ffDefaultConfig(c)
	ffCfg = c

	netcfg := DefaultNetConfig()
	lp := strings.TrimSpace(c.LoginProxy)
	switch strings.ToLower(lp) {
	case "", "direct", "off", "none", "-":
		netcfg.ProxyURL = ""
	default:
		netcfg.ProxyURL = lp
	}
	if ffNet == nil {
		ffNet = NewNetStore(netcfg)
	} else {
		ffNet.Set(netcfg)
	}

	if m, err := ParseNodeIPMode(c.NodeIP); err == nil {
		GlobalNodeIP.Set(m)
	} else {
		GlobalNodeIP.Set(NodeIPAuto)
	}

	var ts *TokenSource
	var tsErr error
	if strings.TrimSpace(c.SessionToken) != "" {
		cand := &TokenSource{sessionToken: strings.TrimSpace(c.SessionToken), getNet: ffNet.Get}
		if err := cand.refresh(); err != nil {
			tsErr = err
		} else {
			ts = cand
		}
	} else if strings.TrimSpace(c.FxaToken) != "" {
		ts, tsErr = NewTokenSourceWithNet(strings.TrimSpace(c.FxaToken), c.Profile, ffNet.Get)
	} else {
		ts, tsErr = NewTokenSourceWithNet("", c.Profile, ffNet.Get)
	}
	if ts == nil {
		ts = NewTokenSourceEmpty(c.FxaToken, c.Profile, ffNet.Get)
	}
	ffTR = newTokenRuntime(ts, ffNet)
	if tsErr != nil {
		ffTR.lastErr = tsErr.Error()
	}

	if ffPM != nil {
		ffPM.Close()
		ffPM = nil
	}
	g := NewGuardianWithNet(ts, ffNet.Get)
	pm, err := NewPassManager(g)
	if err != nil {
		ffLastErr = err.Error()
	}
	ffPM = pm

	var allNodes []Node
	if ffNS != nil && len(ffNS.All()) > 0 {
		allNodes = ffNS.All()
	} else {
		allNodes, _ = FetchNodeList(c.NodePort)
	}

	nodeHost := strings.TrimSpace(c.Node)
	var cur Node
	if len(allNodes) > 0 {
		if nodeHost == "" {
			cur = PickFastest(allNodes, 4*time.Second, allNodes[0])
		} else {
			cur = Node{Host: nodeHost, Port: c.NodePort}
			for _, n := range allNodes {
				if n.Host == nodeHost {
					cur = n
					break
				}
			}
		}
	} else if nodeHost != "" {
		cur = Node{Host: nodeHost, Port: c.NodePort}
	}
	ffNS = NewNodeSwitch(allNodes, cur)

	ipm, err := ParseIPMode(c.IPMode)
	if err != nil {
		ipm = IPModeAuto
	}
	ffD = &Dialer{ns: ffNS, port: c.NodePort, pm: ffPM, res: newResolver(ipm)}

	h3On := *c.H3
	h3Enabled.Store(h3On)
	if h3On {
		if *c.Warm > 0 {
			h3FallbackHook = func() {
				warmer.size = *c.Warm
				warmer.Start(ffD)
			}
		}
		if cur.Host != "" {
			warmH3(cur)
		}
	} else if *c.Warm > 0 {
		warmer.size = *c.Warm
		warmer.Start(ffD)
	}

	p := &Proxy{d: ffD, port: c.NodePort}
	ffSvc = NewProxyService(p)
	return nil
}

func ffResolveNodeLocked(host string, allNodes []Node, port int) Node {
	nodeHost := strings.TrimSpace(host)
	if nodeHost == "" && ffNS != nil {
		cur := ffNS.Current()
		if cur.Host != "" {
			return cur
		}
	}
	for _, n := range allNodes {
		if n.Host == nodeHost {
			return n
		}
	}
	if nodeHost != "" {
		return Node{Host: nodeHost, Port: port}
	}
	if len(allNodes) > 0 {
		return allNodes[0]
	}
	return Node{Port: port}
}

func ffStartExtraLocked(item ffExtraListenerConfig) (*ffExtraRuntime, error) {
	addr := normalAddr(strings.TrimSpace(item.Listen))
	id := strings.TrimSpace(item.ID)
	if id == "" {
		id = addr
	}
	if ffSvc != nil && ffSvc.State().Running && ffSvc.State().Addr == addr {
		return nil, fmt.Errorf("端口 %s 已被主代理占用", addr)
	}
	for k, ex := range ffExtras {
		if k != id && ex != nil && ex.svc != nil && ex.svc.State().Running && ex.svc.State().Addr == addr {
			return nil, fmt.Errorf("端口 %s 已被监听器 %s 占用", addr, k)
		}
	}
	if old, ok := ffExtras[id]; ok && old != nil && old.svc != nil {
		if old.svc.State().Running {
			_ = old.svc.Stop()
		}
	}

	var allNodes []Node
	if ffNS != nil && len(ffNS.All()) > 0 {
		allNodes = ffNS.All()
	} else {
		allNodes, _ = FetchNodeList(ffCfg.NodePort)
	}
	port := ffCfg.NodePort
	if port <= 0 {
		port = 2499
	}
	target := ffResolveNodeLocked(item.Node, allNodes, port)
	ns := NewNodeSwitch(allNodes, target)

	var res *resolver
	if ffD != nil && ffD.res != nil {
		res = ffD.res
	} else {
		ipm, err := ParseIPMode(ffCfg.IPMode)
		if err != nil {
			ipm = IPModeAuto
		}
		res = newResolver(ipm)
	}
	d := &Dialer{ns: ns, port: port, pm: ffPM, res: res}
	p := &Proxy{d: d, port: port}
	svc := NewProxyService(p)
	if err := svc.Start(addr); err != nil {
		return nil, err
	}
	if h3Enabled.Load() && target.Host != "" {
		go warmH3(target)
	}
	ex := &ffExtraRuntime{
		id:     id,
		listen: addr,
		ns:     ns,
		d:      d,
		svc:    svc,
	}
	if _, exists := ffExtras[id]; !exists {
		ffExtrasOrder = append(ffExtrasOrder, id)
	}
	ffExtras[id] = ex
	log.Printf("[extra] 启动固定端口代理 %s -> %s (%s)", addr, target.Code, target.Host)
	return ex, nil
}

func ffStopAllExtrasLocked() {
	for _, id := range ffExtrasOrder {
		if ex, ok := ffExtras[id]; ok && ex != nil && ex.svc != nil && ex.svc.State().Running {
			_ = ex.svc.Stop()
		}
	}
	ffExtras = map[string]*ffExtraRuntime{}
	ffExtrasOrder = nil
}

func ffExtraListenerSnapshot(ex *ffExtraRuntime) map[string]any {
	st := ex.svc.State()
	var node Node
	if ex.ns != nil {
		node = ex.ns.Current()
	}
	return map[string]any{
		"id":      ex.id,
		"listen":  ex.listen,
		"addr":    st.Addr,
		"running": st.Running,
		"node":    node,
		"service": st,
	}
}

func ffExtraListenersSnapshotLocked() []map[string]any {
	out := make([]map[string]any, 0, len(ffExtrasOrder))
	for _, id := range ffExtrasOrder {
		if ex, ok := ffExtras[id]; ok && ex != nil {
			out = append(out, ffExtraListenerSnapshot(ex))
		}
	}
	return out
}

func ffStopLocked() error {
	var firstErr error
	ffStopAllExtrasLocked()
	if ffSvc != nil {
		if ffSvc.State().Running {
			if err := ffSvc.Stop(); err != nil && firstErr == nil {
				firstErr = err
			}
		}
		if pub, _ := ffSvc.PublicState(); pub {
			_ = ffSvc.StopPublic()
		}
	}
	if ffPM != nil {
		ffPM.Close()
		ffPM = nil
	}
	ffRunning = false
	return firstErr
}

func ffStartFromJSONBytes(b []byte, label string) error {
	ffMu.Lock()
	defer ffMu.Unlock()

	_ = ffStopLocked()

	var c ffBridgeConfig
	if len(strings.TrimSpace(string(b))) > 0 {
		if err := json.Unmarshal(b, &c); err != nil {
			ffLastErr = err.Error()
			return err
		}
	}
	if err := ffEnsureRuntimeLocked(c); err != nil {
		ffLastErr = err.Error()
		return err
	}
	if err := ffSvc.Start(ffCfg.Listen); err != nil {
		ffLastErr = err.Error()
		return err
	}
	if strings.TrimSpace(ffCfg.Public) != "" {
		_ = ffSvc.StartPublic(strings.TrimSpace(ffCfg.Public))
	}
	for _, item := range ffCfg.ExtraListeners {
		if strings.TrimSpace(item.Listen) == "" {
			continue
		}
		if _, err := ffStartExtraLocked(item); err != nil {
			log.Printf("[extra] 自启端口 %s 失败: %v", item.Listen, err)
		}
	}
	ffRunning = true
	ffCfgPath = label
	ffStartTime = time.Now()
	ffLastErr = ""
	return nil
}

//export FFVpnStart
func FFVpnStart(cfgPath *C.char) *C.char {
	if cfgPath == nil {
		return C.CString("nil config path")
	}
	p := C.GoString(cfgPath)
	b, err := os.ReadFile(p)
	if err != nil {
		ffMu.Lock()
		ffLastErr = err.Error()
		ffMu.Unlock()
		return C.CString(err.Error())
	}
	if err := ffStartFromJSONBytes(b, p); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export FFVpnStartJSON
func FFVpnStartJSON(jsonContent *C.char) *C.char {
	if jsonContent == nil {
		return C.CString("nil json content")
	}
	if err := ffStartFromJSONBytes([]byte(C.GoString(jsonContent)), "memory://json"); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export FFVpnStop
func FFVpnStop() *C.char {
	ffMu.Lock()
	defer ffMu.Unlock()
	if err := ffStopLocked(); err != nil {
		return C.CString(err.Error())
	}
	return nil
}


func getPingsCache() map[string]int64 {
	ffPingsMu.Lock()
	defer ffPingsMu.Unlock()
	if ffCachedPings == nil {
		return map[string]int64{}
	}
	res := make(map[string]int64, len(ffCachedPings))
	for k, v := range ffCachedPings {
		res[k] = v
	}
	return res
}

func getPingsCacheTime() int64 {
	ffPingsMu.Lock()
	defer ffPingsMu.Unlock()
	if ffCachedPingsTime.IsZero() {
		return 0
	}
	return ffCachedPingsTime.Unix()
}

//export FFVpnStatusJSON
func FFVpnStatusJSON() *C.char {
	ffMu.Lock()
	defer ffMu.Unlock()
	up := int64(0)
	if ffRunning && !ffStartTime.IsZero() {
		up = int64(time.Since(ffStartTime).Seconds())
	}
	var svcState ServiceState
	var pubRunning bool
	var pubAddr string
	if ffSvc != nil {
		svcState = ffSvc.State()
		pubRunning, pubAddr = ffSvc.PublicState()
	}
	var tok tokenStatus
	if ffTR != nil {
		tok = ffTR.Status()
	} else {
		tok = tokenStatus{Source: "none"}
	}
	var curNode Node
	if ffNS != nil {
		curNode = ffNS.Current()
	}
	ipMode := ffCfg.IPMode
	if ffD != nil && ffD.res != nil {
		ipMode = ffD.res.Mode().String()
	}
	out := map[string]any{
		"running":        ffRunning && svcState.Running,
		"addr":           svcState.Addr,
		"publicRunning":  pubRunning,
		"publicAddr":     pubAddr,
		"config_path":    ffCfgPath,
		"uptime_sec":     up,
		"error":          ffLastErr,
		"service":        svcState,
		"token":          tok,
		"node":           curNode,
		"ipMode":         ipMode,
		"nodeIP":         GlobalNodeIP.Get().String(),
		"h3":             h3Enabled.Load(),
		"profile":        ffCfg.Profile,
		"loginProxy":     ffCfg.LoginProxy,
		"logs":           ffLogBuf.Lines(),
		"pings":          getPingsCache(),
		"pings_time":     getPingsCacheTime(),
		"extraListeners": ffExtraListenersSnapshotLocked(),
	}
	b, _ := json.Marshal(out)
	return C.CString(string(b))
}

func ffMarshal(v any) *C.char {
	b, _ := json.Marshal(v)
	return C.CString(string(b))
}

//export FFVpnActionJSON
func FFVpnActionJSON(action *C.char, payloadJSON *C.char) *C.char {
	act := ""
	if action != nil {
		act = C.GoString(action)
	}
	raw := "{}"
	if payloadJSON != nil && strings.TrimSpace(C.GoString(payloadJSON)) != "" {
		raw = C.GoString(payloadJSON)
	}

	switch act {
	case "scan_profiles":
		found, scanned := discoverProfiles()
		return ffMarshal(map[string]any{"ok": true, "profiles": found, "scanned": scanned})

	case "set_profile":
		var req struct {
			Profile string `json:"profile"`
		}
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		info, err := resolveProfilePath(req.Profile)
		if err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		ffMu.Lock()
		ffCfg.Profile = info.Path
		if ffNet == nil {
			d := DefaultNetConfig()
			ffNet = NewNetStore(d)
		}
		ts, tsErr := NewTokenSourceWithNet("", info.Path, ffNet.Get)
		if ts == nil {
			ts = NewTokenSourceEmpty("", info.Path, ffNet.Get)
		}
		ffTR = newTokenRuntime(ts, ffNet)
		if tsErr != nil {
			ffTR.lastErr = tsErr.Error()
		}
		tok := ffTR.Status()
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "info": info, "token": tok})

	case "set_token":
		var req struct {
			SessionToken string `json:"sessionToken"`
			AccessToken  string `json:"accessToken"`
			Email        string `json:"email"`
			UID          string `json:"uid"`
		}
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		ffMu.Lock()
		if ffNet == nil {
			d := DefaultNetConfig()
			ffNet = NewNetStore(d)
		}
		if ffTR == nil {
			ffTR = newTokenRuntime(NewTokenSourceEmpty("", ffCfg.Profile, ffNet.Get), ffNet)
		}
		if strings.TrimSpace(req.SessionToken) != "" {
			tok := strings.TrimSpace(req.SessionToken)
			if err := ffTR.SetSessionToken(tok, req.Email, req.UID); err != nil {
				ffMu.Unlock()
				return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
			}
			ffCfg.SessionToken = tok
			if ffPM != nil && ffTR != nil && ffTR.ts != nil {
				ffPM.g.ts = ffTR.ts
				if err := ffPM.Refresh(); err != nil {
					log.Printf("[account] 切换账号后刷新 pass 提示: %v", err)
				} else {
					log.Printf("[account] 成功热切换出站身份至: %s (%s...)", req.Email, tok[:8])
				}
			}
		} else if strings.TrimSpace(req.AccessToken) != "" {
			ffTR.SetAccessToken(strings.TrimSpace(req.AccessToken))
			ffCfg.FxaToken = strings.TrimSpace(req.AccessToken)
		} else {
			ffMu.Unlock()
			return ffMarshal(map[string]any{"ok": false, "error": "token 不能为空"})
		}
		tok := ffTR.Status()
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "token": tok})

	case "refresh_session_token":
		var req struct {
			SessionToken string `json:"sessionToken"`
			Email        string `json:"email"`
			UID          string `json:"uid"`
		}
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		tokHex := strings.TrimSpace(req.SessionToken)
		if tokHex == "" {
			return ffMarshal(map[string]any{"ok": false, "error": "sessionToken 不能为空"})
		}
		ffMu.Lock()
		ns := ffNet
		if ns == nil {
			d := DefaultNetConfig()
			ns = NewNetStore(d)
			ffNet = ns
		}
		ffMu.Unlock()

		cand := &TokenSource{
			sessionToken: tokHex,
			email:        strings.TrimSpace(req.Email),
			uid:          strings.TrimSpace(req.UID),
			getNet:       ns.Get,
		}
		tmpTR := newTokenRuntime(cand, ns)
		if err := cand.refresh(); err != nil {
			tmpTR.lastErr = err.Error()
			return ffMarshal(map[string]any{"ok": false, "error": err.Error(), "token": tmpTR.Status()})
		}
		st := tmpTR.Status()
		ent, entErr := NewGuardianWithNet(cand, ns.Get).Status()
		resp := map[string]any{
			"ok":    true,
			"token": st,
		}
		if ent != nil {
			resp["entitlement"] = ent
		}
		if entErr != nil {
			resp["entitlementError"] = entErr.Error()
		}
		log.Printf("[auth] 账户巡检续期成功: %s (exp=%s)", st.Email, st.ExpiresAtText)
		return ffMarshal(resp)

	case "refresh_token":
		ffMu.Lock()
		tr := ffTR
		ffMu.Unlock()
		if tr == nil || tr.ts == nil {
			return ffMarshal(map[string]any{"ok": false, "error": "未初始化 token 源"})
		}
		if !tr.ts.CanRefresh() {
			return ffMarshal(map[string]any{"ok": false, "error": "当前 token 不可续期（只读）"})
		}
		if err := tr.ts.refresh(); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		return ffMarshal(map[string]any{"ok": true, "token": tr.Status()})

	case "test_login_proxy":
		var req struct {
			ProxyURL string `json:"proxyURL"`
			Timeout  int    `json:"timeout"`
		}
		_ = json.Unmarshal([]byte(raw), &req)
		if req.Timeout <= 0 {
			req.Timeout = 15
		}
		p := strings.TrimSpace(req.ProxyURL)
		if strings.EqualFold(p, "direct") {
			p = ""
		}
		nc := NetConfig{ProxyURL: p, Timeout: req.Timeout}
		ms, err := nc.TestConnectivity()
		if err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		return ffMarshal(map[string]any{"ok": true, "latencyMs": ms})

	case "get_logs":
		return ffMarshal(map[string]any{"ok": true, "logs": ffLogBuf.Lines()})

	case "clear_logs":
		ffLogBuf.Clear()
		return ffMarshal(map[string]any{"ok": true, "logs": []string{}})

	case "list_nodes":
		ffMu.Lock()
		ns := ffNS
		port := ffCfg.NodePort
		ffMu.Unlock()
		if port <= 0 {
			port = 2499
		}
		if ns != nil && len(ns.All()) > 0 {
			return ffMarshal(map[string]any{"ok": true, "nodes": ns.All(), "current": ns.Current(), "pings": getPingsCache(), "pings_time": getPingsCacheTime()})
		}
		all, err := FetchNodeList(port)
		if err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		var cur Node
		if len(all) > 0 {
			cur = all[0]
		}
		ffMu.Lock()
		if ffNS == nil {
			ffNS = NewNodeSwitch(all, cur)
		}
		cur = ffNS.Current()
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "nodes": all, "current": cur, "pings": getPingsCache(), "pings_time": getPingsCacheTime()})

	case "ping_nodes":
		ffMu.Lock()
		ns := ffNS
		port := ffCfg.NodePort
		ffMu.Unlock()
		if port <= 0 {
			port = 2499
		}
		var all []Node
		if ns != nil && len(ns.All()) > 0 {
			all = ns.All()
		} else {
			var err error
			all, err = FetchNodeList(port)
			if err != nil {
				return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
			}
		}
		pings := pingAll(all, 8)
		ffPingsMu.Lock()
		ffCachedPings = pings
		ffCachedPingsTime = time.Now()
		ffPingsMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "pings": pings, "time": ffCachedPingsTime.Unix()})

	case "select_node":
		var req struct {
			Host string `json:"host"`
		}
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		ffMu.Lock()
		ns := ffNS
		ffMu.Unlock()
		if ns == nil {
			return ffMarshal(map[string]any{"ok": false, "error": "节点列表未初始化，请先启动或拉取节点"})
		}
		n, err := ns.Switch(strings.TrimSpace(req.Host))
		if err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		if h3Enabled.Load() {
			go warmH3(n)
		}
		return ffMarshal(map[string]any{"ok": true, "node": n})

	case "set_ip_mode":
		var req struct {
			Mode string `json:"mode"`
		}
		_ = json.Unmarshal([]byte(raw), &req)
		m, err := ParseIPMode(req.Mode)
		if err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		ffMu.Lock()
		ffCfg.IPMode = m.String()
		if ffD != nil && ffD.res != nil {
			ffD.res.SetMode(m)
		}
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "mode": m.String()})

	case "set_node_ip":
		var req struct {
			Mode string `json:"mode"`
		}
		_ = json.Unmarshal([]byte(raw), &req)
		m, err := ParseNodeIPMode(req.Mode)
		if err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		GlobalNodeIP.Set(m)
		ffMu.Lock()
		ffCfg.NodeIP = m.String()
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "mode": m.String()})

	case "seed_pings":
		var req struct {
			Pings map[string]int64 `json:"pings"`
			Time  int64            `json:"time"`
			Force bool             `json:"force"`
		}
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		ffPingsMu.Lock()
		if len(req.Pings) > 0 && (req.Force || ffCachedPingsTime.IsZero() || len(ffCachedPings) == 0) {
			cp := make(map[string]int64, len(req.Pings))
			for k, v := range req.Pings {
				cp[k] = v
			}
			ffCachedPings = cp
			if req.Time > 0 {
				ffCachedPingsTime = time.Unix(req.Time, 0)
			} else {
				ffCachedPingsTime = time.Now()
			}
		}
		ffPingsMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "pings": getPingsCache(), "pings_time": getPingsCacheTime()})

	case "add_listener":
		var req ffExtraListenerConfig
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		if strings.TrimSpace(req.Listen) == "" {
			return ffMarshal(map[string]any{"ok": false, "error": "监听地址不能为空"})
		}
		ffMu.Lock()
		if !ffRunning || ffPM == nil {
			ffMu.Unlock()
			return ffMarshal(map[string]any{"ok": false, "error": "请先启动主 Firefox VPN 服务"})
		}
		ex, err := ffStartExtraLocked(req)
		if err != nil {
			ffMu.Unlock()
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		snap := ffExtraListenerSnapshot(ex)
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "listener": snap})

	case "update_listener":
		var req ffExtraListenerConfig
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		id := strings.TrimSpace(req.ID)
		ffMu.Lock()
		ex, ok := ffExtras[id]
		if !ok || ex == nil {
			if strings.TrimSpace(req.Listen) != "" {
				ex, err := ffStartExtraLocked(req)
				if err != nil {
					ffMu.Unlock()
					return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
				}
				snap := ffExtraListenerSnapshot(ex)
				ffMu.Unlock()
				return ffMarshal(map[string]any{"ok": true, "listener": snap})
			}
			ffMu.Unlock()
			return ffMarshal(map[string]any{"ok": false, "error": "未找到对应监听器"})
		}
		newAddr := ex.listen
		if strings.TrimSpace(req.Listen) != "" {
			newAddr = normalAddr(strings.TrimSpace(req.Listen))
		}
		if newAddr != ex.listen {
			req.ID = id
			req.Listen = newAddr
			if strings.TrimSpace(req.Node) == "" && ex.ns != nil {
				req.Node = ex.ns.Current().Host
			}
			ex2, err := ffStartExtraLocked(req)
			if err != nil {
				ffMu.Unlock()
				return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
			}
			snap := ffExtraListenerSnapshot(ex2)
			ffMu.Unlock()
			return ffMarshal(map[string]any{"ok": true, "listener": snap})
		}
		if strings.TrimSpace(req.Node) != "" && ex.ns != nil {
			n, err := ex.ns.Switch(strings.TrimSpace(req.Node))
			if err != nil {
				ffMu.Unlock()
				return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
			}
			if h3Enabled.Load() {
				go warmH3(n)
			}
			log.Printf("[extra] 端口 %s 已切换地区 -> %s (%s)", ex.listen, n.Code, n.Host)
		}
		snap := ffExtraListenerSnapshot(ex)
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true, "listener": snap})

	case "remove_listener":
		var req struct {
			ID string `json:"id"`
		}
		if err := json.Unmarshal([]byte(raw), &req); err != nil {
			return ffMarshal(map[string]any{"ok": false, "error": err.Error()})
		}
		id := strings.TrimSpace(req.ID)
		ffMu.Lock()
		if ex, ok := ffExtras[id]; ok && ex != nil {
			if ex.svc != nil && ex.svc.State().Running {
				_ = ex.svc.Stop()
			}
			delete(ffExtras, id)
			nextOrder := make([]string, 0, len(ffExtrasOrder))
			for _, oid := range ffExtrasOrder {
				if oid != id {
					nextOrder = append(nextOrder, oid)
				}
			}
			ffExtrasOrder = nextOrder
			log.Printf("[extra] 已移除固定端口代理 %s", ex.listen)
		}
		ffMu.Unlock()
		return ffMarshal(map[string]any{"ok": true})

	default:
		return ffMarshal(map[string]any{"ok": false, "error": fmt.Sprintf("未知动作: %s", act)})
	}
}

//export FFVpnFreeStr
func FFVpnFreeStr(p *C.char) {
	if p != nil {
		C.free(unsafe.Pointer(p))
	}
}

func main() {}
