package main

// fxa.go: 用 Firefox profile 里的 sessionToken 换取 FxA access token
//
// 逆向自 omni.ja 的 FxAccountsClient.accessTokenWithSessionToken():
//
//   deriveHawkCredentials(sessionTokenHex, "sessionToken", 96)
//     -> hkdfLegacy(token, undefined, keyWord("sessionToken"), 96)
//        keyWord(s) = "identity.mozilla.com/picl/v1/" + s
//     -> id  = hex(out[0:32])
//        key = out[32:64]
//
//   然后 POST /v1/oauth/token
//        Authorization: Hawk id="<id>", ts=..., nonce=..., mac=..., hash=...
//        {client_id, grant_type: "fxa-credentials", scope, ttl}
//
// 两个关键坑（实测得出）:
//   1. profile 里的 sessionToken 字符串要按 **hex** 解（32 字节），
//      不是 base64（48 字节）。两者长度都是 64 字符，极易搞错。
//   2. id 不加 "fxs" 前缀（尽管源码里 BEARER_TOKEN_PREFIXES 有它，
//      那是给 Bearer 用的，Hawk 场景不用）。

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os/exec"
	"strconv"
	"strings"
	"time"
)

const (
	fxaAPI    = "https://api.accounts.firefox.com"
	piclProto = "identity.mozilla.com/picl/v1/"
	// Firefox 桌面端的 OAuth client_id
	fxaClientID = "5882386c6d801776"
	fxaScope    = "https://identity.mozilla.com/apps/vpn profile"
)

// hkdfSHA256 实现 RFC 5869；salt 为空时用 32 个零字节
func hkdfSHA256(ikm, info []byte, length int, salt []byte) []byte {
	if len(salt) == 0 {
		salt = make([]byte, 32)
	}
	mac := hmac.New(sha256.New, salt)
	mac.Write(ikm)
	prk := mac.Sum(nil)

	out := make([]byte, 0, length)
	var t []byte
	for i := byte(1); len(out) < length; i++ {
		mac = hmac.New(sha256.New, prk)
		mac.Write(t)
		mac.Write(info)
		mac.Write([]byte{i})
		t = mac.Sum(nil)
		out = append(out, t...)
	}
	return out[:length]
}

// deriveHawkCredentials 对应 Firefox 的 deriveHawkCredentials(data, "sessionToken")
func deriveHawkCredentials(seed []byte) (idHex string, key []byte) {
	out := hkdfSHA256(seed, []byte(piclProto+"sessionToken"), 96, nil)
	return hex.EncodeToString(out[:32]), out[32:64]
}

// fnv1a 是 Hawk nonce 用的哈希
func fnv1a(s string) uint32 {
	h := uint32(0x811C9DC5)
	for i := 0; i < len(s); i++ {
		h ^= uint32(s[i])
		h *= 0x01000193
	}
	return h
}

// hawkHeader 生成 Hawk 认证头
func hawkHeader(idHex string, key []byte, method, path, payload string) string {
	ts := strconv.FormatInt(time.Now().UnixMilli(), 10)
	nonce := strconv.FormatUint(uint64(fnv1a(ts)), 10)

	ph := sha256.Sum256([]byte(payload))
	payloadHash := hex.EncodeToString(ph[:])

	sigData := strings.Join([]string{method, idHex, nonce, payloadHash}, "\n")
	mac := hmac.New(sha256.New, key)
	mac.Write([]byte(sigData))
	macHex := hex.EncodeToString(mac.Sum(nil))

	return fmt.Sprintf(`Hawk id="%s", ts="%s", nonce="%s", mac="%s", hash="%s"`,
		idHex, ts, nonce, macHex, payloadHash)
}

type oauthTokenResp struct {
	AccessToken string `json:"access_token"`
	Scope       string `json:"scope"`
	ExpiresIn   int64  `json:"expires_in"`
	TokenType   string `json:"token_type"`
}

// refreshWithSessionToken 用 sessionToken 换 access token
//
// netcfg 控制出站是否走代理（受限网络下登录可能需要）。
func refreshWithSessionToken(sessionToken string, netcfg NetConfig) (string, int64, error) {
	// 关键：按 hex 解，不是 base64
	seed, err := hex.DecodeString(sessionToken)
	if err != nil {
		return "", 0, fmt.Errorf("sessionToken 不是合法 hex: %w", err)
	}

	idHex, key := deriveHawkCredentials(seed)

	body := map[string]any{
		"client_id":  fxaClientID,
		"grant_type": "fxa-credentials",
		"scope":      fxaScope,
		"ttl":        86400,
	}
	payloadBytes, _ := json.Marshal(body)
	payload := string(payloadBytes)

	hdr := hawkHeader(idHex, key, "POST", "/v1/oauth/token", payload)

	var rb []byte
	// 优先使用系统 curl 发送请求（避免 Akamai/Fastly WAF 对 Go net/http TLS ClientHello 指纹拦截返回 406）
	args := []string{"-s", "-i", fxaAPI + "/v1/oauth/token",
		"-H", "Content-Type: application/json",
		"-H", "Authorization: " + hdr,
		"-d", payload,
	}
	if netcfg.ProxyURL != "" {
		args = append(args, "-x", netcfg.ProxyURL)
	}
	if netcfg.Timeout > 0 {
		args = append(args, "--max-time", strconv.Itoa(netcfg.Timeout))
	} else {
		args = append(args, "--max-time", "15")
	}

	cmdOut, err := exec.Command("curl", args...).CombinedOutput()
	if err == nil && len(cmdOut) > 0 {
		parts := bytes.SplitN(cmdOut, []byte("\r\n\r\n"), 2)
		if len(parts) < 2 {
			parts = bytes.SplitN(cmdOut, []byte("\n\n"), 2)
		}
		if len(parts) == 2 {
			hdrPart := string(parts[0])
			if strings.Contains(hdrPart, " 200") {
				rb = parts[1]
			} else {
				statusLine := strings.SplitN(hdrPart, "\r\n", 2)[0]
				return "", 0, fmt.Errorf("oauth/token %s: %s", statusLine, truncate(string(parts[1]), 200))
			}
		}
	}

	// 若系统未安装 curl 或 curl 失败，回退到 Go net/http
	if len(rb) == 0 {
		req, err := http.NewRequest("POST", fxaAPI+"/v1/oauth/token",
			bytes.NewReader(payloadBytes))
		if err != nil {
			return "", 0, err
		}
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Authorization", hdr)

		hc, err := netcfg.client()
		if err != nil {
			return "", 0, err
		}
		resp, err := hc.Do(req)
		if err != nil {
			return "", 0, err
		}
		defer resp.Body.Close()
		rb, _ = io.ReadAll(resp.Body)

		if resp.StatusCode != 200 {
			return "", 0, fmt.Errorf("oauth/token 失败 %d: %s",
				resp.StatusCode, truncate(string(rb), 200))
		}
	}

	var out oauthTokenResp
	if err := json.Unmarshal(rb, &out); err != nil {
		return "", 0, err
	}
	if out.AccessToken == "" {
		return "", 0, fmt.Errorf("响应无 access_token: %s", truncate(string(rb), 200))
	}
	return out.AccessToken, out.ExpiresIn, nil
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}
