//go:build !linux

package main

// 非 Linux 平台（Windows/macOS）不需要调 /proc，
// socket 缓冲由 SetReadBuffer/SetWriteBuffer 直接生效，没有内核硬上限。

func tuneKernelBuffers() {}
