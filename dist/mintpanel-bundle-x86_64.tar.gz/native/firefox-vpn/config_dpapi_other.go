//go:build !windows

package main

// config_dpapi_other.go: 非 Windows 平台没有 DPAPI，
// 调用方会退到 AES（见 effectiveCipher），这里只需保证符号存在。

import "errors"

func dpapiEncrypt(plain string) (string, error) {
	return "", errors.New("DPAPI 仅在 Windows 上可用")
}

func dpapiDecrypt(enc string) (string, error) {
	return "", errors.New("DPAPI 仅在 Windows 上可用")
}
