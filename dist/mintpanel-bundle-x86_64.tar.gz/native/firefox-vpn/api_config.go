package main

// api_config.go: 配置相关的 HTTP 接口（界面读写配置文件）

import (
	"encoding/json"
	"net/http"
	"runtime"
)

// handleConfig 读取 / 更新配置
//   GET  /api/config          返回当前配置（token 已脱敏）
//   POST /api/config          部分更新（只改传入的字段）
func (a *AdminServer) handleConfig(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		c := GetConfig()
		writeJSON(w, map[string]any{
			"ok":          true,
			"path":        ConfigPath(),
			"profile":     c.Profile,
			"loginProxy":  c.LoginProxy,
			"listen":      c.Listen,
			"ipMode":      c.IPMode,
			"nodeIP":      c.NodeIP,
			"warm":        c.Warm,
			"node":        c.Node,
			"nodePort":    c.NodePort,
			"saveToken":   c.SaveToken,
			"hasToken":    c.SaveToken && (c.SessionTokenEnc != "" || c.SessionTokenPlain != ""),
			"tokenCipher": effectiveCipher(c.TokenCipher),
			"platform":    runtime.GOOS,
		})
		return
	}

	var req struct {
		Profile    *string `json:"profile"`
		LoginProxy *string `json:"loginProxy"`
		Listen     *string `json:"listen"`
		IPMode     *string `json:"ipMode"`
		NodeIP     *string `json:"nodeIP"`
		Warm       *int    `json:"warm"`
		Node       *string `json:"node"`
		NodePort   *int    `json:"nodePort"`
		SaveToken  *bool   `json:"saveToken"`
		TokenCipher *string `json:"tokenCipher"`
		// ClearToken 清掉已保存的 sessionToken
		ClearToken bool `json:"clearToken"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": "参数错误"})
		return
	}

	if req.ClearToken {
		if err := SaveSessionToken("", "", false); err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
			return
		}
	}

	err := UpdateConfig(func(c *Config) {
		if req.Profile != nil {
			c.Profile = *req.Profile
		}
		if req.LoginProxy != nil {
			c.LoginProxy = *req.LoginProxy
		}
		if req.Listen != nil {
			c.Listen = *req.Listen
		}
		if req.IPMode != nil {
			c.IPMode = *req.IPMode
		}
		if req.NodeIP != nil {
			c.NodeIP = *req.NodeIP
		}
		if req.Warm != nil {
			c.Warm = *req.Warm
		}
		if req.Node != nil {
			c.Node = *req.Node
		}
		if req.NodePort != nil {
			c.NodePort = *req.NodePort
		}
		if req.SaveToken != nil {
			c.SaveToken = *req.SaveToken
			if !*req.SaveToken {
				// 关开关 = 立刻删掉已存的凭证
				c.SessionTokenEnc = ""
				c.SessionTokenPlain = ""
			}
		}
		if req.TokenCipher != nil {
			c.TokenCipher = *req.TokenCipher
		}
	})
	if err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
		return
	}
	writeJSON(w, map[string]any{"ok": true, "path": ConfigPath()})
}

// rememberCurrentToken 把当前生效的 sessionToken 加密保存。
// 由界面在"记住登录"打开后调用。
func (a *AdminServer) rememberCurrentToken(tok string) error {
	c := GetConfig()
	return SaveSessionToken(tok, c.TokenCipher, true)
}

// handleTokenRemember 保存当前生效的 sessionToken（加密）
func (a *AdminServer) handleTokenRemember(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeJSON(w, map[string]any{"ok": false, "error": "仅支持 POST"})
		return
	}
	if a.tr == nil || a.tr.ts == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "未启用"})
		return
	}
	tok := a.tr.ts.sessionToken
	if tok == "" {
		writeJSON(w, map[string]any{"ok": false,
			"error": "当前没有可保存的 sessionToken（access token 无法长期续期）"})
		return
	}
	if err := a.rememberCurrentToken(tok); err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
		return
	}
	c := GetConfig()
	writeJSON(w, map[string]any{"ok": true, "cipher": effectiveCipher(c.TokenCipher)})
}
