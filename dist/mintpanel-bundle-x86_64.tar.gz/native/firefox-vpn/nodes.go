package main

// nodes.go: 节点列表与运行时切换
//
// 隧道节点从启动参数固定在 Dialer.node 里，无法热切换。
// 这里引入 NodeSwitch：Dialer 每次拨号时读取当前节点，
// 切换只需原子地改一个指针，已建成的连接不受影响。

import (
	"encoding/json"
	"fmt"
	"log"
	"net"
	"net/http"
	"sort"
	"sync"
	"sync/atomic"
	"time"
)

// Node 一个 IPP 出口节点
type Node struct {
	Code string `json:"code"` // 国家码，如 KR
	Name string `json:"name"` // 国家名，如 Korea
	Host string `json:"host"` // icn145.m1.fastly-masque.net
	Port int    `json:"port"` // 2499
}

// Addr 返回 host:port
func (n Node) Addr() string { return fmt.Sprintf("%s:%d", n.Host, n.Port) }

// Label 展示用
func (n Node) Label() string { return n.Code + " " + n.Name }

// NodeSwitch 持有当前节点，支持原子切换
type NodeSwitch struct {
	cur  atomic.Value // 存 Node
	mu   sync.Mutex   // 串行化切换
	all  []Node
	prev string // 上一个节点 host，用于回退
}

// NewNodeSwitch 用给定节点初始化
func NewNodeSwitch(nodes []Node, current Node) *NodeSwitch {
	ns := &NodeSwitch{all: nodes}
	ns.cur.Store(current)
	return ns
}

// Current 当前节点
func (ns *NodeSwitch) Current() Node {
	return ns.cur.Load().(Node)
}

// All 全部节点
func (ns *NodeSwitch) All() []Node { return ns.all }

// Switch 切换到指定节点（按 host 匹配）
func (ns *NodeSwitch) Switch(host string) (Node, error) {
	ns.mu.Lock()
	defer ns.mu.Unlock()

	var target *Node
	for i := range ns.all {
		if ns.all[i].Host == host || ns.all[i].Addr() == host {
			target = &ns.all[i]
			break
		}
	}
	if target == nil {
		return Node{}, fmt.Errorf("未知节点: %s", host)
	}

	// 先探活，避免切到一个死节点上
	if err := probeNode(*target); err != nil {
		return Node{}, fmt.Errorf("节点 %s 不可用: %w", target.Label(), err)
	}

	ns.prev = ns.Current().Host
	ns.cur.Store(*target)
	log.Printf("[node] 已切换到 %s (%s)", target.Label(), target.Host)
	return *target, nil
}

// Rollback 回退到上一个节点
func (ns *NodeSwitch) Rollback() (Node, error) {
	ns.mu.Lock()
	prev := ns.prev
	ns.mu.Unlock()
	if prev == "" {
		return Node{}, fmt.Errorf("没有可回退的节点")
	}
	return ns.Switch(prev)
}

// probeNode 发一个 TCP 连接测试节点是否可连
//
// 不在这里做完整 CONNECT，因为那要消耗一次 pass；
// 只要 TLS 层能连通就认为节点活着。
func probeNode(n Node) error {
	c, err := dialNodeTCP(n)
	if err != nil {
		return err
	}
	c.Close()
	return nil
}

// FetchNodeList 从 Mozilla settings 服务拉取全部可用节点
//
// 转成扁平的 []Node，供管理页面列示。
func FetchNodeList(defaultPort int) ([]Node, error) {
	countries, err := FetchServers()
	if err != nil {
		return nil, err
	}

	var out []Node
	for _, c := range countries {
		for _, ci := range c.Cities {
			for _, s := range ci.Servers {
				if s.Quarantined {
					continue
				}
				p := s.Port
				if p == 0 {
					p = defaultPort
				}
				out = append(out, Node{
					Code: c.Code,
					Name: c.Name,
					Host: s.Hostname,
					Port: p,
				})
			}
		}
	}

	sort.Slice(out, func(i, j int) bool {
		if out[i].Code != out[j].Code {
			return out[i].Code < out[j].Code
		}
		return out[i].Host < out[j].Host
	})
	return out, nil
}

// ---------- 管理接口 ----------

// AdminServer 提供节点选择页面与切换 API
type AdminServer struct {
	ns       *NodeSwitch
	node     Node // 启动时的默认节点
	pm       *PassManager
	listen   string
	tr       *tokenRuntime // token 状态（可热替换）
	svc      *ProxyService // 代理服务管理
	d        *Dialer       // 用于热切换 IP 模式
	lastAddr string        // 用户上次填的监听地址

	// 延迟探测缓存
	pingMu    sync.Mutex
	pingCache map[string]int64
	pingAt    time.Time
}

// routes 构造路由表
func (a *AdminServer) routes() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("/", a.handleIndex)
	mux.HandleFunc("/api/nodes", a.handleNodes)
	mux.HandleFunc("/api/ping", a.handlePing)
	mux.HandleFunc("/api/switch", a.handleSwitch)
	mux.HandleFunc("/api/status", a.handleStatus)
	mux.HandleFunc("/api/token", a.handleToken)
	mux.HandleFunc("/api/token/refresh", a.handleRefresh)
	mux.HandleFunc("/api/login-proxy", a.handleLoginProxy)
	mux.HandleFunc("/api/profiles", a.handleProfiles)
	mux.HandleFunc("/api/profile", a.handleProfileSet)
	mux.HandleFunc("/api/service", a.handleService)
	mux.HandleFunc("/api/h3", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, h3p.Stats())
	})
	mux.HandleFunc("/api/service/", a.handleServiceAction)
	mux.HandleFunc("/api/ipmode", a.handleIPMode)
	mux.HandleFunc("/api/nodeip", a.handleNodeIP)
	mux.HandleFunc("/api/pass", a.handlePass)
	mux.HandleFunc("/api/warm", a.handleWarm)
	mux.HandleFunc("/api/config", a.handleConfig)
	mux.HandleFunc("/api/token/remember", a.handleTokenRemember)
	return mux
}

// listenOn 先占住端口（支持 :0 交给系统分配）
func (a *AdminServer) listenOn(addr string) (net.Listener, error) {
	if addr == "" {
		addr = "127.0.0.1:0"
	}
	return net.Listen("tcp", addr)
}

// serveOn 在已就绪的 listener 上提供服务
func (a *AdminServer) serveOn(ln net.Listener) error {
	srv := &http.Server{Handler: a.routes()}
	return srv.Serve(ln)
}

func (a *AdminServer) Serve() error {
	ln, err := a.listenOn(a.listen)
	if err != nil {
		return err
	}
	log.Printf("[admin] 管理页面 -> http://%s/", ln.Addr().String())
	return a.serveOn(ln)
}

type nodeView struct {
	Node
	Current  bool   `json:"current"`
	ExitIP   string `json:"exitIP,omitempty"`
	Latency  int64  `json:"latency,omitempty"`
	Disabled bool   `json:"disabled,omitempty"`
	Error    string `json:"error,omitempty"`
}

func (a *AdminServer) handleNodes(w http.ResponseWriter, r *http.Request) {
	cur := a.ns.Current()
	out := make([]nodeView, 0, len(a.ns.All()))
	for _, n := range a.ns.All() {
		out = append(out, nodeView{Node: n, Current: n.Host == cur.Host})
	}
	writeJSON(w, map[string]any{
		"nodes":   out,
		"current": cur,
	})
}

// handlePing 并发探测所有节点延迟
//
// GET /api/ping -> {"latency":{"host":ms}, "took":ms}
// 结果会缓存，避免频繁点击把节点打爆。
func (a *AdminServer) handlePing(w http.ResponseWriter, r *http.Request) {
	a.pingMu.Lock()
	defer a.pingMu.Unlock()

	// 60 秒内重复请求直接用缓存（?force=1 强制刷新）
	force := r.URL.Query().Get("force") != ""
	if !force && a.pingCache != nil && time.Since(a.pingAt) < 60*time.Second {
		writeJSON(w, map[string]any{
			"latency": a.pingCache,
			"cached":  true,
			"at":      a.pingAt.Format("15:04:05"),
		})
		return
	}

	start := time.Now()
	lat := pingAll(a.ns.All(), 12)
	a.pingCache = lat
	a.pingAt = time.Now()

	writeJSON(w, map[string]any{
		"latency": lat,
		"cached":  false,
		"took":    time.Since(start).Milliseconds(),
		"at":      a.pingAt.Format("15:04:05"),
	})
}

func (a *AdminServer) handleSwitch(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "需要 POST", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Host string `json:"host"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "参数错误: "+err.Error(), http.StatusBadRequest)
		return
	}

	prev := a.ns.Current()
	px := a.svc.Proxy()
	if px == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "代理未初始化"})
		return
	}

	// 关键：先断开旧节点的所有连接，再切换，两者绝不并存。
	// 不等待排空是为了切换够快——视频这类长连接会把等待拖到数秒。
	// 代价是旧连接上的请求会失败一次，浏览器会自动重发到新节点。
	t0 := time.Now()
	var switched Node
	info, err := px.DrainAndSwitch(func() error {
		n, serr := a.ns.Switch(req.Host)
		if serr != nil {
			return serr
		}
		switched = n
		// 丢弃旧节点的预热连接与 QUIC 连接，并为新节点重新预热
		warmer.Reset(n)
		if n := h3Reset(); n > 0 {
			log.Printf("[h3] 已关闭 %d 条旧 QUIC 连接", n)
		}
		return nil
	})
	if err != nil {
		writeJSON(w, map[string]any{
			"ok":    false,
			"error": err.Error(),
			"drain": map[string]any{"before": info.Before, "after": info.After},
		})
		return
	}

	log.Printf("[switch] %s -> %s（断开 %d 条旧连接，耗时 %v）",
		prev.Label(), switched.Label(), info.Before,
		time.Since(t0).Round(time.Millisecond))

	// 切换后立刻实测出口 IP
	exitIP, lat, terr := testNode(switched, a.pm)
	resp := map[string]any{
		"ok":      true,
		"node":    switched,
		"prev":    prev,
		"exitIP":  exitIP,
		"latency": lat,
		"drain": map[string]any{
			"before": info.Before,
			"after":  info.After,
			"forced": info.Forced,
			"took":   time.Since(t0).Milliseconds(),
		},
	}
	if terr != nil {
		resp["warn"] = terr.Error()
	}
	writeJSON(w, resp)
}

func (a *AdminServer) handleStatus(w http.ResponseWriter, r *http.Request) {
	cur := a.ns.Current()
	writeJSON(w, map[string]any{
		"current": cur,
		"total":   len(a.ns.All()),
	})
}

func (a *AdminServer) handleIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write([]byte(indexHTML))
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(v)
}
