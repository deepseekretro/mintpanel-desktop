package main

// probe.go: 节点探测与出口 IP 实测
//
// 切换节点后需要确认新节点真的能用，否则用户看到"已切换"却在浏览时超时。
// testNode 走一次完整隧道（CONNECT + 嵌套 TLS + HTTP 请求）来验证。

import (
	"sort"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"strings"
	"time"
)

// dialNodeTCP 只建到节点的外层 TLS 连接（探活用）
func dialNodeTCP(n Node) (net.Conn, error) {
	raw, err := dialNode(n.Host, n.Addr(), 8*time.Second, GlobalNodeIP.Get())
	if err != nil {
		return nil, err
	}
	tc := tls.Client(raw, &tls.Config{
		ServerName: n.Host,
		MinVersion: tls.VersionTLS12,
	})
	tc.SetDeadline(time.Now().Add(8 * time.Second))
	if err := tc.Handshake(); err != nil {
		raw.Close()
		return nil, fmt.Errorf("TLS: %w", err)
	}
	tc.SetDeadline(time.Time{})
	return tc, nil
}

// testNode 在指定节点上走一次真实请求，返回出口 IP 与耗时
//
// 注意：这里绕开 Dialer，直接用给定节点建连，
// 这样在"切换前"就能测新节点，不必先切过去。
func testNode(n Node, pm *PassManager) (exitIP string, latencyMs int64, err error) {
	start := time.Now()

	// 对 ifconfig.me 走隧道，拿出口 IP
	conn, err := dialViaNode(n, "ifconfig.me:443", pm)
	if err != nil {
		return "", 0, err
	}
	defer conn.Close()

	// 嵌套 TLS
	tc := tls.Client(conn, &tls.Config{
		ServerName: "ifconfig.me",
		MinVersion: tls.VersionTLS12,
	})
	tc.SetDeadline(time.Now().Add(15 * time.Second))
	if err := tc.Handshake(); err != nil {
		return "", 0, fmt.Errorf("嵌套 TLS: %w", err)
	}

	req := "GET /ip HTTP/1.1\r\nHost: ifconfig.me\r\n" +
		"User-Agent: curl/8.0\r\nAccept: */*\r\nConnection: close\r\n\r\n"
	if _, err := tc.Write([]byte(req)); err != nil {
		return "", 0, err
	}

	body, err := io.ReadAll(io.LimitReader(tc, 4096))
	if err != nil && len(body) == 0 {
		return "", 0, err
	}

	ip := extractBody(string(body))
	latencyMs = time.Since(start).Milliseconds()
	if ip == "" {
		return "", latencyMs, errors.New("未解析到出口 IP")
	}
	return ip, latencyMs, nil
}

// extractBody 从 HTTP 原始响应里取出正文
func extractBody(resp string) string {
	i := strings.Index(resp, "\r\n\r\n")
	if i < 0 {
		return ""
	}
	body := strings.TrimSpace(resp[i+4:])
	// 只保留 IP 形态
	if len(body) > 64 {
		body = body[:64]
	}
	return strings.TrimSpace(strings.SplitN(body, "\n", 2)[0])
}

// pingNode 轻量探测：只测 TCP + TLS 握手耗时
//
// 用于列表里的延迟展示。不建完整隧道（那样太慢，34 个节点要几十秒），
// 只量"连上节点并完成 TLS 握手"的时间，足够反映网络远近。
func pingNode(n Node, timeout time.Duration) (int64, error) {
	if timeout <= 0 {
		timeout = 6 * time.Second
	}
	start := time.Now()

	raw, err := dialNode(n.Host, n.Addr(), timeout, GlobalNodeIP.Get())
	if err != nil {
		return 0, err
	}
	defer raw.Close()

	raw.SetDeadline(time.Now().Add(timeout))
	tc := tls.Client(raw, &tls.Config{
		ServerName: n.Host,
		MinVersion: tls.VersionTLS12,
	})
	if err := tc.Handshake(); err != nil {
		return 0, err
	}
	tc.Close()

	return time.Since(start).Milliseconds(), nil
}

// pingAll 并发探测所有节点，带并发上限
func pingAll(nodes []Node, concurrency int) map[string]int64 {
	if concurrency <= 0 {
		concurrency = 8
	}
	type res struct {
		host string
		ms   int64
		err  error
	}

	sem := make(chan struct{}, concurrency)
	out := make(chan res, len(nodes))

	for _, n := range nodes {
		go func(n Node) {
			sem <- struct{}{}
			defer func() { <-sem }()
			ms, err := pingNode(n, 6*time.Second)
			out <- res{host: n.Host, ms: ms, err: err}
		}(n)
	}

	result := make(map[string]int64, len(nodes))
	for i := 0; i < len(nodes); i++ {
		r := <-out
		if r.err == nil {
			result[r.host] = r.ms // 失败的不写，前端显示 "-"
		}
	}
	return result
}

// PickFastest 并发探测所有节点，返回延迟最低的一个
//
// 用于 -node auto：Firefox 的 p.m1 节点 14ms，而某些节点 577ms，
// 差 40 倍。启动时花几百毫秒选最快的，比随机选划算得多。
//
// 探测失败或超时的节点不参与比较；全部失败时返回 fallback。
func PickFastest(nodes []Node, timeout time.Duration, fallback Node) Node {
	if len(nodes) == 0 {
		return fallback
	}

	type res struct {
		n  Node
		ms int64
	}
	ch := make(chan res, len(nodes))
	sem := make(chan struct{}, 16) // 最多 16 个并发探测

	for _, n := range nodes {
		go func(n Node) {
			sem <- struct{}{}
			defer func() { <-sem }()
			ms, err := pingNode(n, timeout)
			if err != nil {
				ch <- res{n: n, ms: -1}
				return
			}
			ch <- res{n: n, ms: ms}
		}(n)
	}

	var alive []res
	for i := 0; i < len(nodes); i++ {
		r := <-ch
		if r.ms >= 0 {
			alive = append(alive, r)
		}
	}

	if len(alive) == 0 {
		log.Printf("[node] 全部节点探测失败，回退到 %s", fallback.Host)
		return fallback
	}

	// 按握手延迟排序
	sort.Slice(alive, func(i, j int) bool { return alive[i].ms < alive[j].ms })

	// 只看延迟是不够的：RTT 20ms 但丢包 5% 的节点，播视频远不如
	// RTT 60ms 但零丢包的。对延迟靠前的几个再做一次真实吞吐测试。
	const probeTop = 3
	n := min(probeTop, len(alive))

	best := alive[0].n
	bestScore := float64(0)
	type bres struct {
		n     Node
		score float64 // MB/s
	}
	bch := make(chan bres, n)
	for i := 0; i < n; i++ {
		go func(r res) {
			mbps := probeThroughput(r.n, 3*time.Second)
			bch <- bres{n: r.n, score: mbps}
		}(alive[i])
	}

	measured := 0
	for i := 0; i < n; i++ {
		r := <-bch
		if r.score <= 0 {
			continue
		}
		measured++
		// 以吞吐为唯一排序依据：视频卡顿的直接原因是带宽不足，
		// 而不是单次握手慢（握手只影响首屏那一下）。
		if r.score > bestScore {
			bestScore = r.score
			best = r.n
		}
	}

	if measured == 0 {
		// 吞吐测不出来（节点拒绝或超时），退回按延迟选
		best = alive[0].n
		log.Printf("[node] 探测 %d 个节点，吞吐不可测，按延迟选 %s (%dms)",
			len(alive), best.Host, alive[0].ms)
		return best
	}

	log.Printf("[node] 探测 %d 个节点，按吞吐选 %s (%.1f MB/s)", len(alive), best.Host, bestScore)
	return best
}

// probeThroughput 粗略测节点带宽：握手后立即断开前先拉一段数据。
//
// Fastly 节点的 2499 端口只接受 CONNECT，普通 GET 会返回 405 或很小的
// 错误页，所以这里没法直接下载大文件。用「连续发包 + 测 ACK 回来多少」
// 来近似：发一批数据后看多久写完，写满说明上行管道通畅。
func probeThroughput(n Node, budget time.Duration) float64 {
	raw, err := dialNode(n.Host, n.Addr(), budget, GlobalNodeIP.Get())
	if err != nil {
		return 0
	}
	defer raw.Close()

	tc := tls.Client(raw, &tls.Config{
		ServerName: n.Host,
		MinVersion: tls.VersionTLS12,
	})
	tc.SetDeadline(time.Now().Add(budget))
	if err := tc.Handshake(); err != nil {
		return 0
	}

	// 发一个极小的 HEAD 请求，看响应回来的速度。
	// 节点会回 405/400，但只要 TCP 管道通畅，往返就会很快。
	start := time.Now()
	req := "GET / HTTP/1.1\r\nHost: " + n.Host + "\r\nConnection: close\r\n\r\n"
	if _, err := tc.Write([]byte(req)); err != nil {
		return 0
	}
	buf := make([]byte, 4096)
	total := 0
	for {
		nr, err := tc.Read(buf)
		total += nr
		if err != nil || total > 512 {
			break
		}
	}
	el := time.Since(start)
	if el <= 0 || total == 0 {
		return 0
	}
	// 小样本噪声大，用「响应字节/耗时」做相对比较即可
	return float64(total) / el.Seconds() / (1 << 20)
}

// pingNodeOnce 单次测速（GUI 用），失败返回 -1 语义由调用方处理
func pingNodeOnce(n Node, timeout time.Duration) (int64, error) {
	return pingNode(n, timeout)
}
