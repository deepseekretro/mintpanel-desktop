package main

// netcfg.go: 出站网络配置（登录时可走代理）
//
// 场景：客户端在受限网络里，accounts.firefox.com 直连不通，
// 但用户手里有一个可用的 HTTP/SOCKS5 代理。
// 这时让 FxA 登录请求走代理，拿到 token。
//
// 注意：这只是"换 token 那一下"用代理；
// 真正的 IPP 隧道仍然直连 Fastly 节点（那条链自己就带 TLS+认证）。

import (
	"fmt"
	"net"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
)

// NetConfig 出站网络配置
const (
	// DefaultLoginProxy 登录换 token 时的默认出站代理
	DefaultLoginProxy = "http://127.0.0.1:8080"
	// DefaultListenAddr 本地代理默认监听地址
	DefaultListenAddr = "127.0.0.1:10909"
)

type NetConfig struct {
	// ProxyURL 形如 http://127.0.0.1:8080 或 socks5://127.0.0.1:1080
	// 空 = 直连
	ProxyURL string `json:"proxyURL"`
	// Timeout 秒
	Timeout int `json:"timeout"`
}

// DefaultNetConfig 返回默认的出站配置
//
// 默认走本机 127.0.0.1:8080 的 HTTP 代理（该端口通常由 mihomo/clash
// 或其他本地代理占用）。可用 -login-proxy 或环境变量覆盖：
//
//	IPP_LOGIN_PROXY / HTTPS_PROXY / https_proxy
//
// 显式传 -login-proxy ""（空串）且环境变量为空时，才回退为直连。
func DefaultNetConfig() NetConfig {
	c := NetConfig{Timeout: 30}

	for _, k := range []string{"IPP_LOGIN_PROXY", "HTTPS_PROXY", "https_proxy"} {
		if p := strings.TrimSpace(os.Getenv(k)); p != "" {
			c.ProxyURL = p
			return c
		}
	}

	// 全部未设置时用本地代理
	c.ProxyURL = DefaultLoginProxy
	return c
}

// client 构造按配置走代理的 HTTP 客户端
//
// 支持 http:// / https:// / socks5:// 三种代理 URL。
// Go 标准库的 http.Transport 只原生支持 http(s) 代理，
// socks5 需要自己提供 DialContext。
func (c NetConfig) client() (*http.Client, error) {
	timeout := time.Duration(c.Timeout) * time.Second
	if timeout <= 0 {
		timeout = 30 * time.Second
	}

	tr := &http.Transport{
		DialContext:         (&net.Dialer{Timeout: 15 * time.Second}).DialContext,
		TLSHandshakeTimeout: 15 * time.Second,
	}

	if c.ProxyURL != "" {
		u, err := url.Parse(c.ProxyURL)
		if err != nil {
			return nil, fmt.Errorf("代理地址无效: %w", err)
		}
		switch u.Scheme {
		case "http", "https":
			tr.Proxy = http.ProxyURL(u)
		case "socks5", "socks5h":
			d := &socks5Dialer{proxy: u}
			tr.DialContext = d.DialContext
		case "":
			// 没写 scheme，按 http 处理
			u.Scheme = "http"
			tr.Proxy = http.ProxyURL(u)
		default:
			return nil, fmt.Errorf("不支持的代理协议: %s（用 http / https / socks5）", u.Scheme)
		}
	}

	return &http.Client{Timeout: timeout, Transport: tr}, nil
}

// TestConnectivity 测试能否连通 Mozilla 的登录端点
//
// 返回延迟与错误；用来在界面上给用户"测试代理"按钮用。
func (c NetConfig) TestConnectivity() (int64, error) {
	hc, err := c.client()
	if err != nil {
		return 0, err
	}
	start := time.Now()
	resp, err := hc.Get("https://api.accounts.firefox.com/__heartbeat__")
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	ms := time.Since(start).Milliseconds()
	if resp.StatusCode >= 400 {
		return ms, fmt.Errorf("健康检查返回 %d", resp.StatusCode)
	}
	return ms, nil
}
