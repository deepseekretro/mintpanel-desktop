package main

// api_token.go: token 状态与登录配置的管理接口
//
// 界面需要的：
//   GET  /api/token    当前 token 状态（含倒计时秒数）
//   POST /api/token    手动设置 sessionToken / access token
//   POST /api/login-proxy  测试登录用的出站代理
//   GET  /api/config   当前登录出站配置

import (
	"encoding/json"
	"log"
	"net/http"
	"time"
)

// tokenStatus 给前端用的 token 状态
type tokenStatus struct {
	// Valid 当前是否有可用 token
	Valid bool `json:"valid"`
	Email string `json:"email,omitempty"`
	UID string `json:"uid,omitempty"`
	// Source 来源: "session"(可续期) / "access"(只读，会过期) / "none"
	Source string `json:"source"`
	// CanRefresh 能否自动续期
	CanRefresh bool `json:"canRefresh"`
	// ExpiresAt 过期时间（Unix 秒）
	ExpiresAt int64 `json:"expiresAt"`
	// ExpiresAtText 过期时间（可读）
	ExpiresAtText string `json:"expiresAtText"`
	// RemainingSec 剩余秒数（前端据此倒计时）
	RemainingSec int64 `json:"remainingSec"`
	// RefreshInSec 距离自动续期还有多少秒（= remaining - 60）
	RefreshInSec int64 `json:"refreshInSec"`
	// Profile 来源 profile 路径
	Profile string `json:"profile,omitempty"`
	// Error 最近一次错误
	Error string `json:"error,omitempty"`
}

// tokenRuntime 管理当前生效的 TokenSource（可热替换）
type tokenRuntime struct {
	ts      *TokenSource
	net     *NetStore // 共享出站配置
	lastErr string
}

func newTokenRuntime(ts *TokenSource, net *NetStore) *tokenRuntime {
	return &tokenRuntime{ts: ts, net: net}
}

// getNet 传给新建的 TokenSource，保持共享配置
func (tr *tokenRuntime) getNet() *NetConfig {
	if tr.net == nil {
		return nil
	}
	return tr.net.Get()
}

// Status 汇总状态
func (tr *tokenRuntime) Status() tokenStatus {
	st := tokenStatus{Source: "none"}

	if tr.ts == nil {
		st.Error = tr.lastErr
		return st
	}
	st.Email = tr.ts.email
	st.UID = tr.ts.uid

	exp := tr.ts.Expiry()
	if !exp.IsZero() {
		st.ExpiresAt = exp.Unix()
		st.ExpiresAtText = exp.Format("2006-01-02 15:04:05")
		st.RemainingSec = int64(time.Until(exp).Seconds())
		// 与 Firefox 一致：剩余不足 60 秒时续期
		st.RefreshInSec = st.RemainingSec - oauthMinTimeLeftSecs
	}
	st.CanRefresh = tr.ts.CanRefresh()
	if st.CanRefresh {
		st.Source = "session"
	} else if st.ExpiresAt > 0 {
		st.Source = "access"
	}
	st.Valid = st.RemainingSec > 0
	st.Profile = tr.ts.path
	st.Error = tr.lastErr
	return st
}

// SetSessionToken 用新的 sessionToken 替换（界面粘贴用）
func (tr *tokenRuntime) SetSessionToken(tok, email, uid string) error {
	ts := &TokenSource{
		sessionToken: tok,
		email:        email,
		uid:          uid,
		getNet:       tr.getNet,
	}
	if err := ts.refresh(); err != nil {
		tr.lastErr = "sessionToken 无效: " + err.Error()
		return err
	}
	tr.ts = ts
	tr.lastErr = ""
	return nil
}

// SetAccessToken 直接设置 access token（只读，不可续期）
func (tr *tokenRuntime) SetAccessToken(tok string) {
	tr.ts = &TokenSource{
		cached: tok,
		expiry: time.Now().Add(24 * time.Hour).Unix(),
		getNet: tr.getNet,
	}
	tr.lastErr = ""
}

// ---------- HTTP 处理 ----------

func (a *AdminServer) handleToken(w http.ResponseWriter, r *http.Request) {
	if a.tr == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "token 管理未启用"})
		return
	}

	switch r.Method {
	case http.MethodGet:
		writeJSON(w, a.tr.Status())

	case http.MethodPost:
		var req struct {
			// Session token（可续期）
			SessionToken string `json:"sessionToken"`
			// Access token（只读）
			AccessToken string `json:"accessToken"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": "参数错误: " + err.Error()})
			return
		}

		if req.SessionToken != "" {
			if err := a.tr.SetSessionToken(req.SessionToken, "", ""); err != nil {
				writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
				return
			}
			writeJSON(w, map[string]any{"ok": true, "status": a.tr.Status()})
			return
		}

		if req.AccessToken != "" {
			a.tr.SetAccessToken(req.AccessToken)
			writeJSON(w, map[string]any{"ok": true, "status": a.tr.Status()})
			return
		}

		writeJSON(w, map[string]any{"ok": false, "error": "需要 sessionToken 或 accessToken"})

	default:
		http.Error(w, "方法不允许", http.StatusMethodNotAllowed)
	}
}

// handleLoginProxy 测试或设置登录出站代理
func (a *AdminServer) handleLoginProxy(w http.ResponseWriter, r *http.Request) {
	if a.tr == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "未启用"})
		return
	}

	switch r.Method {
	case http.MethodGet:
		writeJSON(w, map[string]any{
			"proxyURL": a.tr.net.ProxyURL(),
			"timeout":  a.tr.net.Timeout(),
		})

	case http.MethodPost:
		var req struct {
			ProxyURL string `json:"proxyURL"`
			Timeout  int    `json:"timeout"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
			return
		}
		if req.Timeout <= 0 {
			req.Timeout = 30
		}
		nc := NetConfig{ProxyURL: req.ProxyURL, Timeout: req.Timeout}

		// 先测连通（会真的访问 vpn.mozilla.org，能直接发现 451）
		ms, err := nc.TestConnectivity()
		if err != nil {
			writeJSON(w, map[string]any{
				"ok":    false,
				"error": "连通失败: " + err.Error(),
			})
			return
		}

		// 写入共享配置：token 刷新和取 pass 都立即走新代理
		a.tr.net.Set(nc)
		log.Printf("[auth] 出站代理已更新 -> %q", req.ProxyURL)

		// 马上试一次取 pass，让用户立即知道能否用
		res := map[string]any{"ok": true, "latencyMs": ms}
		if a.pm != nil {
			if err := a.pm.Refresh(); err != nil {
				res["passOk"] = false
				res["passError"] = err.Error()
			} else {
				res["passOk"] = true
			}
		}
		writeJSON(w, res)

	default:
		http.Error(w, "方法不允许", http.StatusMethodNotAllowed)
	}
}

// handleRefresh 手动触发一次续期
func (a *AdminServer) handleRefresh(w http.ResponseWriter, r *http.Request) {
	if a.tr == nil || a.tr.ts == nil {
		writeJSON(w, map[string]any{"ok": false, "error": "无 token 源"})
		return
	}
	if !a.tr.ts.CanRefresh() {
		writeJSON(w, map[string]any{"ok": false, "error": "当前 token 不可续期（只读）"})
		return
	}
	if err := a.tr.ts.refresh(); err != nil {
		writeJSON(w, map[string]any{"ok": false, "error": err.Error()})
		return
	}
	writeJSON(w, map[string]any{"ok": true, "status": a.tr.Status()})
}
