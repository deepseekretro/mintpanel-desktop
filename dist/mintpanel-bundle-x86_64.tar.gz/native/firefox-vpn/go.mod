module ipp-gost

go 1.27.3

require (
	github.com/egoist/mygo v0.8.3
	github.com/quic-go/quic-go v0.65.0
	golang.org/x/sys v0.50.0
)

require (
	github.com/ebitengine/purego v0.11.1 // indirect
	github.com/go-text/typesetting v0.3.5 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	golang.org/x/crypto v0.57.0 // indirect
	golang.org/x/image v0.46.0 // indirect
	golang.org/x/net v0.59.0 // indirect
	golang.org/x/text v0.43.0 // indirect
)
