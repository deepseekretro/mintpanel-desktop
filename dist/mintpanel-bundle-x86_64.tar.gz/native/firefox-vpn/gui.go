//go:build !cshared

package main

// 桌面模式：用内嵌 webview 显示与浏览器完全相同的管理界面。
//
// 做法：本地起一个只监听 127.0.0.1 的管理服务（端口由系统分配），
// webview 直接加载 http://127.0.0.1:PORT/。界面代码复用 ui.go 里的
// indexHTML，功能代码复用 nodes.go 的 AdminServer，零重复实现。

import (
	"fmt"
	"log"
	"strings"

	"github.com/egoist/mygo"
	"github.com/egoist/mygo/ui"
)

// guiOptions 桌面模式的启动参数
type guiOptions struct {
	ns       *NodeSwitch
	pm       *PassManager
	tr       *tokenRuntime
	svc      *ProxyService
	d        *Dialer
	listen   string // 管理服务监听地址，默认 127.0.0.1:0
	title    string
	onURL    func(string) // 拿到真实 URL 后回调（便于日志/调试）
	width    int
	height   int
	webTitle string
}

// runGUI 启动桌面窗口，内嵌显示管理界面。
// 阻塞直到窗口关闭。
func runGUI(opt guiOptions) error {
	a := &AdminServer{ns: opt.ns, pm: opt.pm, tr: opt.tr, svc: opt.svc, d: opt.d, }

	listenAddr := strings.TrimSpace(opt.listen)
	if listenAddr == "" {
		listenAddr = "127.0.0.1:0"
	}
	ln, err := a.listenOn(listenAddr)
	if err != nil {
		return fmt.Errorf("管理服务监听失败: %w", err)
	}
	url := adminURL(ln.Addr().String())
	log.Printf("[gui] 内嵌界面 -> %s", url)

	go func() {
		if err := a.serveOn(ln); err != nil {
			log.Printf("[gui] 管理服务退出: %v", err)
		}
	}()

	if opt.onURL != nil {
		opt.onURL(url)
	}

	title := opt.title
	if title == "" {
		title = "FireFox VPN"
	}
	w, h := opt.width, opt.height
	if w <= 0 {
		w = 1180
	}
	if h <= 0 {
		h = 820
	}

	mygo.App.WhenReady(func() {
		win := mygo.NewWindow(mygo.WindowOptions{
			// 固定尺寸：最小/最大都设成同一值，再关掉缩放与最大化，
			// 双保险防止某些平台上仍能拖拽改变大小。
			Title:           title,
			Width:           w,
			Height:          h,
			MinWidth:        w,
			MaxWidth:        w,
			MinHeight:       h,
			MaxHeight:       h,
			DisableResize:   true,
			DisableMaximize: true,
			Content: ui.View(func(c *ui.Context) {
				// webview 覆盖整个内容区；构建完成前先给个占位提示，
				// 避免首帧白屏。
				if v := currentWebView(); v != nil {
					ui.WebView(c, v).Grow(1)
					return
				}
				ui.Column(c).Fill().Center().Children(func() {
					ui.Text(c, "正在加载界面…").FontSize(14)
				})
			}),
		})

		v, verr := win.NewWebView(mygo.WebViewOptions{URL: url})
		if verr != nil {
			log.Printf("[gui] webview 创建失败: %v", verr)
			return
		}
		setWebView(v)
		win.Invalidate()
	})

	return mygo.App.Run()
}

// ---- 当前 webview（供视图回调读取） ----

var (
	curView   *mygo.WebView
	curViewOK bool
)

func setWebView(v *mygo.WebView) { curView, curViewOK = v, v != nil }

func currentWebView() *mygo.WebView {
	if !curViewOK {
		return nil
	}
	return curView
}
