//go:build cshared

package main

type guiOptions struct {
ns       *NodeSwitch
pm       *PassManager
tr       *tokenRuntime
svc      *ProxyService
d        *Dialer
listen   string
title    string
onURL    func(string)
width    int
height   int
webTitle string
}

func runGUI(opt guiOptions) error {
return nil
}
