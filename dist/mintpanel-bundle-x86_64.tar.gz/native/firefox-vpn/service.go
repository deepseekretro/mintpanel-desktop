package main

// service.go: 代理服务的运行控制（可在界面里启停/改端口）
//
// 之前代理在 main 里直接 Listen，改端口得重启进程。
// 现在统一交给 ProxyService 管理：
//   - Start(addr) 启动
//   - Stop()      停止
//   - Restart(addr) 改端口
//
// 用 atomic 保存当前 listener，Stop 时关掉它，accept 循环自然退出。

import (
	"errors"
	"fmt"
	"log"
	"net"
	"sync"
	"time"
)

// ServiceState 当前服务状态
type ServiceState struct {
	// Running 是否在运行
	Running bool `json:"running"`
	// Addr 实际监听地址（如 127.0.0.1:1080）
	Addr string `json:"addr"`
	// Error 最近一次错误
	Error string `json:"error"`
	// StartedAt 启动时间
	StartedAt string `json:"startedAt,omitempty"`
	// Conns 自启动以来接受的连接数
	Conns int64 `json:"conns"`
	// Errs 自启动以来的错误数
	Errs int64 `json:"errs"`
	// Active 当前活跃隧道数（切换节点时排空的依据）
	Active int64 `json:"active"`
	// BytesIn 累计下行字节
	BytesIn int64 `json:"bytesIn"`
	// BytesOut 累计上行字节
	BytesOut int64 `json:"bytesOut"`
}

// ProxyService 管理代理监听的启停
type ProxyService struct {
	mu      sync.Mutex
	p       *Proxy
	ln      net.Listener
	addr    string
	since   time.Time
	lastErr string

	conns int64
	errs  int64

	// publicLn 额外的公开监听（可选）
	publicLn   net.Listener
	publicAddr string
}

func NewProxyService(p *Proxy) *ProxyService {
	return &ProxyService{p: p}
}

// normalAddr 补全 addr
//
//	"1080"        -> "127.0.0.1:1080"
//	":8080"       -> "0.0.0.0:8080"
//	"0.0.0.0:80"  -> 原样
func normalAddr(addr string) string {
	if addr == "" {
		return "127.0.0.1:1080"
	}
	// 纯数字 = 端口
	isNum := true
	for _, c := range addr {
		if c < '0' || c > '9' {
			isNum = false
			break
		}
	}
	if isNum {
		return "127.0.0.1:" + addr
	}
	if addr[0] == ':' {
		return "0.0.0.0" + addr
	}
	return addr
}

// Proxy 返回底层代理实例
func (s *ProxyService) Proxy() *Proxy {
	if s == nil {
		return nil
	}
	return s.p
}

// Start 启动代理监听
func (s *ProxyService) Start(addr string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.ln != nil {
		return fmt.Errorf("服务已在运行 (%s)，请先停止", s.addr)
	}

	addr = normalAddr(addr)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		s.lastErr = err.Error()
		return fmt.Errorf("监听 %s 失败: %w", addr, err)
	}

	s.ln = ln
	s.addr = ln.Addr().String()
	s.since = time.Now()
	s.lastErr = ""
	s.conns = 0
	s.errs = 0

	go func(l net.Listener) {
		err := s.p.Serve(l)
		// 主动 Stop 导致的关闭不算错误
		if err != nil && !errors.Is(err, net.ErrClosed) {
			s.mu.Lock()
			s.lastErr = err.Error()
			s.ln = nil
			s.addr = ""
			s.mu.Unlock()
			log.Printf("[service] 代理退出: %v", err)
		}
	}(ln)

	log.Printf("[service] 代理已启动 -> %s", s.addr)
	return nil
}

// Stop 停止代理监听
func (s *ProxyService) Stop() error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.ln == nil {
		return fmt.Errorf("服务未运行")
	}
	addr := s.addr
	err := s.ln.Close()
	s.ln = nil
	s.addr = ""
	if err != nil && !errors.Is(err, net.ErrClosed) {
		return err
	}
	log.Printf("[service] 代理已停止 (%s)", addr)
	return nil
}

// Restart 改地址并重启
func (s *ProxyService) Restart(addr string) error {
	s.mu.Lock()
	had := s.ln != nil
	s.mu.Unlock()

	if had {
		if err := s.Stop(); err != nil {
			return err
		}
		// 等端口释放
		time.Sleep(150 * time.Millisecond)
	}
	return s.Start(addr)
}

// State 当前状态
func (s *ProxyService) State() ServiceState {
	s.mu.Lock()
	defer s.mu.Unlock()

	st := ServiceState{Error: s.lastErr}
	if s.ln != nil {
		st.Running = true
		st.Addr = s.addr
		st.StartedAt = s.since.Format("15:04:05")
	}
	if p := s.p; p != nil {
		st.Conns = p.TotalConns()
		st.Errs = p.TotalErrs()
		st.Active = p.ActiveCount()
		st.BytesIn = p.bytesIn.Load()
		st.BytesOut = p.bytesOut.Load()
	}
	return st
}

// StartPublic 启动额外的公开监听（红灯区，慎用）
func (s *ProxyService) StartPublic(addr string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.publicLn != nil {
		return fmt.Errorf("公开监听已在运行 (%s)", s.publicAddr)
	}
	if addr == "" {
		return fmt.Errorf("地址为空")
	}
	addr = normalAddr(addr)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return fmt.Errorf("监听 %s 失败: %w", addr, err)
	}
	s.publicLn = ln
	s.publicAddr = ln.Addr().String()
	go func(l net.Listener) {
		if err := s.p.Serve(l); err != nil && !errors.Is(err, net.ErrClosed) {
			log.Printf("[service] 公开监听退出: %v", err)
		}
	}(ln)
	log.Printf("[service] 公开代理已启动 -> %s（无认证！）", s.publicAddr)
	return nil
}

// StopPublic 关闭公开监听
func (s *ProxyService) StopPublic() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.publicLn == nil {
		return fmt.Errorf("公开监听未运行")
	}
	addr := s.publicAddr
	err := s.publicLn.Close()
	s.publicLn = nil
	s.publicAddr = ""
	if err != nil && !errors.Is(err, net.ErrClosed) {
		return err
	}
	log.Printf("[service] 公开代理已停止 (%s)", addr)
	return nil
}

// PublicState 公开监听状态
func (s *ProxyService) PublicState() (running bool, addr string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.publicLn != nil, s.publicAddr
}
