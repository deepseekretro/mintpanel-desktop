package main

// socks5server.go: 内置 SOCKS5 服务端（RFC 1928）
//
// 与 HTTP 代理共用同一个监听端口，靠首字节区分：
//   0x05          -> SOCKS5
//   "GET"/"CONNECT"/... -> HTTP
//
// 只支持 CONNECT（TCP），无认证（本地用不传账号密码）。
// UDP ASSOCIATE / BIND 直接拒绝——IPP 隧道是 TCP 流，UDP 无从承载。

import (
	"bufio"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"strconv"
	"time"
)

const (
	socks5Ver = 0x05

	// 认证方法
	methodNoAuth = 0x00
	methodNone   = 0xFF // 无可接受方法

	// 命令
	cmdConnect = 0x01
	cmdBind    = 0x02
	cmdUDP     = 0x03

	// 地址类型
	atypIPv4   = 0x01
	atypDomain = 0x03
	atypIPv6   = 0x04

	// 响应码
	repSuccess          = 0x00
	repGeneralFailure   = 0x01
	repNotAllowed       = 0x02
	repNetworkUnreach   = 0x03
	repHostUnreach      = 0x04
	repConnRefused      = 0x05
	repCmdNotSupported  = 0x07
	repAddrNotSupported = 0x08
)

// isSOCKS5 判断是否 SOCKS5 握手
//
// 只读 peek，不消费数据。HTTP 方法都是字母（GET/CONNECT/POST...），
// 首字节不可能是 0x05，所以这个判断很安全。
func isSOCKS5(br *bufio.Reader) bool {
	b, err := br.Peek(1)
	if err != nil {
		return false
	}
	return b[0] == socks5Ver
}

// handleSOCKS5 处理一个 SOCKS5 会话
func (p *Proxy) handleSOCKS5(c net.Conn, br *bufio.Reader) {
	// ---- 1. 方法协商 ----
	//
	// VER(1) NMETHODS(1) METHODS(NMETHODS)
	head := make([]byte, 2)
	if _, err := io.ReadFull(br, head); err != nil {
		p.errors.Add(1)
		return
	}
	if head[0] != socks5Ver {
		p.errors.Add(1)
		return
	}
	nMethods := int(head[1])
	if nMethods == 0 {
		c.Write([]byte{socks5Ver, methodNone})
		return
	}
	methods := make([]byte, nMethods)
	if _, err := io.ReadFull(br, methods); err != nil {
		p.errors.Add(1)
		return
	}

	// 只用无认证；客户端没提供 0x00 就拒绝
	hasNoAuth := false
	for _, m := range methods {
		if m == methodNoAuth {
			hasNoAuth = true
			break
		}
	}
	if !hasNoAuth {
		c.Write([]byte{socks5Ver, methodNone})
		return
	}
	if _, err := c.Write([]byte{socks5Ver, methodNoAuth}); err != nil {
		return
	}

	// ---- 2. 请求 ----
	//
	// VER(1) CMD(1) RSV(1) ATYP(1) DST.ADDR DST.PORT(2)
	reqHead := make([]byte, 4)
	if _, err := io.ReadFull(br, reqHead); err != nil {
		p.errors.Add(1)
		return
	}
	if reqHead[0] != socks5Ver {
		p.errors.Add(1)
		return
	}
	cmd := reqHead[1]
	atyp := reqHead[3]

	host, err := readSOCKS5Addr(br, atyp)
	if err != nil {
		p.errors.Add(1)
		socksReply(c, repAddrNotSupported)
		return
	}

	pb := make([]byte, 2)
	if _, err := io.ReadFull(br, pb); err != nil {
		p.errors.Add(1)
		return
	}
	port := int(binary.BigEndian.Uint16(pb))

	// 只支持 CONNECT
	if cmd != cmdConnect {
		code := byte(repCmdNotSupported)
		if cmd == cmdUDP || cmd == cmdBind {
			code = repNotAllowed
		}
		socksReply(c, code)
		return
	}

	// ---- 3. 建隧道 ----
	target := net.JoinHostPort(host, strconv.Itoa(port))
	up, err := p.d.Dial(target)
	if err != nil {
		p.errors.Add(1)
		socksReply(c, dialErrToRep(err))
		return
	}
	defer up.Close()

	// ---- 4. 回成功 + 开始转发 ----
	if err := socksReplyOK(c); err != nil {
		return
	}

	// br 里可能还有客户端提前发来的数据
	pipe(c, br, up)
}

// readSOCKS5Addr 读地址部分
func readSOCKS5Addr(br *bufio.Reader, atyp byte) (string, error) {
	switch atyp {
	case atypIPv4:
		b := make([]byte, 4)
		if _, err := io.ReadFull(br, b); err != nil {
			return "", err
		}
		return net.IP(b).String(), nil

	case atypIPv6:
		b := make([]byte, 16)
		if _, err := io.ReadFull(br, b); err != nil {
			return "", err
		}
		return net.IP(b).String(), nil

	case atypDomain:
		lb := make([]byte, 1)
		if _, err := io.ReadFull(br, lb); err != nil {
			return "", err
		}
		l := int(lb[0])
		if l == 0 {
			return "", errors.New("空域名")
		}
		b := make([]byte, l)
		if _, err := io.ReadFull(br, b); err != nil {
			return "", err
		}
		return string(b), nil

	default:
		return "", fmt.Errorf("未知地址类型 0x%02x", atyp)
	}
}

// socksReply 回失败响应（BND.ADDR 填 0.0.0.0:0）
func socksReply(c net.Conn, code byte) error {
	_, err := c.Write([]byte{
		socks5Ver, code, 0x00,
		atypIPv4, 0, 0, 0, 0, // BND.ADDR
		0, 0, // BND.PORT
	})
	return err
}

// socksReplyOK 回成功响应
func socksReplyOK(c net.Conn) error {
	c.SetDeadline(time.Now().Add(10 * time.Second))
	err := socksReply(c, repSuccess)
	c.SetDeadline(time.Time{})
	return err
}

// dialErrToRep 把拨号错误映射成 SOCKS5 响应码
func dialErrToRep(err error) byte {
	var ne net.Error
	if errors.As(err, &ne) && ne.Timeout() {
		return repHostUnreach
	}
	s := err.Error()
	switch {
	case containsAny(s, "refused"):
		return repConnRefused
	case containsAny(s, "no such host", "not found", "no valid pass"):
		return repHostUnreach
	case containsAny(s, "network is unreachable", "no route"):
		return repNetworkUnreach
	}
	return repGeneralFailure
}

func containsAny(s string, subs ...string) bool {
	for _, sub := range subs {
		if len(sub) > 0 && len(s) >= len(sub) {
			for i := 0; i+len(sub) <= len(s); i++ {
				if s[i:i+len(sub)] == sub {
					return true
				}
			}
		}
	}
	return false
}
