package main

// ui.go: FireFox VPN 主界面（登录配置 + token 倒计时 + 节点选择）

const indexHTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FireFox VPN</title>
<style>
  :root{
    --bg:#f7faf9; --card:#ffffff; --card2:#f0f5f3; --bd:#e2ebe7;
    --tx:#2c3a35; --dim:#8aa39a; --acc:#4fb894; --ok:#3fb27f;
    --warn:#e8a33d; --err:#e2685f;
    --acc-soft:rgba(79,184,148,.12); --acc-bd:rgba(79,184,148,.35);
    --sh:0 1px 3px rgba(44,58,53,.05),0 4px 14px rgba(44,58,53,.04);
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--tx);
    font:14px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
    -webkit-font-smoothing:antialiased;
    padding:18px}
  .wrap{max-width:880px;margin:0 auto}
  h1{font-size:18px;margin:0 0 2px;font-weight:650;letter-spacing:.3px}
  h1 span{color:var(--acc)}
  .sub{color:var(--dim);font-size:12.5px;margin-bottom:16px}

  .card{background:var(--card);border:1px solid var(--bd);border-radius:14px;
    padding:18px 20px;margin-bottom:14px;box-shadow:var(--sh)}
  .card h2{font-size:13px;margin:0 0 14px;color:var(--tx);font-weight:650;
    letter-spacing:.4px;display:flex;align-items:center;gap:7px}
  .card h2::before{content:"";width:3px;height:13px;border-radius:2px;
    background:var(--acc);flex-shrink:0}

  .row{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-bottom:10px}
  .row:last-child{margin-bottom:0}
  label{font-size:13px;color:var(--dim);min-width:74px}

  input[type=text],input[type=password],select{
    -webkit-appearance:none;appearance:none;
    flex:1;min-width:150px;background:var(--card2);border:1px solid var(--bd);
    color:var(--tx);padding:9px 12px;border-radius:9px;font-size:13px;outline:none;
    font-family:ui-monospace,Consolas,monospace;transition:.15s}
  input::placeholder{color:#b3c5be}
  input:focus,select:focus{background:#fff;border-color:var(--acc);
    box-shadow:0 0 0 3px var(--acc-soft)}
  select{font-family:inherit}

  button{-webkit-appearance:none;appearance:none;
    background:var(--card2);border:1px solid var(--bd);color:var(--tx);
    padding:9px 16px;border-radius:9px;font-size:13px;cursor:pointer;
    transition:.15s;white-space:nowrap;font-weight:550}
  button:hover{background:#e9f2ee;border-color:#cfe0d9;color:#1f4a3c}
  button:active{transform:scale(.97)}
  button.primary{background:var(--acc);border-color:var(--acc);color:#fff;font-weight:600;
    box-shadow:0 2px 8px rgba(79,184,148,.28)}
  button.primary:hover{background:#43a585;border-color:#43a585;color:#fff;
    box-shadow:0 3px 12px rgba(79,184,148,.36)}
  button:disabled{opacity:.5;cursor:not-allowed;box-shadow:none}

  .seg{display:flex;gap:0;border:1px solid var(--bd);border-radius:9px;overflow:hidden;
    background:var(--card2)}
  .seg button{border:none;border-radius:0;border-right:1px solid var(--bd);
    background:transparent;padding:8px 15px;font-weight:500}
  .seg button:last-child{border-right:none}
  .seg button:hover{background:#e9f2ee}
  .seg button.on{background:var(--acc);color:#fff;font-weight:600;
    box-shadow:0 1px 4px rgba(79,184,148,.3)}
  .seg button.on:hover{background:#43a585}

  .hint{font-size:11.5px;color:var(--dim);margin-top:7px;line-height:1.6}
  .hint code{background:var(--card2);padding:1px 5px;border-radius:4px;
    font-size:11px;color:#2f8f66}

  /* token 倒计时 */
  .tokline{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
  .ring{position:relative;width:52px;height:52px;flex-shrink:0}
  .ring svg{transform:rotate(-90deg)}
  .ring .pct{position:absolute;inset:0;display:flex;align-items:center;
    justify-content:center;font-size:11px;font-weight:650}
  .tokinfo{flex:1;min-width:170px}
  .tokmain{font-size:16px;font-weight:650;
    font-family:ui-monospace,Consolas,monospace;letter-spacing:.5px}
  .toksub{font-size:11.5px;color:var(--dim);margin-top:1px}

  .pill{font-size:10.5px;padding:2px 8px;border-radius:20px;
    border:1px solid;font-weight:600;letter-spacing:.2px}
  .pill.ok{color:#2f8f66;border-color:rgba(63,178,127,.3);background:rgba(63,178,127,.1)}
  .pill.warn{color:#b87d24;border-color:rgba(232,163,61,.3);background:rgba(232,163,61,.1)}
  .pill.err{color:#c2544b;border-color:rgba(226,104,95,.3);background:rgba(226,104,95,.1)}
  .pill.dim{color:var(--dim);border-color:var(--bd);background:var(--card2)}

  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));gap:7px;
    max-height:none;min-height:520px;overflow-y:auto;padding-right:3px}
  .grid::-webkit-scrollbar{width:8px}
  .grid::-webkit-scrollbar-thumb{background:#dce9e4;border-radius:5px}
  .grid::-webkit-scrollbar-thumb:hover{background:#c9dcd5}
  .item{background:var(--card2);border:1px solid transparent;border-radius:10px;
    padding:10px 12px;cursor:pointer;display:flex;align-items:center;gap:10px;
    transition:.15s;user-select:none}
  .item:hover{background:#eaf3ef;border-color:#d3e5dd;transform:translateY(-1px);
    box-shadow:0 2px 8px rgba(44,58,53,.06)}
  .item.on{border-color:var(--acc);background:var(--acc-soft);
    box-shadow:0 0 0 1px var(--acc-soft)}
  .item.busy{opacity:.5;pointer-events:none}
  .item .fl{line-height:0;flex-shrink:0}
  .flag{display:inline-flex;width:26px;height:17px;border-radius:3px;overflow:hidden;
    box-shadow:0 0 0 1px rgba(44,58,53,.12);vertical-align:middle}
  .flag svg{width:100%;height:100%;display:block}
  .flag-none{background:var(--card2);color:var(--dim);font-size:9px;font-weight:700;
    align-items:center;justify-content:center;letter-spacing:.3px}
  .item .tx{flex:1;min-width:0}
  .item .c{font-size:12.5px;font-weight:600}
  .item .h{font-size:10.5px;color:var(--dim);overflow:hidden;
    text-overflow:ellipsis;white-space:nowrap;
    font-family:ui-monospace,Consolas,monospace}
  .item .ms{font-size:10.5px;font-family:ui-monospace,Consolas,monospace;
    padding:1px 5px;border-radius:4px;flex-shrink:0;font-weight:600}
  .ms.good{color:#2f8f66;background:rgba(63,178,127,.14)}
  .ms.mid{color:#b87d24;background:rgba(232,163,61,.16)}
  .ms.bad{color:#c2544b;background:rgba(226,104,95,.14)}
  .ms.none{color:var(--dim);background:rgba(138,163,154,.12)}
  .item.on .c{color:var(--acc)}
  .dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;background:transparent}
  .item.on .dot{background:var(--ok);box-shadow:0 0 0 3px rgba(63,178,127,.18)}

  .spin{width:12px;height:12px;border:2px solid rgba(255,255,255,.15);
    border-top-color:var(--acc);border-radius:50%;animation:sp .7s linear infinite;flex-shrink:0}
  @keyframes sp{to{transform:rotate(360deg)}}

  .stat{display:flex;gap:18px;flex-wrap:wrap;font-size:12.5px}
  .stat div{color:var(--dim)}
  .stat b{color:var(--tx);font-weight:600;font-family:ui-monospace,Consolas,monospace}

  /* 开关 */
  .swch{position:relative;display:inline-block;width:44px;height:25px;flex-shrink:0}
  .swch input{opacity:0;width:0;height:0;position:absolute}
  .swch .sl{position:absolute;inset:0;background:#dbe7e2;border-radius:25px;
    transition:.2s;cursor:pointer}
  .swch .sl::before{content:"";position:absolute;width:19px;height:19px;left:3px;top:3px;
    background:#fff;border-radius:50%;transition:.2s;box-shadow:0 1px 3px rgba(44,58,53,.2)}
  .swch input:checked + .sl{background:var(--acc)}
  .swch input:checked + .sl::before{transform:translateX(19px)}

  .toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%) translateY(10px);
    background:#fff;border:1px solid var(--bd);color:var(--tx);padding:11px 18px;
    border-radius:11px;font-size:13px;box-shadow:0 8px 30px rgba(44,58,53,.14);
    opacity:0;pointer-events:none;transition:.2s;max-width:92vw}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
  .toast.ok{border-color:rgba(63,178,127,.5)}
  .toast.err{border-color:rgba(226,104,95,.5)}

  /* ===== 左侧导航布局 ===== */
  body{padding:0;height:100vh;overflow:hidden}
  .app{display:flex;height:100vh}

  .side{width:196px;flex-shrink:0;background:#fcfefd;border-right:1px solid var(--bd);
    display:flex;flex-direction:column;padding:18px 12px;gap:3px}
  .brand{display:flex;align-items:baseline;gap:1px;padding:2px 10px 18px}
  .brand h1{font-size:17px;margin:0;font-weight:700;letter-spacing:.2px}
  .brand h1 span{color:var(--acc)}

  .nav{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;
    cursor:pointer;color:#7d968d;font-size:13.5px;font-weight:550;
    border:1px solid transparent;transition:.15s;user-select:none}
  .nav:hover{background:var(--card2);color:var(--tx)}
  .nav.on{background:var(--acc-soft);color:#2f8f66;
    border-color:var(--acc-bd);font-weight:650}
  .nav .ico{font-size:14px;width:16px;text-align:center;flex-shrink:0}
  .nav .bdg{margin-left:auto;font-size:10.5px;padding:2px 7px;border-radius:10px;
    background:var(--acc-soft);color:#2f8f66;font-weight:650}
  .nav.on .bdg{background:rgba(79,184,148,.22)}

  .sidefoot{margin-top:auto;padding:12px 10px 4px;border-top:1px solid var(--bd);
    font-size:11.5px;color:var(--dim);line-height:1.75}
  .sidefoot b{color:var(--tx);font-family:ui-monospace,Consolas,monospace;font-weight:600}

  .main{flex:1;min-width:0;display:flex;flex-direction:column;background:var(--bg)}
  .topbar{display:flex;align-items:center;gap:10px;padding:14px 24px;
    border-bottom:1px solid var(--bd);flex-shrink:0;background:#fcfefd}
  .topbar .ttl{font-size:15px;font-weight:700;color:var(--tx)}
  .topbar .sp{flex:1}
  .content{flex:1;overflow-y:auto;padding:20px 24px}
  .content::-webkit-scrollbar{width:9px}
  .content::-webkit-scrollbar-thumb{background:#dce9e4;border-radius:5px}
  .content::-webkit-scrollbar-thumb:hover{background:#c9dcd5}
  .content::-webkit-scrollbar-track{background:transparent}
  .wrap{max-width:820px}
  .page{display:none}
  .page.on{display:block}
</style>
</head>
<body>
<div class="app">

  <!-- ===== 左侧导航 ===== -->
  <aside class="side">
    <div class="brand"><h1>FireFox<span>VPN</span></h1></div>

    <div class="nav on" data-page="overview"><span class="ico">◈</span>概览</div>
    <div class="nav" data-page="nodes"><span class="ico">◎</span>节点<span class="bdg" id="navNodeCnt">—</span></div>
    <div class="nav" data-page="settings"><span class="ico">⚙</span>设置</div>

    <div class="sidefoot">
      <div>代理 <b id="sfAddr">未启动</b></div>
      <div>节点 <b id="sfNode">—</b></div>
      <div>出口 <b id="sfIP">—</b></div>
      <div>隧道 <b id="sfH3">—</b></div>
      <div>速度 <b id="sfSpd">—</b></div>
    </div>
  </aside>

  <!-- ===== 主区 ===== -->
  <main class="main">
    <div class="topbar">
      <span class="ttl" id="pageTtl">概览</span>
      <span class="sp"></span>
      <span class="pill dim" id="topPill">—</span>
      <button id="btnRefreshTop" class="primary" title="立即续期">续期</button>
    </div>

    <div class="content">
      <div class="wrap">

  <!-- ============ 设置页 ============ -->
  <div class="page" id="page-settings">

  <!-- ===== Profile 选择 ===== -->
  <div class="card">
    <h2>Firefox Profile</h2>

    <div class="row">
      <input type="text" id="profPath" placeholder="profile 目录路径（如 %APPDATA%\\Mozilla\\Firefox\\Profiles\\xxx.default-release）" style="font-family:ui-monospace,Consolas,monospace">
      <button id="btnProf">应用</button>
      <button id="btnScan">重新扫描</button>
    </div>

    <div class="row" id="profListRow">
      <label>已发现</label>
      <select id="profSel" style="flex:1">
        <option>扫描中…</option>
      </select>
    </div>

    <div class="hint" id="profHint">
      未登录可用：从 Firefox 登录后自动读取。Windows 下路径通常为
      <code>%APPDATA%\Mozilla\Firefox\Profiles\xxxx.default-release</code>。
    </div>
  </div>

  <!-- ===== 登录配置 ===== -->
  <div class="card">
    <h2>登录 / 出站配置</h2>

    <div class="row">
      <label>出站方式</label>
      <div class="seg" id="modeSeg">
        <button data-mode="direct">直连</button>
        <button data-mode="http" class="on">HTTP 代理</button>
        <button data-mode="socks5">SOCKS5</button>
      </div>
    </div>

    <div class="row" id="proxyRow" style="display:flex">
      <label>代理地址</label>
      <input type="text" id="proxyURL" value="127.0.0.1:8080" placeholder="127.0.0.1:8080">
      <button id="btnTest">测试连通</button>
    </div>

    <div class="hint" id="loginHint">
      Mozilla 登录接口需能访问 api.accounts.firefox.com。受限网络下请配置代理。
    </div>

    <div class="row" style="margin-top:12px">
      <label>sessionToken</label>
      <input type="password" id="sessionTok" placeholder="粘贴 64 字符 hex sessionToken（可留空用 Firefox profile）">
      <button id="btnSetTok">应用</button>
    </div>

    <div class="hint">
      获取方式：Firefox 登录后，从 profile 的
      <code>signedInUser.json</code> → <code>accountData.sessionToken</code> 复制。
      应用后可<b>无限自动续期</b>。
    </div>
  </div>

  <!-- ===== 配置文件 ===== -->
  <div class="card">
    <h2>配置文件</h2>

    <div class="row">
      <label>记住登录</label>
      <label class="swch">
        <input type="checkbox" id="cfgSave">
        <span class="sl"></span>
      </label>
      <span class="hint" id="cfgSaveHint" style="margin:0"></span>
    </div>

    <div class="hint" id="cfgPathHint">配置保存在系统配置目录</div>

    <div class="row" style="margin-top:10px">
      <button id="btnCfgSave">保存当前设置</button>
      <button id="btnCfgClear">清除已存凭证</button>
    </div>
  </div>

  </div><!-- /page-settings -->

  <!-- ============ 概览页 ============ -->
  <div class="page on" id="page-overview">

  <!-- ===== Token 状态 ===== -->
  <div class="card">
    <h2>Token 状态</h2>
    <div class="tokline">
      <div class="ring">
        <svg width="52" height="52">
          <circle cx="26" cy="26" r="22" fill="none" stroke="#e6f0eb" stroke-width="5"/>
          <circle id="ringBar" cx="26" cy="26" r="22" fill="none" stroke="#4fb894"
                  stroke-width="5" stroke-linecap="round"
                  stroke-dasharray="138.2" stroke-dashoffset="0"/>
        </svg>
        <div class="pct" id="ringPct">--</div>
      </div>
      <div class="tokinfo">
        <div class="tokmain" id="tokCountdown">--:--:--</div>
        <div class="toksub" id="tokSub">正在读取…</div>
      </div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <span class="pill dim" id="tokPill">—</span>
        <button id="btnRefresh" title="立即续期">手动续期</button>
      </div>
    </div>
  </div>

  <!-- ===== 代理服务 ===== -->
  <div class="card">
    <h2>代理服务</h2>

    <div class="row">
      <label>监听地址</label>
      <input type="text" id="svcAddr" value="127.0.0.1:10909" placeholder="127.0.0.1:10909" style="font-family:ui-monospace,Consolas,monospace">
      <button id="btnSvcStart" class="primary">启动</button>
      <button id="btnSvcStop">停止</button>
    </div>

    <div class="row">
      <label>代理服务</label>
      <span class="pill dim" id="svcPill">未启动</span>
      <span class="hint" id="svcInfo" style="margin:0"></span>
    </div>

    <div class="row">
      <label>出口 IP</label>
      <div class="seg" id="ipSeg">
        <button data-ip="ipv4">IPv4</button>
        <button data-ip="ipv6">IPv6</button>
        <button data-ip="auto" class="on">自动</button>
        <button data-ip="remote">远端</button>
      </div>
    </div>

    <div class="hint">
      <b>IPv4</b>：本机先解析 A 记录再 CONNECT（推荐，兼容好）<br>
      <b>IPv6</b>：解析 AAAA 记录，仅目标站有 IPv6 时可用<br>
      <b>自动</b>：交给节点解析（可能走 IPv6）<br>
      <b>远端</b>：域名直接交给节点，与旧版一致
    </div>

    <div class="hint">
      填纯数字（如 <code>1080</code>）= 只监听本机；
      填 <code>0.0.0.0:1080</code> = 局域网可访问（无认证，小心）。
    </div>
  </div>

  </div><!-- /page-overview -->

  <!-- ============ 节点页 ============ -->
  <div class="page" id="page-nodes">

  <!-- ===== 节点 ===== -->
  <div class="card">
    <h2>出口节点</h2>
    <div class="row">
      <input type="text" id="q" placeholder="搜索国家 / 代码 / 主机名…" style="font-family:inherit">
      <div class="seg" id="sortSeg">
        <button data-sort="ping" class="on">延迟</button>
        <button data-sort="name">名称</button>
        <button data-sort="none">默认</button>
      </div>
      <button id="btnPing">测延迟</button>
    </div>
    <div class="row">
      <span class="hint" id="cnt" style="margin:0"></span>
      <span class="hint" id="pingInfo" style="margin:0"></span>
    </div>
    <div class="grid" id="grid"></div>
  </div>

  <!-- ===== 运行状态 ===== -->
  <div class="card">
    <h2>运行状态</h2>
    <div class="stat">
      <div>当前节点 <b id="stNode">—</b></div>
      <div>出口 IP <b id="stIP">—</b></div>
      <div>代理端口 <b id="stAddr">未启动</b></div>
    </div>
  </div>

  </div><!-- /page-nodes -->

      </div><!-- /wrap -->
    </div><!-- /content -->
  </main>
</div><!-- /app -->

<div class="toast" id="toast"></div>

<script>
/* ---------- 左侧导航切换 ---------- */
const PAGE_TTL={overview:"概览",nodes:"节点",settings:"设置"};
function showPage(id){
  document.querySelectorAll(".nav").forEach(n=>
    n.classList.toggle("on",n.dataset.page===id));
  document.querySelectorAll(".page").forEach(p=>
    p.classList.toggle("on",p.id==="page-"+id));
  document.getElementById("pageTtl").textContent=PAGE_TTL[id]||"";
  try{localStorage.setItem("ipp.page",id);}catch(e){}
}
document.querySelectorAll(".nav").forEach(n=>{
  n.onclick=()=>showPage(n.dataset.page);
});

/* 国旗：内联 SVG（不依赖 emoji 字体，Windows/Linux 一致） */
const FLAGS={
AR:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#74acdf"/><rect y="6.7" width="30" height="6.6" fill="#fff"/><circle cx="15" cy="10" r="2.2" fill="#f6b40e"/></svg>',
AT:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect width="30" height="6.7" fill="#ed2939"/><rect y="13.3" width="30" height="6.7" fill="#ed2939"/></svg>',
AU:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#012169"/><path d="M0 0h15v10H0z" fill="#012169"/><path d="M0 0l15 10M15 0L0 10" stroke="#fff" stroke-width="2"/><path d="M7.5 0v10M0 5h15" stroke="#fff" stroke-width="2.5"/><path d="M7.5 0v10M0 5h15" stroke="#c8102e" stroke-width="1.2"/><circle cx="22" cy="6" r="1.2" fill="#fff"/><circle cx="25" cy="12" r="1.2" fill="#fff"/><circle cx="20" cy="15" r="1" fill="#fff"/><circle cx="10" cy="15" r="1" fill="#fff"/><circle cx="24" cy="9" r="0.8" fill="#fff"/></svg>',
BE:'<svg viewBox="0 0 30 20"><rect width="10" height="20" fill="#000"/><rect x="10" width="10" height="20" fill="#fdda24"/><rect x="20" width="10" height="20" fill="#ef3340"/></svg>',
BG:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect y="6.7" width="30" height="6.6" fill="#00966e"/><rect y="13.3" width="30" height="6.7" fill="#d62612"/></svg>',
BR:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#009c3b"/><path d="M15 3l12 7-12 7L3 10z" fill="#ffdf00"/><circle cx="15" cy="10" r="3.6" fill="#002776"/><path d="M11.6 8.8c2.6 1.2 5 1.2 6.8 0" stroke="#fff" stroke-width="0.9" fill="none"/></svg>',
CA:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect width="7.5" height="20" fill="#d80621"/><rect x="22.5" width="7.5" height="20" fill="#d80621"/><path d="M15 5l1.2 2.4 2.3-.7-.7 2.3 2.2.6-1.8 1.6.5 2.2-2.4-.6-.2 2.4h-2.2l-.2-2.4-2.4.6.5-2.2-1.8-1.6 2.2-.6-.7-2.3 2.3.7z" fill="#d80621"/></svg>',
CL:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect y="10" width="30" height="10" fill="#d52b1e"/><rect width="10" height="10" fill="#0039a6"/><path d="M5 2.5l.7 2.1h2.2L6.1 6l.7 2.1L5 6.9 3.2 8.1 3.9 6 2.1 4.6h2.2z" fill="#fff"/></svg>',
CO:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fcd116"/><rect y="10" width="30" height="5" fill="#003893"/><rect y="15" width="30" height="5" fill="#ce1126"/></svg>',
DE:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#000"/><rect y="6.7" width="30" height="6.6" fill="#dd0000"/><rect y="13.3" width="30" height="6.7" fill="#ffce00"/></svg>',
DK:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#c8102e"/><rect x="9" width="3.5" height="20" fill="#fff"/><rect y="8.2" width="30" height="3.5" fill="#fff"/></svg>',
ES:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#aa151b"/><rect y="5" width="30" height="10" fill="#f1bf00"/><rect x="8" y="7.5" width="3.5" height="5" fill="#aa151b" opacity=".75"/></svg>',
FI:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect x="8" width="5" height="20" fill="#003580"/><rect y="7.5" width="30" height="5" fill="#003580"/></svg>',
FR:'<svg viewBox="0 0 30 20"><rect width="10" height="20" fill="#002395"/><rect x="10" width="10" height="20" fill="#fff"/><rect x="20" width="10" height="20" fill="#ed2939"/></svg>',
GB:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#012169"/><path d="M0 0l30 20M30 0L0 20" stroke="#fff" stroke-width="4"/><path d="M0 0l30 20M30 0L0 20" stroke="#c8102e" stroke-width="2"/><path d="M15 0v20M0 10h30" stroke="#fff" stroke-width="6.5"/><path d="M15 0v20M0 10h30" stroke="#c8102e" stroke-width="3.8"/></svg>',
GH:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#006b3f"/><rect width="30" height="6.7" fill="#ce1126"/><rect y="6.7" width="30" height="6.6" fill="#fcd116"/><path d="M15 6.6l.9 2.8h2.9l-2.4 1.7.9 2.8-2.3-1.7-2.3 1.7.9-2.8-2.4-1.7h2.9z" fill="#000"/></svg>',
IE:'<svg viewBox="0 0 30 20"><rect width="10" height="20" fill="#169b62"/><rect x="10" width="10" height="20" fill="#fff"/><rect x="20" width="10" height="20" fill="#ff883e"/></svg>',
JP:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><circle cx="15" cy="10" r="6" fill="#bc002d"/></svg>',
KR:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><circle cx="15" cy="10" r="4" fill="#cd2e3a"/><path d="M11 10a4 4 0 008 0 2 2 0 00-4 0 2 2 0 01-4 0z" fill="#0047a0"/><path d="M6 5l2-1M6 7l2-1M22 14l2-1M22 16l2-1" stroke="#000" stroke-width="1"/></svg>',
MX:'<svg viewBox="0 0 30 20"><rect width="10" height="20" fill="#006847"/><rect x="10" width="10" height="20" fill="#fff"/><rect x="20" width="10" height="20" fill="#ce1126"/><circle cx="15" cy="10" r="2.2" fill="#8c6239"/></svg>',
MY:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><g fill="#cc0001"><rect width="30" height="2.2"/><rect y="4.4" width="30" height="2.2"/><rect y="8.8" width="30" height="2.2"/><rect y="13.2" width="30" height="2.2"/><rect y="17.6" width="30" height="2.4"/></g><rect width="15" height="11" fill="#010066"/><circle cx="7" cy="5.5" r="3" fill="#ffcc00"/><circle cx="8.4" cy="5.5" r="2.4" fill="#010066"/><path d="M11 5.5l1.6-.5-1 1.4.2 1.6-1.3-1-1.5.5.9-1.4-.1-1.6z" fill="#ffcc00"/></svg>',
NL:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect width="30" height="6.7" fill="#ae1c28"/><rect y="13.3" width="30" height="6.7" fill="#21468b"/></svg>',
NO:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#ba0c2f"/><rect x="8" width="5" height="20" fill="#fff"/><rect y="7.5" width="30" height="5" fill="#fff"/><rect x="9" width="3" height="20" fill="#00205b"/><rect y="8.5" width="30" height="3" fill="#00205b"/></svg>',
NZ:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#012169"/><path d="M0 0l14 9M14 0L0 9" stroke="#fff" stroke-width="1.8"/><path d="M7 0v9M0 4.5h14" stroke="#fff" stroke-width="2.4"/><path d="M7 0v9M0 4.5h14" stroke="#c8102e" stroke-width="1.1"/><circle cx="22" cy="13" r="1" fill="#c8102e"/><circle cx="25" cy="8" r="1" fill="#c8102e"/><circle cx="19" cy="7" r="1" fill="#c8102e"/><circle cx="23" cy="16" r="0.8" fill="#c8102e"/></svg>',
PE:'<svg viewBox="0 0 30 20"><rect width="10" height="20" fill="#d91023"/><rect x="10" width="10" height="20" fill="#fff"/><rect x="20" width="10" height="20" fill="#d91023"/></svg>',
PH:'<svg viewBox="0 0 30 20"><rect width="30" height="10" fill="#0038a8"/><rect y="10" width="30" height="10" fill="#ce1126"/><path d="M0 0l12 10L0 20z" fill="#fff"/><circle cx="3.5" cy="10" r="1.6" fill="#fcd116"/></svg>',
PT:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#da291c"/><rect width="12" height="20" fill="#046a38"/><circle cx="12" cy="10" r="3.6" fill="#f1bf00"/><circle cx="12" cy="10" r="2.4" fill="#da291c"/><circle cx="12" cy="10" r="1.6" fill="#fff"/></svg>',
SE:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#006aa7"/><rect x="9" width="4.5" height="20" fill="#fecc00"/><rect y="7.8" width="30" height="4.5" fill="#fecc00"/></svg>',
SG:'<svg viewBox="0 0 30 20"><rect width="30" height="10" fill="#ef3340"/><rect y="10" width="30" height="10" fill="#fff"/><circle cx="7" cy="5" r="3.2" fill="#fff"/><circle cx="8.6" cy="5" r="2.8" fill="#ef3340"/><circle cx="10" cy="3.6" r="0.7" fill="#fff"/><circle cx="12" cy="5" r="0.7" fill="#fff"/><circle cx="11" cy="7.2" r="0.7" fill="#fff"/></svg>',
TH:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#f4f5f8"/><rect width="30" height="3.3" fill="#a51931"/><rect y="16.7" width="30" height="3.3" fill="#a51931"/><rect y="6.7" width="30" height="6.6" fill="#2d2a4a"/></svg>',
US:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><g fill="#b22234"><rect width="30" height="1.54"/><rect y="3.08" width="30" height="1.54"/><rect y="6.15" width="30" height="1.54"/><rect y="9.23" width="30" height="1.54"/><rect y="12.31" width="30" height="1.54"/><rect y="15.38" width="30" height="1.54"/><rect y="18.46" width="30" height="1.54"/></g><rect width="12" height="10.77" fill="#3c3b6e"/><g fill="#fff"><circle cx="2" cy="1.8" r=".5"/><circle cx="5" cy="1.8" r=".5"/><circle cx="8" cy="1.8" r=".5"/><circle cx="11" cy="1.8" r=".5"/><circle cx="3.5" cy="3.6" r=".5"/><circle cx="6.5" cy="3.6" r=".5"/><circle cx="9.5" cy="3.6" r=".5"/><circle cx="2" cy="5.4" r=".5"/><circle cx="5" cy="5.4" r=".5"/><circle cx="8" cy="5.4" r=".5"/><circle cx="11" cy="5.4" r=".5"/><circle cx="3.5" cy="7.2" r=".5"/><circle cx="6.5" cy="7.2" r=".5"/><circle cx="9.5" cy="7.2" r=".5"/><circle cx="2" cy="9" r=".5"/><circle cx="5" cy="9" r=".5"/><circle cx="8" cy="9" r=".5"/><circle cx="11" cy="9" r=".5"/></g></svg>',
ZA:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#fff"/><rect width="30" height="7.7" fill="#de3831"/><rect y="12.3" width="30" height="7.7" fill="#002395"/><rect y="7.7" width="30" height="4.6" fill="#007a4d"/><path d="M0 0l11 10L0 20z" fill="#000"/><path d="M0 2.2l9 7.8L0 17.8z" fill="#007a4d"/><path d="M0 3.5l7.5 6.5L0 16.5z" fill="#ffb612"/></svg>',
REC:'<svg viewBox="0 0 30 20"><rect width="30" height="20" fill="#4fb894"/><circle cx="15" cy="10" r="5.2" fill="none" stroke="#fff" stroke-width="1.6"/><circle cx="15" cy="10" r="2" fill="#fff"/></svg>'
};
function fl(code){
  const svg=FLAGS[code];
  if(svg) return '<span class="flag">'+svg+'</span>';
  return '<span class="flag flag-none">'+code.slice(0,2)+'</span>';
}

/* 国家名中英对照（节点列表展示用） */
const CN={
Argentina:"阿根廷",Austria:"奥地利",Australia:"澳大利亚",Belgium:"比利时",
Bulgaria:"保加利亚",Brazil:"巴西",Canada:"加拿大",Chile:"智利",Colombia:"哥伦比亚",
Germany:"德国",Denmark:"丹麦",Spain:"西班牙",Finland:"芬兰",France:"法国",
"United Kingdom":"英国",Ghana:"加纳",Ireland:"爱尔兰",Japan:"日本",
"South Korea":"韩国",Mexico:"墨西哥",Malaysia:"马来西亚",Netherlands:"荷兰",
Norway:"挪威","New Zealand":"新西兰",Peru:"秘鲁",Philippines:"菲律宾",
Portugal:"葡萄牙",Sweden:"瑞典",Singapore:"新加坡",Thailand:"泰国",
"United States":"美国","South Africa":"南非",Czechia:"捷克","Czech Republic":"捷克",
Poland:"波兰",Romania:"罗马尼亚",Hungary:"匈牙利",Greece:"希腊",Italy:"意大利",
Switzerland:"瑞士",India:"印度",Indonesia:"印度尼西亚",Israel:"以色列",
Turkey:"土耳其",Ukraine:"乌克兰",Estonia:"爱沙尼亚",Latvia:"拉脱维亚",
Lithuania:"立陶宛",Slovakia:"斯洛伐克",Slovenia:"斯洛文尼亚",Croatia:"克罗地亚",
Serbia:"塞尔维亚",Iceland:"冰岛",Luxembourg:"卢森堡",Taiwan:"台湾",
"Hong Kong":"香港","Recomended Location":"推荐位置",Recommended:"推荐位置"
};
const cn=name=>CN[name]||name;
/* 搜索时同时匹配英文与中文 */
const nameMatch=(n,q)=>((n.code+" "+n.name+" "+cn(n.name)+" "+n.host).toLowerCase().includes(q));

let nodes=[],current=null,busy=false;
let tok={},tokTimer=null,mode="http";

function toast(m,k){const t=document.getElementById("toast");
  t.textContent=m;t.className="toast show "+(k||"");
  clearTimeout(t._h);t._h=setTimeout(()=>t.className="toast",3400);}

/* ---------- 出站方式 ---------- */
function setMode(m){
  mode=m;
  document.querySelectorAll("#modeSeg button").forEach(b=>
    b.classList.toggle("on",b.dataset.mode===m));
  document.getElementById("proxyRow").style.display=
    m==="direct"?"none":"flex";
  const p=document.getElementById("proxyURL");
  if(m==="http"&&!p.value)p.placeholder="127.0.0.1:8080";
  if(m==="socks5"&&!p.value)p.placeholder="127.0.0.1:1080";
}
document.querySelectorAll("#modeSeg button").forEach(b=>
  b.onclick=()=>setMode(b.dataset.mode));

document.getElementById("btnTest").onclick=async()=>{
  const raw=document.getElementById("proxyURL").value.trim();
  if(!raw){toast("请填代理地址","err");return;}
  let url=raw;
  if(!/^[a-z0-9]+:\/\//i.test(raw))
    url=(mode==="socks5"?"socks5://":"http://")+raw;

  const btn=document.getElementById("btnTest");
  btn.disabled=true;btn.textContent="测试中…";
  try{
    const r=await fetch("/api/login-proxy",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({proxyURL:url,timeout:30})});
    const j=await r.json();
    if(j.ok) toast("代理可用 · 延迟 "+j.latencyMs+"ms","ok");
    else toast(j.error||"失败","err");
  }catch(e){toast("请求失败: "+e.message,"err");}
  finally{btn.disabled=false;btn.textContent="测试连通";}
};

/* ---------- sessionToken ---------- */
document.getElementById("btnSetTok").onclick=async()=>{
  const v=document.getElementById("sessionTok").value.trim();
  if(!v){toast("请粘贴 sessionToken","err");return;}
  const btn=document.getElementById("btnSetTok");
  btn.disabled=true;btn.textContent="验证中…";
  try{
    const r=await fetch("/api/token",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({sessionToken:v})});
    const j=await r.json();
    if(j.ok){toast("sessionToken 已生效，可自动续期","ok");
      document.getElementById("sessionTok").value="";
      renderTok(j.status);}
    else toast(j.error||"无效","err");
  }catch(e){toast("请求失败: "+e.message,"err");}
  finally{btn.disabled=false;btn.textContent="应用";}
};

document.getElementById("btnRefresh").onclick=async()=>{
  const btn=document.getElementById("btnRefresh");
  btn.disabled=true;btn.textContent="续期中…";
  try{
    const r=await fetch("/api/token/refresh",{method:"POST"});
    const j=await r.json();
    if(j.ok){toast("续期成功","ok");renderTok(j.status);}
    else toast(j.error||"失败","err");
  }catch(e){toast(e.message,"err");}
  finally{btn.disabled=false;btn.textContent="手动续期";}
};

/* ---------- token 倒计时 ---------- */
let tokBase=null,tokBaseAt=0;

function renderTok(st){
  tok=st||{};
  if(!tok.expiresAt){
    document.getElementById("tokCountdown").textContent="--:--:--";
    document.getElementById("tokSub").textContent=tok.error||"无可用 token";
    document.getElementById("ringPct").textContent="--";
    const p=document.getElementById("tokPill");
    p.className="pill err";p.textContent="无效";
    return;
  }
  tokBase=tok.remainingSec;tokBaseAt=Date.now();
  const p=document.getElementById("tokPill");
  if(tok.source==="session"){p.className="pill ok";p.textContent="可自动续期";}
  else if(tok.source==="access"){p.className="pill warn";p.textContent="只读·到期需手动";}
  else {p.className="pill dim";p.textContent="未知";}

  document.getElementById("tokSub").textContent=
    (tok.canRefresh?"到期自动续期 · ":"不可续期 · ")+
    (tok.expiresAtText||"");
  tick();
}

function tick(){
  if(!tokBase) return;
  const el=Math.max(0,tokBase-Math.floor((Date.now()-tokBaseAt)/1000));
  const h=Math.floor(el/3600),m=Math.floor(el%3600/60),s=el%60;
  document.getElementById("tokCountdown").textContent=
    String(h).padStart(2,"0")+":"+String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");

  const total=tok.remainingSec||86400;
  const pct=Math.max(0,Math.min(1,el/total));
  const C=2*Math.PI*22;
  const bar=document.getElementById("ringBar");
  bar.setAttribute("stroke-dashoffset",String(C*(1-pct)));
  bar.setAttribute("stroke",pct>.3?"#22c55e":pct>.1?"#f59e0b":"#ef4444");
  document.getElementById("ringPct").textContent=Math.round(pct*100)+"%";

  if(el<=0){clearInterval(tokTimer);loadTok();}
}

async function loadTok(){
  try{
    const r=await fetch("/api/token");
    renderTok(await r.json());
  }catch(e){
    document.getElementById("tokSub").textContent="读取失败: "+e.message;
  }
}

/* ---------- 代理服务 ---------- */
let svcState={};

function renderSvc(j){
  const st=j.service||{};
  const p=document.getElementById("svcPill");
  const info=document.getElementById("svcInfo");
  svcState=st;

  if(st.running){
    p.className="pill ok";p.textContent="运行中";
    info.textContent=st.addr+" · "+(st.conns||0)+" 连接 · "+(st.errs||0)+" 错误"+
      (st.startedAt?" · 自 "+st.startedAt:"");
    document.getElementById("svcAddr").value=st.addr;
    document.getElementById("btnSvcStart").textContent="重启";
    const sa=document.getElementById("stAddr");
    if(sa)sa.textContent=st.addr;
    const sf=document.getElementById("sfAddr");
    if(sf)sf.textContent=st.addr;
  }else{
    p.className="pill dim";p.textContent="未启动";
    info.textContent=st.error?("错误: "+st.error):"";
    document.getElementById("btnSvcStart").textContent="启动";
    const sa=document.getElementById("stAddr");
    if(sa)sa.textContent="未启动";
    const sf=document.getElementById("sfAddr");
    if(sf)sf.textContent="未启动";
    if(!document.getElementById("svcAddr").value)
      document.getElementById("svcAddr").value=j.lastAddr||"127.0.0.1:10909";
  }
}

async function svcAction(path){
  const addr=document.getElementById("svcAddr").value.trim();
  try{
    const r=await fetch(path,{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({addr:addr})});
    const j=await r.json();
    if(j.ok){toast(j.service&&j.service.running?"代理已启动 "+j.service.addr:"代理已停止","ok");
      renderSvc(j);}
    else {toast(j.error||"失败","err");renderSvc(j);}
  }catch(e){toast("请求失败: "+e.message,"err");}
}

document.getElementById("btnSvcStart").onclick=()=>{
  svcAction(svcState.running?"/api/service/restart":"/api/service/start");
};
document.getElementById("btnSvcStop").onclick=()=>svcAction("/api/service/stop");

// 出口 IP 模式（函数声明会提升，但初始化调用必须容错）
  document.querySelectorAll("#ipSeg button").forEach(b=>{
    b.onclick=()=>setIP(b.dataset.ip);
  });

  // 连节点 IP 族
  document.querySelectorAll("#nodeIPSeg button").forEach(b=>{
    b.onclick=()=>setNodeIP(b.dataset.ip);
  });

  // 单独 try：任何一个初始化失败都不能拖死后面的 bindings/loadProfiles 等
  try{ loadIPMode(); }catch(e){ console.error("loadIPMode",e); }
  try{ loadNodeIP(); }catch(e){ console.error("loadNodeIP",e); }

async function loadSvc(){
  try{
    const r=await fetch("/api/service");
    renderSvc(await r.json());
  }catch(e){}
}

/* ---------- 出口 IP 模式 ---------- */
let ipMode="auto";

function renderIP(m){
  ipMode=m;
  document.querySelectorAll("#ipSeg button").forEach(b=>
    b.classList.toggle("on",b.dataset.ip===m));
}

async function setIP(m){
  try{
    const r=await fetch("/api/ipmode",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({mode:m})});
    const j=await r.json();
    if(j.ok){renderIP(j.mode);toast("出口 IP 已切为 "+j.mode,"ok");}
    else toast(j.error||"切换失败","err");
  }catch(e){toast("请求失败: "+e.message,"err");}
}

async function loadIPMode(){
  try{
    const r=await fetch("/api/ipmode");
    const j=await r.json();
    if(j.mode)renderIP(j.mode);
  }catch(e){}
}

/* ---------- 连节点 IP 族 ---------- */
let nodeIPMode="auto";

function renderNodeIP(m){
  nodeIPMode=m;
  document.querySelectorAll("#nodeIPSeg button").forEach(b=>
    b.classList.toggle("on",b.dataset.ip===m));
}

async function setNodeIP(m){
  try{
    const r=await fetch("/api/nodeip",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({mode:m})});
    const j=await r.json();
    if(j.ok){renderNodeIP(j.mode);toast("连节点 IP 已切为 "+j.mode,"ok");}
    else toast(j.error||"切换失败","err");
  }catch(e){toast("请求失败: "+e.message,"err");}
}

// 实时速度：拿两次 /api/service 的累计字节差，除以时间间隔
let _spdPrev=null;
async function loadSpeed(){
  try{
    const r=await fetch("/api/service");
    const j=await r.json();
    const el=document.getElementById("sfSpd");
    if(!el)return;
    const now=Date.now();
    const total=(j.bytesIn||0);
    if(_spdPrev){
      const dt=(now-_spdPrev.t)/1000;
      if(dt>0.5){
        const bps=(total-_spdPrev.v)/dt;
        el.textContent=fmtSpd(bps);
        el.style.color=bps>2e6?"#2f8f66":(bps>3e5?"var(--warn)":"var(--dim)");
      }
    }
    _spdPrev={t:now,v:total};
  }catch(e){}
}
function fmtSpd(bps){
  if(!bps||bps<0)return "0";
  if(bps>1048576)return (bps/1048576).toFixed(1)+" MB/s";
  if(bps>1024)return (bps/1024).toFixed(0)+" KB/s";
  return Math.round(bps)+" B/s";
}

async function loadH3(){
  try{
    const r=await fetch("/api/h3");
    const j=await r.json();
    const el=document.getElementById("sfH3");
    if(!el)return;
    if(!j.enabled){el.textContent="HTTP/1.1";el.style.color="var(--dim)";return;}
    el.textContent="H3 · "+j.conns+"连接/"+j.streams+"路";
    el.style.color=j.conns>0?"#2f8f66":"var(--warn)";
  }catch(e){}
}

async function loadNodeIP(){
  try{
    const r=await fetch("/api/nodeip");
    const j=await r.json();
    if(j.mode)renderNodeIP(j.mode);
  }catch(e){}
}

/* ---------- 节点 ---------- */
let latency={};          // host -> ms
let sortBy="ping";      // ping | name | none
let pingAtText="";

function msClass(ms){
  if(ms==null)return "none";
  if(ms<150)return "good";
  if(ms<400)return "mid";
  return "bad";
}

function renderGrid(){
  const q=document.getElementById("q").value.trim().toLowerCase();
  const box=document.getElementById("grid");box.innerHTML="";

  let shown=nodes.filter(n=>!q||nameMatch(n,q));

  // 排序
  if(sortBy==="ping"){
    shown=shown.slice().sort((a,b)=>{
      const la=latency[a.host], lb=latency[b.host];
      // 未测出的排最后
      if(la==null&&lb==null)return a.code.localeCompare(b.code);
      if(la==null)return 1;
      if(lb==null)return -1;
      return la-lb;
    });
  }else if(sortBy==="name"){
    shown=shown.slice().sort((a,b)=>a.code.localeCompare(b.code));
  }

  document.getElementById("cnt").textContent=shown.length+" / "+nodes.length;
  document.getElementById("pingInfo").textContent=
    pingAtText?("延迟 "+pingAtText+" 测"):"";

  for(const n of shown){
    const el=document.createElement("div");
    el.className="item"+(current&&n.host===current.host?" on":"");
    const ms=latency[n.host];
    const msTxt=ms==null?"—":ms+"ms";
    el.innerHTML=
      '<div class="fl">'+fl(n.code)+'</div>'+
      '<div class="tx"><div class="c">'+n.code+' '+cn(n.name)+'</div>'+
      '<div class="h">'+n.host+'</div></div>'+
      '<span class="ms '+msClass(ms)+'">'+msTxt+'</span>'+
      '<div class="dot"></div>';
    el.onclick=()=>switchTo(n,el);
    box.appendChild(el);
  }
  if(!shown.length)box.innerHTML='<div class="hint">无匹配节点</div>';
}

async function loadPing(force){
  const btn=document.getElementById("btnPing");
  btn.disabled=true;btn.textContent="测试中…";
  try{
    const r=await fetch("/api/ping"+(force?"?force=1":""));
    const j=await r.json();
    latency=j.latency||{};
    pingAtText=j.at||"";
    renderGrid();
    const n=Object.keys(latency).length;
    toast("已测 "+n+" 个节点"+(j.took?" · "+j.took+"ms":""),"ok");
  }catch(e){toast("测延迟失败: "+e.message,"err");}
  finally{btn.disabled=false;btn.textContent="测延迟";}
}

async function switchTo(n,el){
  if(busy||(current&&n.host===current.host))return;
  busy=true;
  const old=el.innerHTML;
  el.classList.add("busy");
  el.querySelector(".dot").outerHTML='<div class="spin"></div>';
  toast("切换到 "+n.code+" "+n.name+" …");
  try{
    const r=await fetch("/api/switch",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({host:n.host})});
    const j=await r.json();
    if(!j.ok){toast("失败: "+(j.error||"?"),"err");
      el.classList.remove("busy");el.innerHTML=old;return;}
    current=j.node;
    document.getElementById("stNode").textContent=current.code+" "+current.name;
    if(j.exitIP)document.getElementById("stIP").textContent=j.exitIP;
    renderGrid();
    toast("已切换 "+(j.exitIP||"")+(j.latency?" · "+j.latency+"ms":""),"ok");
  }catch(e){
    toast("请求失败: "+e.message,"err");
    el.classList.remove("busy");el.innerHTML=old;
  }finally{busy=false;}
}

/* ---------- profile ---------- */
async function loadProfiles(){
  const sel=document.getElementById("profSel");
  const hint=document.getElementById("profHint");
  try{
    const r=await fetch("/api/profiles");
    const j=await r.json();
    sel.innerHTML="";
    if(!j.profiles||!j.profiles.length){
      sel.innerHTML='<option value="">未发现 profile</option>';
      hint.innerHTML="扫描了 "+(j.scanned?j.scanned.length:0)+
        " 个位置，没找到 signedInUser.json。请手动填写路径。";
      return;
    }
    for(const p of j.profiles){
      const o=document.createElement("option");
      o.value=p.path;
      const tag=p.hasToken?"✓":"空";
      o.textContent="["+tag+"] "+(p.email||"(未登录)")+" · "+p.path;
      // j.current 是 profile 目录，p.signedInUserPath 是文件路径，两者不同。
      // 之前直接比较（文件 vs 目录）导致当前 profile 永远不会被选中。
      const cur = j.current || "";
      if (cur && (p.path === cur || p.signedInUserPath === cur)) o.selected = true;
      sel.appendChild(o);
    }
    hint.textContent="共 "+j.profiles.length+" 个 profile（系统: "+j.os+"）";
  }catch(e){hint.textContent="扫描失败: "+e.message;}
}

document.getElementById("btnScan").onclick=loadProfiles;

document.getElementById("profSel").onchange=async e=>{
  const p=e.target.value;
  if(!p)return;
  document.getElementById("profPath").value=p;
  await applyProfile(p);
};

document.getElementById("btnProf").onclick=async()=>{
  const p=document.getElementById("profPath").value.trim();
  if(!p){toast("请填写 profile 路径","err");return;}
  await applyProfile(p);
};

async function applyProfile(p){
  const btn=document.getElementById("btnProf");
  btn.disabled=true;btn.textContent="验证中…";
  try{
    const r=await fetch("/api/profile",{method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:p})});
    const j=await r.json();
    if(j.ok){toast("profile 已切换: "+(j.profile.email||"")+"","ok");
      renderTok(j.status);}
    else toast(j.error||"失败","err");
  }catch(e){toast("请求失败: "+e.message,"err");}
  finally{btn.disabled=false;btn.textContent="应用";}
}

/* ---------- 启动 ---------- */
/* ---------- 配置文件 ---------- */
let cfg={};

async function loadCfg(){
  try{
    const r=await fetch("/api/config");
    const j=await r.json();
    cfg=j;
    const sw=document.getElementById("cfgSave");
    if(sw) sw.checked=!!j.saveToken;

    const hint=document.getElementById("cfgSaveHint");
    if(hint){
      const km={dpapi:"DPAPI 加密（绑定本机与本用户）",
                aes:"AES-256 加密（绑定本机 machine-id）",
                plain:"⚠ 明文保存（不推荐）",none:"未加密"};
      hint.textContent=j.hasToken?"已保存 · "+(km[j.tokenCipher]||j.tokenCipher)
                                 :(j.saveToken?(km[j.tokenCipher]||""):"关闭中");
    }
    const ph=document.getElementById("cfgPathHint");
    if(ph) ph.textContent="配置文件："+j.path;

    // 用配置补齐界面（仅当界面还没值时不覆盖用户输入）
    if(j.profile && !document.getElementById("profPath").value)
      document.getElementById("profPath").value=j.profile;
    if(j.listen && !document.getElementById("svcAddr").value)
      document.getElementById("svcAddr").value=j.listen;
  }catch(e){}
}

async function patchCfg(body){
  try{
    const r=await fetch("/api/config",{method:"POST",
      headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const j=await r.json();
    if(!j.ok){toast(j.error||"保存失败","err");return false;}
    await loadCfg();
    return true;
  }catch(e){toast("保存失败: "+e.message,"err");return false;}
}

document.getElementById("cfgSave").onchange=async(e)=>{
  const on=e.target.checked;
  if(!on){
    // 关掉 = 立刻删除已存凭证
    if(await patchCfg({saveToken:false,clearToken:true}))
      toast("已关闭记住登录，本地凭证已清除","ok");
    return;
  }
  // 打开：把当前生效的 token 加密存下来
  const ok=await patchCfg({saveToken:true});
  if(!ok)return;
  try{
    const r=await fetch("/api/token/remember",{method:"POST"});
    const j=await r.json();
    if(j.ok) toast("已加密保存登录凭证","ok");
    else toast(j.error||"没有可保存的凭证（请先从 Firefox profile 读取或粘贴 sessionToken）","err");
  }catch(e){toast("保存失败: "+e.message,"err");}
};

document.getElementById("btnCfgSave").onclick=async()=>{
  const body={
    profile:document.getElementById("profPath").value.trim(),
    listen:document.getElementById("svcAddr").value.trim(),
    loginProxy:(mode==="direct")?"direct":
      (mode==="socks5"?"socks5://"+document.getElementById("proxyURL").value.trim()
                       :"http://"+document.getElementById("proxyURL").value.trim()),
    ipMode:(document.querySelector("#ipSeg button.on")||{}).dataset?.ip||"auto",
    nodeIP:(document.querySelector("#nodeIPSeg button.on")||{}).dataset?.nodeip||"auto",
    node:(current&&current.host)||""
  };
  if(await patchCfg(body)) toast("设置已保存到配置文件","ok");
};

document.getElementById("btnCfgClear").onclick=async()=>{
  if(!confirm("确定清除已保存的登录凭证？清除后需要从 Firefox profile 重新读取。"))return;
  if(await patchCfg({clearToken:true,saveToken:false})){
    document.getElementById("cfgSave").checked=false;
    toast("已清除本地凭证","ok");
  }
};

async function boot(){
  document.getElementById("q").oninput=renderGrid;
  setMode("direct");

  // 排序切换
  document.querySelectorAll("#sortSeg button").forEach(b=>{
    b.onclick=()=>{
      sortBy=b.dataset.sort;
      document.querySelectorAll("#sortSeg button").forEach(x=>
        x.classList.toggle("on",x===b));
      renderGrid();
    };
  });
  document.getElementById("btnPing").onclick=()=>loadPing(true);
  // 顶部栏的「续期」= Token 卡片里的「手动续期」
  {
    const top=document.getElementById("btnRefreshTop");
    const inner=document.getElementById("btnRefresh");
    if(top) top.onclick=()=>{ if(inner&&inner.onclick) inner.click(); };
  }

  await loadCfg();
  await loadTok();
  await loadProfiles();
  await loadSvc();
  setInterval(loadSvc,5000);
  clearInterval(tokTimer);
  tokTimer=setInterval(tick,1000);
  setInterval(loadTok,30000);

  try{
    const r=await fetch("/api/nodes");
    const j=await r.json();
    nodes=j.nodes||[];current=j.current||null;
    if(current){
      document.getElementById("stNode").textContent=current.code+" "+cn(current.name);
      const sf=document.getElementById("sfNode");
      if(sf)sf.textContent=current.code; // sidefoot
    }
    const nc=document.getElementById("navNodeCnt");
    if(nc)nc.textContent=nodes.length||"—";
    renderGrid();
    loadH3();
  }catch(e){toast("节点加载失败: "+e.message,"err");}

  setInterval(loadH3,8000);
  setInterval(loadSpeed,1000);

  // 自动测一次延迟（后端 60 秒缓存，不会反复打）
  loadPing(false);

  // 读当前登录出站配置
  try{
    const r=await fetch("/api/login-proxy");
    const j=await r.json();
    if(j.proxyURL){
      const p=j.proxyURL;
      if(p.startsWith("socks5")){setMode("socks5");
        document.getElementById("proxyURL").value=p.replace(/^socks5h?:\/\//,"");}
      else {setMode("http");
        document.getElementById("proxyURL").value=p.replace(/^https?:\/\//,"");}
    }else{
      // 后端返回空 = 直连
      setMode("direct");
    }
  }catch(e){}
}
boot();
</script>
</body>
</html>
`
