package main

// resolve.go: 目标地址解析策略（控制 IPv4 / IPv6 优先）
//
// 背景：IPP 节点支持双栈，但节点本身通常只有 IPv4 地址。
// CONNECT 里如果传主机名，实际是**出口节点替我们解析**，
// 出口按自己的偏好（多为 IPv6 优先）选 AAAA，于是我们被"带上 IPv6 出口"。
//
// 想强制 IPv4 出口，就得在**发 CONNECT 之前**在本机把域名解析成 IPv4 字面量，
// 让节点只能连那个 IPv4。
//
// 策略：
//   auto   本机默认（双栈，通常 IPv6 优先）
//   ipv4   只解析 A 记录，强制 IPv4 出口
//   ipv6   只解析 AAAA 记录，强制 IPv6
//   remote 不解析，直接把域名交给节点（旧行为）

import (
	"context"
	"fmt"
	"net"
	"strings"
	"sync"
	"time"
)

// IPMode 出口 IP 策略
type IPMode string

const (
	IPModeAuto   IPMode = "auto"
	IPModeV4     IPMode = "ipv4"
	IPModeV6     IPMode = "ipv6"
	IPModeRemote IPMode = "remote"
)

// ParseIPMode 从字符串解析
func ParseIPMode(s string) (IPMode, error) {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "", "auto", "default":
		return IPModeAuto, nil
	case "ipv4", "v4", "4":
		return IPModeV4, nil
	case "ipv6", "v6", "6":
		return IPModeV6, nil
	case "remote", "proxy", "server":
		return IPModeRemote, nil
	}
	return IPModeAuto, fmt.Errorf("未知的 IP 模式 %q（可选 auto/ipv4/ipv6/remote）", s)
}

// String 便于界面显示
func (m IPMode) String() string {
	if m == "" {
		return string(IPModeAuto)
	}
	return string(m)
}

// resolver 带缓存的解析器
type resolver struct {
	mode IPMode

	mu    sync.Mutex
	cache map[string]cacheEntry
}

type cacheEntry struct {
	ip  string
	err error
	at  time.Time
}

const resolveTTL = 5 * time.Minute

func newResolver(mode IPMode) *resolver {
	return &resolver{mode: mode, cache: map[string]cacheEntry{}}
}

// SetMode 热切换策略（同时清缓存）
func (r *resolver) SetMode(m IPMode) {
	r.mu.Lock()
	r.mode = m
	r.cache = map[string]cacheEntry{}
	r.mu.Unlock()
}

// Mode 当前策略
func (r *resolver) Mode() IPMode {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.mode
}

// Resolve 按策略处理 target（形如 host:port）
//
// 返回可直接放进 CONNECT 的字符串。
func (r *resolver) Resolve(target string) (string, error) {
	host, port, err := net.SplitHostPort(target)
	if err != nil {
		// 没有端口，原样返回（让调用方处理）
		return target, nil
	}

	// 已经是 IP 字面量，无需处理
	if ip := net.ParseIP(host); ip != nil {
		return target, nil
	}

	mode := r.Mode()
	if mode == IPModeRemote || mode == IPModeAuto {
		// remote: 交给节点解析
		// auto: 也交给节点，保持与 Firefox 一致的双栈行为
		return target, nil
	}

	ip, err := r.lookup(host)
	if err != nil {
		return "", err
	}
	return net.JoinHostPort(ip, port), nil
}

// lookup 按模式解析（带缓存）
func (r *resolver) lookup(host string) (string, error) {
	r.mu.Lock()
	if e, ok := r.cache[host]; ok && time.Since(e.at) < resolveTTL {
		r.mu.Unlock()
		return e.ip, e.err
	}
	mode := r.mode
	r.mu.Unlock()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	network := "ip4"
	if mode == IPModeV6 {
		network = "ip6"
	}

	ips, err := net.DefaultResolver.LookupIP(ctx, network, host)
	if err != nil {
		r.store(host, "", err)
		return "", err
	}
	if len(ips) == 0 {
		err = fmt.Errorf("%s 没有 %s 地址", host, network)
		r.store(host, "", err)
		return "", err
	}

	ip := ips[0].String()
	r.store(host, ip, nil)
	return ip, nil
}

func (r *resolver) store(host, ip string, err error) {
	r.mu.Lock()
	// 只在缓存过大时清理
	if len(r.cache) > 2000 {
		r.cache = map[string]cacheEntry{}
	}
	r.cache[host] = cacheEntry{ip: ip, err: err, at: time.Now()}
	r.mu.Unlock()
}
