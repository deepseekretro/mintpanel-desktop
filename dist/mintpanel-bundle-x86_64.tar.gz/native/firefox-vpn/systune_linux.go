//go:build linux

package main

// Linux 内核网络参数调优。
//
// 背景：QUIC 走 UDP，而 Linux 的 UDP socket 缓冲上限受
// net.core.rmem_max / wmem_max 管控。很多系统默认只有 208KB，
// 此时代码里调 SetReadBuffer(7MB) 会被内核静默截断成 208KB。
//
// 208KB 在 120ms RTT 的链路上，理论上限只有
//   208KB / 0.12s ≈ 1.7 MB/s
// 这正好解释了「h3 生效了但速度上不去」。
//
// 注意：内核的 tcp_congestion_control=bbr 只作用于 TCP，
// 对我们主要的 UDP/QUIC 隧道没有作用，所以这里调的是
// 「缓冲区」而不是「拥塞算法」——这才是 QUIC 吞吐的真正瓶颈。

import (
	"log"
	"os"
	"strconv"
	"strings"
)

// 目标缓冲大小。16MB 在 120ms RTT 下对应约 130MB/s 的 BDP 上限，
// 远超实际可用带宽，留足余量。
const wantSockBuf = 16 * 1024 * 1024

// tuneKernelBuffers 尽量把 UDP/TCP socket 缓冲上限拉高。
//
// 这是尽力而为：容器、非 root、只读 /proc 都可能失败，
// 失败就保持系统默认，不影响功能。
func tuneKernelBuffers() {
	changed := []string{}

	skipped := 0
	maxUp := func(path string, want int) {
		cur, err := readSysInt(path)
		if err != nil {
			// 容器里 /proc/sys/net 常常不可见（net 命名空间隔离），
			// 这是正常情况，不算失败，但要计数避免误报「已足够」
			skipped++
			return
		}
		if cur >= want {
			return
		}
		if err := writeSysInt(path, want); err != nil {
			log.Printf("[sys] %s 提升失败（当前 %s，需要 root 或可写 /proc）: %v",
				path, humanBytes(cur), err)
			return
		}
		changed = append(changed, path)
	}

	// UDP/QUIC 主要看这两个
	maxUp("/proc/sys/net/core/rmem_max", wantSockBuf)
	maxUp("/proc/sys/net/core/wmem_max", wantSockBuf)

	// 默认值也提上来，避免新 socket 从很小的初始窗口慢慢涨
	maxUp("/proc/sys/net/core/rmem_default", 4*1024*1024)
	maxUp("/proc/sys/net/core/wmem_default", 4*1024*1024)

	// TCP 侧（h1 回退路径）也顺手调，但它俩是三元组，单独处理
	tuneTCPMem()

	switch {
	case len(changed) > 0:
		log.Printf("[sys] 已提升 socket 缓冲上限: %s", strings.Join(changed, ", "))
	case skipped >= 4:
		log.Printf("[sys] /proc/sys/net 不可写（容器/受限环境），socket 缓冲沿用系统默认")
	default:
		log.Printf("[sys] socket 缓冲上限已足够，无需调整")
	}

	// 顺带报告一下拥塞算法状态（仅信息，QUIC 用不到）
	if cc, err := os.ReadFile("/proc/sys/net/ipv4/tcp_congestion_control"); err == nil {
		name := strings.TrimSpace(string(cc))
		if name == "bbr" {
			log.Printf("[sys] TCP 拥塞控制 = bbr（对 h1 路径有效，QUIC 不适用）")
		}
	}
}

// tuneTCPMem 单独处理 tcp_rmem/tcp_wmem 三元组（min default max）
func tuneTCPMem() {
	for _, path := range []string{
		"/proc/sys/net/ipv4/tcp_rmem",
		"/proc/sys/net/ipv4/tcp_wmem",
	} {
		raw, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		parts := strings.Fields(strings.TrimSpace(string(raw)))
		if len(parts) != 3 {
			continue
		}
		mx, _ := strconv.Atoi(parts[2])
		if mx >= wantSockBuf {
			continue
		}
		// min 保持原值，default 提到 1MB，max 提到目标值
		val := parts[0] + "\t" + "1048576" + "\t" + strconv.Itoa(wantSockBuf)
		if err := os.WriteFile(path, []byte(val), 0o644); err != nil {
			continue
		}
		log.Printf("[sys] 已提升 %s -> max %s", path, humanBytes(wantSockBuf))
	}
}

func readSysInt(path string) (int, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return 0, err
	}
	n, err := strconv.Atoi(strings.TrimSpace(string(b)))
	if err != nil {
		return 0, err
	}
	return n, nil
}

func writeSysInt(path string, v int) error {
	return os.WriteFile(path, []byte(strconv.Itoa(v)), 0o644)
}

func humanBytes(n int) string {
	switch {
	case n >= 1<<20:
		return strconv.Itoa(n>>20) + "MB"
	case n >= 1<<10:
		return strconv.Itoa(n>>10) + "KB"
	default:
		return strconv.Itoa(n) + "B"
	}
}
