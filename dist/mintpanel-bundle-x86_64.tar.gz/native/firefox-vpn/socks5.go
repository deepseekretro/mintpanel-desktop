package main

// socks5.go: 最小的 SOCKS5 客户端拨号器（RFC 1928）
//
// Go 标准库的 http.Transport 只支持 http/https 代理，
// 要连 SOCKS5 得自己实现 DialContext。
// 只实现 CONNECT 命令（无认证 + 用户名密码认证），
// 够"换 token 时走代理"这个场景用了。

import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"net/url"
	"strconv"
	"time"
)

type socks5Dialer struct {
	proxy *url.URL
	// 超时
	Timeout time.Duration
}

// DialContext 实现传输层拨号
func (d *socks5Dialer) DialContext(ctx context.Context, network, addr string) (net.Conn, error) {
	if network != "tcp" && network != "tcp4" && network != "tcp6" {
		return nil, fmt.Errorf("SOCKS5 只支持 tcp，收到 %s", network)
	}

	timeout := d.Timeout
	if timeout <= 0 {
		timeout = 15 * time.Second
	}

	proxyAddr := d.proxy.Host
	if d.proxy.Port() == "" {
		proxyAddr = net.JoinHostPort(d.proxy.Hostname(), "1080")
	}

	var dd net.Dialer
	conn, err := dd.DialContext(ctx, "tcp", proxyAddr)
	if err != nil {
		return nil, fmt.Errorf("连 SOCKS5 代理失败: %w", err)
	}
	conn.SetDeadline(time.Now().Add(timeout))

	// 需要在失败时关掉连接
	fail := func(e error) (net.Conn, error) {
		conn.Close()
		return nil, e
	}

	// ---- 1. 方法协商 ----
	// 有用户名密码就同时提供 0x00(无认证) 和 0x02
	methods := []byte{0x00}
	hasAuth := d.proxy.User != nil
	if hasAuth {
		methods = append(methods, 0x02)
	}
	greet := append([]byte{0x05, byte(len(methods))}, methods...)
	if _, err := conn.Write(greet); err != nil {
		return fail(err)
	}

	reply := make([]byte, 2)
	if _, err := io.ReadFull(conn, reply); err != nil {
		return fail(err)
	}
	if reply[0] != 0x05 {
		return fail(fmt.Errorf("不是 SOCKS5 代理（版本 %d）", reply[0]))
	}

	switch reply[1] {
	case 0x00:
		// 无需认证
	case 0x02:
		if !hasAuth {
			return fail(fmt.Errorf("代理要求认证，但未提供用户名密码"))
		}
		user := d.proxy.User.Username()
		pass, _ := d.proxy.User.Password()
		if len(user) > 255 || len(pass) > 255 {
			return fail(fmt.Errorf("用户名或密码过长"))
		}
		// 版本 0x01 + ULEN + UNAME + PLEN + PASSWD
		auth := []byte{0x01, byte(len(user))}
		auth = append(auth, user...)
		auth = append(auth, byte(len(pass)))
		auth = append(auth, pass...)
		if _, err := conn.Write(auth); err != nil {
			return fail(err)
		}
		ar := make([]byte, 2)
		if _, err := io.ReadFull(conn, ar); err != nil {
			return fail(err)
		}
		if ar[1] != 0x00 {
			return fail(fmt.Errorf("SOCKS5 认证失败"))
		}
	case 0xFF:
		return fail(fmt.Errorf("代理不接受任何认证方式"))
	default:
		return fail(fmt.Errorf("代理选了不支持的认证方式 0x%02x", reply[1]))
	}

	// ---- 2. CONNECT 请求 ----
	host, portStr, err := net.SplitHostPort(addr)
	if err != nil {
		return fail(fmt.Errorf("目标地址无效 %q: %w", addr, err))
	}
	port, err := strconv.Atoi(portStr)
	if err != nil || port < 1 || port > 65535 {
		return fail(fmt.Errorf("端口无效 %q", portStr))
	}

	req := []byte{0x05, 0x01, 0x00} // VER, CMD=CONNECT, RSV
	if ip := net.ParseIP(host); ip != nil {
		if ip4 := ip.To4(); ip4 != nil {
			req = append(req, 0x01)
			req = append(req, ip4...)
		} else {
			req = append(req, 0x04)
			req = append(req, ip.To16()...)
		}
	} else {
		// 域名交给代理解析（socks5h 语义）
		if len(host) > 255 {
			return fail(fmt.Errorf("主机名过长"))
		}
		req = append(req, 0x03, byte(len(host)))
		req = append(req, host...)
	}
	req = binary.BigEndian.AppendUint16(req, uint16(port))

	if _, err := conn.Write(req); err != nil {
		return fail(err)
	}

	// ---- 3. 读回复 ----
	head := make([]byte, 4) // VER, REP, RSV, ATYP
	if _, err := io.ReadFull(conn, head); err != nil {
		return fail(err)
	}
	if head[1] != 0x00 {
		return fail(fmt.Errorf("SOCKS5 CONNECT 被拒: %s", socks5ErrText(head[1])))
	}

	// 按地址类型吃掉 BND.ADDR + BND.PORT
	var skip int
	switch head[3] {
	case 0x01:
		skip = 4 + 2
	case 0x04:
		skip = 16 + 2
	case 0x03:
		l := make([]byte, 1)
		if _, err := io.ReadFull(conn, l); err != nil {
			return fail(err)
		}
		skip = int(l[0]) + 2
	default:
		return fail(fmt.Errorf("未知地址类型 0x%02x", head[3]))
	}
	if _, err := io.ReadFull(conn, make([]byte, skip)); err != nil {
		return fail(err)
	}

	conn.SetDeadline(time.Time{})
	return conn, nil
}

func socks5ErrText(code byte) string {
	switch code {
	case 0x01:
		return "服务器故障"
	case 0x02:
		return "规则不允许"
	case 0x03:
		return "网络不可达"
	case 0x04:
		return "主机不可达"
	case 0x05:
		return "连接被拒"
	case 0x06:
		return "TTL 过期"
	case 0x07:
		return "不支持的命令"
	case 0x08:
		return "不支持的地址类型"
	}
	return fmt.Sprintf("未知错误 0x%02x", code)
}
