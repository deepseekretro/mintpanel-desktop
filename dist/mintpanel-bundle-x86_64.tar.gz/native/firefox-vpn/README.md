# MyGo — Firefox IP Protection 客户端

把 Firefox 的 VPN（IP Protection）能力抽出来，做成一个独立的本地代理。

最终效果：本机任意程序只要设置 `127.0.0.1:1080` 作为 HTTP 代理，
出口流量就从 Mozilla 的 IPP 节点出去，无需安装/运行 Firefox。

---

## 快速开始（Windows）

```
双击运行  ipp-gost-windows-amd64.exe
```

默认会做三件事：

| 项目 | 默认值 |
|---|---|
| 本地代理 | `127.0.0.1:1080`（HTTP CONNECT，无认证） |
| 管理界面 | `http://127.0.0.1:1081/` |
| Firefox profile | 自动扫描 `%APPDATA%\Mozilla\Firefox\Profiles\` |

打开浏览器访问 `http://127.0.0.1:1081/` 即可看到界面。

> **前置条件**：至少用 Firefox 登录过一次 Mozilla 账号（Firefox 内的
> "IP Protection / VPN" 需可用）。客户端从 profile 里读 sessionToken，
> 之后自动续期，不需要 Firefox 一直开着。

---

## 命令行参数

```
ipp-gost-windows-amd64.exe [参数]

  -listen string        本地代理监听地址（默认 127.0.0.1:10909）
  -admin  string        管理界面地址（默认空 = 随机端口 + 自动开浏览器；填 off 关闭）
  -open   bool          启动后自动在浏览器打开管理界面（默认 true）
  -profile string       手动指定 Firefox profile 目录
  -node   string        指定 IPP 节点主机名（默认自动探测最快节点）
  -node-port int        IPP 节点端口（默认 2499）
  -node-ip string       连 Mozilla 节点用的 IP 族: auto/ipv4/ipv6（默认 auto）
  -ip-mode string       节点出口 IP 族: ipv4/ipv6/auto/remote（默认 auto）
  -warm   int           节点预热条数（默认 10，0=禁用；h3 启用时自动跳过）
  -h3     bool          用 HTTP/3 隧道（默认 true，节点不支持会自动降级）
  -h3-conns int         预热的 QUIC 连接条数（默认 4，每条最多 64 路复用）
  -login-proxy string   登录换 token 时使用的出站代理
                        （默认 http://127.0.0.1:8080；填 direct 则直连）
  -listen-public string 额外开一个公开的无认证代理（如 0.0.0.0:1080）
  -list-servers         打印服务器列表后退出
  -status               打印账号状态后退出
  -fxa-token string     直接用 access token（不做自动续期）
```

### 两个 IP 设置的区别

界面上有两组 IP 选项，容易混淆：

| 设置 | 含义 | 参数 |
|---|---|---|
| **连节点用** | 本机 → Mozilla 节点（走的什么 IP 族） | `-node-ip` |
| **出口用** | 节点 → 目标网站（目标看到的 IP） | `-ip-mode` |

默认 `-node-ip auto`（Happy Eyeballs）、`-ip-mode auto`。

### 性能调优

`-warm 10` 是 h1 路径的默认值。

**注意**：h3 启用时 h1 预热池会自动跳过（`[warm] h3 已启用，跳过 HTTP/1.1 预热池`），
因为一条 QUIC 连接可复用 64 路，不需要囤一堆只能跑单目标的 h1 连接。
只有 h3 探测失败降级时，才会自动补启动 h1 预热池。

现代网页会同时发起 6~10 个不同域名的连接（主站 + CDN + 图片 + API +
字体 + 埋点），而一条 HTTP/1.1 CONNECT 只能承载一个目标，所以池子必须
覆盖常见并发域名数才有收益。默认 2 时多域名页面会瞬间耗尽。

预热池维护 **到节点的外层 TLS 连接**，与访问哪个网站无关：

- 池大小固定，不随访问站点数增长
- 空闲 45 秒自动淘汰重建
- 取用后异步补回，保证池恒满
- 并发隧道上限 256，超过返回 503

实测 600 并发请求后 RSS / fd 零增长（3.5MB 恒定）。

调整依据看 `/api/warm`：

```json
{
  "idle": 10, "used": 175, "total": 189,
  "hitRate": 0.98,
  "burst": {"missPerMin": 3, "inflight": 4, "peak": 12}
}
```

`hitRate` 低于 0.8 或 `missPerMin` 持续偏高，说明并发超出了池容量，可调大 `-warm`。

| warm 值 | 适用场景 |
|---|---|
| 0 | 关闭预热（调试/排障） |
| 2 | 对齐 Firefox 行为，轻量浏览 |
| 10 | 默认，覆盖典型多域名页面 |
| 20+ | 批量抓取/高并发 |

### 常用组合

```bat
:: 只监听本机（默认，最安全）
ipp-gost-windows-amd64.exe

:: 换端口 + 手动指定 profile
ipp-gost-windows-amd64.exe -listen 127.0.0.1:7890 ^
    -profile "%APPDATA%\Mozilla\Firefox\Profiles\xxxx.default-release"

:: 局域网共享（慎用：无认证，谁都能拿来当梯子）
ipp-gost-windows-amd64.exe -listen-public 0.0.0.0:1080

:: 登录时走代理（客户端在受限网络里、直连 Mozilla 不通时）
ipp-gost-windows-amd64.exe -login-proxy socks5://127.0.0.1:10808
```

---

## 界面功能

打开 `http://127.0.0.1:1081/`：

### 1. Firefox Profile
- 自动扫描所有平台的 profile 位置，列出带 `✓` 标记的（已登录）
- 可手动填路径，支持：
  - profile 目录：`...\Profiles\xxxx.default-release`
  - 根目录：`...\Profiles`（自动选最新）
  - 文件：`...\signedInUser.json`
- 粘贴 Windows 路径带引号也能识别

### 2. 登录 / 出站配置
- **出站方式**：直连 / HTTP 代理 / SOCKS5
- 代理地址可点「测试连通」验证延迟
- 可**粘贴 sessionToken**（64 字符 hex）直接生效

> 说明：Mozilla 已关闭邮箱密码直接登录（`/v1/account/login` → 406），
> OAuth 授权页又有 JS 风控（Client Challenge）。
> **唯一可行路径是从 Firefox profile 读取 sessionToken**，这也是本客户端的方式。

### 3. Token 状态（倒计时）
- 环形进度圈 + `HH:MM:SS` 精确倒计时
- 显示 `可自动续期` / `只读·到期需手动`
- **到期前 60 秒自动续期**，与 Firefox 的 `OAUTH_MIN_TIME_LEFT_SECS` 完全一致
- 也可以点「手动续期」立即换新 token

### 4. 出口节点
- 34 个国家/地区节点，带国旗
- 支持搜索（国家名 / 代码 / 主机名）
- 切换前会先探测（真实建隧道 → 访问 ifconfig.me → 测延迟），失败自动回滚
- 切换不影响已建立的连接

---

## 原理（简要）

```
本机程序 --HTTP CONNECT--> ipp-gost:1080
                              |
                              | ① FxA sessionToken --HKDF+Hawk--> access token
                              | ② POST vpn.mozilla.org/api/v1/fpn/token --> ProxyPass JWT (601s)
                              | ③ TLS 1.3 连节点 *.m1.fastly-masque.net:2499
                              | ④ HTTP CONNECT + Proxy-Authorization: Bearer <pass>
                              | ⑤ 在隧道里再套一层 TLS 到目标站
                              v
                          目标网站
```

要点：
- IPP **不是** SOCKS5，也不是 Shadowsocks
- 是**带认证的 HTTPS 正向代理（HTTP CONNECT）跑在 TLS 1.3 里**
- 内层再套一次 TLS 到目标（端到端加密）
- **HTTP/3（QUIC）隧道已支持**：节点在 ALPN `h3` 上接受扩展 CONNECT（RFC 9220）。
  h2 的 CONNECT 会被拒（`400 Invalid CONNECT request`），但 h3 认（返回 JWT 校验错误
  说明协议层已通过）。因此一条 QUIC 连接可复用承载多个 CONNECT stream，
  不再需要每个目标各建一条 TLS 连接

详细协议逆向见 `ipp-protocol-spec.md`。

---

## 文件清单

| 文件 | 说明 |
|---|---|
| `ipp-gost-windows-amd64.exe` | Windows x64（最常见） |
| `ipp-gost-windows-arm64.exe` | Windows on ARM |
| `ipp-gost-darwin-arm64` | macOS Apple Silicon |
| `ipp-gost`（Linux 版另行编译） | `GOOS=linux go build` |
| `ipp-protocol-spec.md` | 协议逆向完整文档 |
| `REPORT.md` | 逆向过程报告 |

---

## 构建

交叉编译全部平台（无需目标机器）：

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o ipp-gost-windows-amd64.exe .
GOOS=windows GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o ipp-gost-windows-arm64.exe .
GOOS=darwin  GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o ipp-gost-darwin-arm64 .
GOOS=linux   GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o ipp-gost-linux-amd64 .
```

要求 Go 1.22+。**纯标准库，无第三方依赖**。

---

## 注意

- 管理界面只监听 `127.0.0.1`，不要暴露到公网（无认证）
- `-listen-public 0.0.0.0:1080` 开出来的是**无认证公开代理**，
  放公网会被扫到滥用，会消耗你的 50 GiB/月 配额
- sessionToken 等同于账号凭证，不要外泄
- 配额：Mozilla 免费 50 GiB/月
