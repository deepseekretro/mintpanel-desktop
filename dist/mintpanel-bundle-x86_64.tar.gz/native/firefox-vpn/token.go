package main

// token.go: 获取 FxA access token
//
// 两级策略：
//   1. 用 profile 里的 sessionToken 主动换新 access token（推荐，可无限续期）
//   2. 退化为读 profile 里现成的 access token（需 Firefox 登录过）

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"sort"
	"time"
)

// Firefox 的续期阀值，见 omni.ja:modules/FxAccounts.sys.mjs:73
//
//	const OAUTH_MIN_TIME_LEFT_SECS = 60;
//
// 以及 getCachedToken() 里的判定（同文件:246）：
//
//	if (result.expiresAt <= nowSecs + OAUTH_MIN_TIME_LEFT_SECS) return null;
//
// 即：缓存 token 剩余不足 60 秒就重新取。这里保持一致。
const oauthMinTimeLeftSecs = 60

const vpnScopeKey = "https://identity.mozilla.com/apps/vpn|profile"

type oauthToken struct {
	Token     string `json:"token"`
	ExpiresAt int64  `json:"expiresAt"`
}

type accountData struct {
	Email        string                `json:"email"`
	UID          string                `json:"uid"`
	SessionToken string                `json:"sessionToken"`
	OAuthTokens  map[string]oauthToken `json:"oauthTokens"`
}

type signedInUser struct {
	AccountData accountData `json:"accountData"`
}

// defaultProfileRoots 返回各平台常见的 Firefox profile 根目录
//
// 支持 Linux / macOS / Windows。用户也可用 -profile 手动指定。
func defaultProfileRoots() []string {
	home, _ := os.UserHomeDir()
	var roots []string

	// ---- Linux ----
	roots = append(roots,
		filepath.Join(home, ".mozilla", "firefox"),
		filepath.Join(home, ".config", "mozilla", "firefox"),
		filepath.Join(home, "snap", "firefox", "common", ".mozilla", "firefox"),
		filepath.Join(home, ".var", "app", "org.mozilla.firefox", ".mozilla", "firefox"),
	)

	// ---- macOS ----
	roots = append(roots,
		filepath.Join(home, "Library", "Application Support", "Firefox", "Profiles"),
	)

	// ---- Windows ----
	// 用 os.Getenv 而非 runtime.GOOS 判断，因为 WSL 下也可能访问 Windows 目录
	if appData := os.Getenv("APPDATA"); appData != "" {
		roots = append(roots,
			filepath.Join(appData, "Mozilla", "Firefox", "Profiles"),
		)
	}
	if home != "" {
		// 常见 Windows 默认位置（Windows 上 home 形如 C:\Users\xxx）
		roots = append(roots,
			filepath.Join(home, "AppData", "Roaming", "Mozilla", "Firefox", "Profiles"),
		)
	}

	// WSL 下挂载的 Windows 用户目录
	if users, err := os.ReadDir("/mnt/c/Users"); err == nil {
		for _, u := range users {
			if !u.IsDir() {
				continue
			}
			n := u.Name()
			if n == "Public" || n == "Default" || n == "All Users" || n == "Default User" {
				continue
			}
			roots = append(roots, filepath.Join("/mnt/c/Users", n,
				"AppData", "Roaming", "Mozilla", "Firefox", "Profiles"))
		}
	}

	return roots
}

// findSignedInUser 在 root 下找最新的 signedInUser.json
//
// 支持两种结构：
//
//	root/xxxx.default-release/signedInUser.json   （profile 根目录）
//	root/signedInUser.json                        （直接指向 profile 目录）
func findSignedInUser(root string) (string, error) {
	// 先试直接的 profile 目录
	direct := filepath.Join(root, "signedInUser.json")
	if _, err := os.Stat(direct); err == nil {
		return direct, nil
	}

	matches, err := filepath.Glob(filepath.Join(root, "*", "signedInUser.json"))
	if err != nil || len(matches) == 0 {
		return "", fmt.Errorf("%s 下没有 signedInUser.json", root)
	}
	sort.Slice(matches, func(i, j int) bool {
		si, _ := os.Stat(matches[i])
		sj, _ := os.Stat(matches[j])
		if si == nil || sj == nil {
			return false
		}
		return si.ModTime().After(sj.ModTime())
	})
	return matches[0], nil
}

// TokenSource 提供 access token
type TokenSource struct {
	path         string // signedInUser.json 路径
	sessionToken string
	email        string
	uid          string
	cached       string
	expiry       int64
	getNet       func() *NetConfig // 动态取出站配置（界面可热改）
}

// config 当前出站配置
func (ts *TokenSource) config() NetConfig {
	if ts.getNet != nil {
		if nc := ts.getNet(); nc != nil {
			return *nc
		}
	}
	return DefaultNetConfig()
}

// NewTokenSource 解析 token 来源
func NewTokenSource(explicit, profileDir string) (*TokenSource, error) {
	cfg := DefaultNetConfig()
	return NewTokenSourceWithNet(explicit, profileDir, func() *NetConfig { return &cfg })
}

// NewTokenSourceWithNet 同上，但出站配置由 getNet 提供
//
// 传函数而不是值，这样界面改了代理后，下一次刷新 token 立即生效。
func NewTokenSourceWithNet(explicit, profileDir string, getNet func() *NetConfig) (*TokenSource, error) {
	ts := &TokenSource{getNet: getNet}
	if explicit != "" {
		ts.cached = explicit
		ts.expiry = time.Now().Add(24 * time.Hour).Unix()
		return ts, nil
	}

	var file string
	if profileDir != "" {
		cand := filepath.Join(profileDir, "signedInUser.json")
		if _, err := os.Stat(cand); err == nil {
			file = cand
		} else if f, err := findSignedInUser(profileDir); err == nil {
			file = f
		}
	}
	if file == "" {
		for _, root := range defaultProfileRoots() {
			if f, err := findSignedInUser(root); err == nil {
				file = f
				break
			}
		}
	}
	if file == "" {
		return nil, errors.New("未找到 Firefox profile；请用 -fxa-token 或 -profile 指定")
	}

	ts.path = file
	if err := ts.loadProfile(); err != nil {
		return nil, err
	}

	// 优先用 sessionToken 主动续期
	if ts.sessionToken != "" {
		if err := ts.refresh(); err == nil {
			return ts, nil
		} else if ts.cached == "" {
			return nil, fmt.Errorf("sessionToken 续期失败且无缓存 token: %w", err)
		}
	}
	if ts.cached == "" {
		return nil, errors.New("profile 中无可用 token，请在 Firefox 中登录一次")
	}
	return ts, nil
}

// loadProfile 读取 profile 内容
func (ts *TokenSource) loadProfile() error {
	b, err := os.ReadFile(ts.path)
	if err != nil {
		return err
	}
	var s signedInUser
	if err := json.Unmarshal(b, &s); err != nil {
		return fmt.Errorf("解析 signedInUser.json: %w", err)
	}
	ts.sessionToken = s.AccountData.SessionToken
	ts.email = s.AccountData.Email
	ts.uid = s.AccountData.UID

	if tok, ok := s.AccountData.OAuthTokens[vpnScopeKey]; ok && tok.Token != "" {
		ts.cached = tok.Token
		ts.expiry = tok.ExpiresAt
	} else {
		for k, v := range s.AccountData.OAuthTokens {
			if containsVPNScope(k) && v.Token != "" {
				ts.cached, ts.expiry = v.Token, v.ExpiresAt
				break
			}
		}
	}
	return nil
}

// refresh 用 sessionToken 换新 access token
func (ts *TokenSource) refresh() error {
	tok, expiresIn, err := refreshWithSessionToken(ts.sessionToken, ts.config())
	if err != nil {
		log.Printf("[auth] sessionToken 续期失败: %v", err)
		return err
	}
	if expiresIn <= 0 {
		expiresIn = 86400
	}
	ts.cached = tok
	ts.expiry = time.Now().Unix() + expiresIn
	log.Printf("[auth] sessionToken 续期成功: 有效期 %ds (exp=%s)", expiresIn, time.Unix(ts.expiry, 0).Format("15:04:05"))
	return nil
}

func containsVPNScope(s string) bool {
	for i := 0; i+7 <= len(s); i++ {
		if s[i:i+7] == "apps/vpn" || s[i:i+3] == "vpn" {
			return true
		}
	}
	return len(s) > 0 && (s == "vpn")
}

// Get 返回可用 token；逻辑与 Firefox getCachedToken() 一致
func (ts *TokenSource) Get() (string, error) {
	// 与 Firefox 一致：剩余不足 60 秒才重新取
	if ts.expiry > 0 && time.Now().Unix() > ts.expiry-oauthMinTimeLeftSecs {
		if ts.sessionToken != "" {
			if err := ts.refresh(); err != nil {
				return "", fmt.Errorf("token 续期失败: %w", err)
			}
			return ts.cached, nil
		}
		// 没有 sessionToken 才回退到重读 profile
		if ts.path == "" {
			return "", errors.New("token 已过期，无法续期")
		}
		if err := ts.loadProfile(); err != nil {
			return "", err
		}
		if time.Now().Unix() > ts.expiry-oauthMinTimeLeftSecs {
			return "", errors.New("依赖的 token 全部过期，请重新登录 Firefox")
		}
	}
	return ts.cached, nil
}

// Expiry 返回过期时间
func (ts *TokenSource) Expiry() time.Time {
	if ts.expiry == 0 {
		return time.Time{}
	}
	return time.Unix(ts.expiry, 0)
}

// CanRefresh 是否具备主动续期能力
func (ts *TokenSource) CanRefresh() bool { return ts.sessionToken != "" }

// NewTokenSourceEmpty 构造一个「无 token」的 TokenSource
//
// 用于启动时 profile 无效的场景：仍然把 UI 起起来，
// 让用户在页面上扫描/切换 profile，而不是直接退出。
// 调用 Reload(path) 后即可恢复正常。
func NewTokenSourceEmpty(explicit, profileDir string, getNet func() *NetConfig) *TokenSource {
	ts := &TokenSource{getNet: getNet}
	if explicit != "" {
		ts.cached = explicit
		ts.expiry = time.Now().Add(24 * time.Hour).Unix()
	}
	// 保留用户给的路径，便于 UI 回显
	if profileDir != "" {
		ts.path = profileDir
	}
	return ts
}
