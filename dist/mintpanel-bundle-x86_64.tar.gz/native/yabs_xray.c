#define _GNU_SOURCE
#include <node_api.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char *(*fn_start_t)(const char *);
typedef char *(*fn_stop_t)(void);
typedef char *(*fn_status_t)(void);
typedef void (*fn_free_t)(char *);

static void *g_handle = NULL;
static fn_start_t g_start = NULL;
static fn_stop_t g_stop = NULL;
static fn_status_t g_status = NULL;
static fn_free_t g_free = NULL;

static int ensure_loaded(const char *so_path, char *errbuf, size_t errlen) {
    if (g_handle) return 0;
    g_handle = dlopen(so_path, RTLD_NOW | RTLD_GLOBAL);
    if (!g_handle) {
        snprintf(errbuf, errlen, "dlopen failed: %s", dlerror());
        return -1;
    }
    g_start = (fn_start_t)dlsym(g_handle, "XrayStart");
    g_stop = (fn_stop_t)dlsym(g_handle, "XrayStop");
    g_status = (fn_status_t)dlsym(g_handle, "XrayStatusJSON");
    g_free = (fn_free_t)dlsym(g_handle, "XrayFreeStr");
    if (!g_start || !g_stop || !g_status || !g_free) {
        snprintf(errbuf, errlen, "missing symbols in libxray.so");
        return -1;
    }
    return 0;
}

static napi_value xray_start(napi_env env, napi_callback_info info) {
    size_t argc = 2;
    napi_value args[2];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (argc < 2) {
        napi_throw_error(env, NULL, "Expected (soPath, configPath)");
        return NULL;
    }
    char so_path[1024], cfg_path[1024], err[512];
    size_t l1 = 0, l2 = 0;
    napi_get_value_string_utf8(env, args[0], so_path, sizeof(so_path), &l1);
    napi_get_value_string_utf8(env, args[1], cfg_path, sizeof(cfg_path), &l2);

    if (ensure_loaded(so_path, err, sizeof(err)) != 0) {
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    char *msg = g_start(cfg_path);
    if (msg != NULL) {
        snprintf(err, sizeof(err), "%s", msg);
        g_free(msg);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    napi_value ok;
    napi_get_boolean(env, true, &ok);
    return ok;
}

static napi_value xray_stop(napi_env env, napi_callback_info info) {
    (void)info;
    if (!g_handle) {
        napi_value ok;
        napi_get_boolean(env, true, &ok);
        return ok;
    }
    char *msg = g_stop();
    if (msg != NULL) {
        char err[512];
        snprintf(err, sizeof(err), "%s", msg);
        g_free(msg);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    napi_value ok;
    napi_get_boolean(env, true, &ok);
    return ok;
}

static napi_value xray_status(napi_env env, napi_callback_info info) {
    size_t argc = 1;
    napi_value args[1];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (!g_handle && argc >= 1) {
        char so_path[1024], err[512];
        size_t l1 = 0;
        napi_get_value_string_utf8(env, args[0], so_path, sizeof(so_path), &l1);
        if (ensure_loaded(so_path, err, sizeof(err)) != 0) {
            napi_throw_error(env, NULL, err);
            return NULL;
        }
    }
    if (!g_handle) {
        napi_value s;
        napi_create_string_utf8(env, "{\"running\":false,\"config_path\":\"\",\"uptime_sec\":0,\"version\":\"v26.11.9\",\"error\":\"\"}", NAPI_AUTO_LENGTH, &s);
        return s;
    }
    char *json = g_status();
    napi_value s;
    napi_create_string_utf8(env, json ? json : "{}", NAPI_AUTO_LENGTH, &s);
    if (json) g_free(json);
    return s;
}

static napi_value init(napi_env env, napi_value exports) {
    napi_value fn1, fn2, fn3;
    napi_create_function(env, NULL, 0, xray_start, NULL, &fn1);
    napi_create_function(env, NULL, 0, xray_stop, NULL, &fn2);
    napi_create_function(env, NULL, 0, xray_status, NULL, &fn3);
    napi_set_named_property(env, exports, "start", fn1);
    napi_set_named_property(env, exports, "stop", fn2);
    napi_set_named_property(env, exports, "status", fn3);
    return exports;
}

NAPI_MODULE(NODE_GYP_MODULE_NAME, init)
