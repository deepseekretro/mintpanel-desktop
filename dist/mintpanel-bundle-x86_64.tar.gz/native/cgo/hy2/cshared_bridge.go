package cmd

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"

	"github.com/apernet/hysteria/core/v2/server"
	"github.com/spf13/viper"
	"go.uber.org/zap"
)

var (
	csMu        sync.Mutex
	csSrv       server.Server
	csRunning   bool
	csListen    string
	csStartTime time.Time
	csLastErr   string
)

func init() {
	if logger == nil {
		logger = zap.NewNop()
	}
}

func CSharedStartFile(cfgPath string) error {
	b, err := os.ReadFile(cfgPath)
	if err != nil {
		csMu.Lock()
		csLastErr = err.Error()
		csMu.Unlock()
		return err
	}
	return CSharedStartYAML(string(b))
}

func CSharedStartYAML(yamlContent string) error {
	csMu.Lock()
	defer csMu.Unlock()

	if csRunning && csSrv != nil {
		_ = csSrv.Close()
		csSrv = nil
		csRunning = false
	}

	v := viper.New()
	v.SetConfigType("yaml")
	if err := v.ReadConfig(bytes.NewReader([]byte(yamlContent))); err != nil {
		csLastErr = err.Error()
		return fmt.Errorf("read yaml: %w", err)
	}
	var cfg serverConfig
	if err := v.Unmarshal(&cfg); err != nil {
		csLastErr = err.Error()
		return fmt.Errorf("unmarshal config: %w", err)
	}
	hyConfig, err := cfg.Config()
	if err != nil {
		csLastErr = err.Error()
		return fmt.Errorf("build server config: %w", err)
	}
	s, err := server.NewServer(hyConfig)
	if err != nil {
		csLastErr = err.Error()
		return fmt.Errorf("new server: %w", err)
	}

	listen := cfg.Listen
	if listen == "" {
		listen = defaultListenAddr
	}
	csSrv = s
	csRunning = true
	csListen = listen
	csStartTime = time.Now()
	csLastErr = ""

	go func(srv server.Server) {
		if err := srv.Serve(); err != nil {
			csMu.Lock()
			if csSrv == srv {
				csLastErr = err.Error()
				csRunning = false
			}
			csMu.Unlock()
		}
	}(s)

	return nil
}

func CSharedStop() error {
	csMu.Lock()
	defer csMu.Unlock()
	if csSrv != nil {
		err := csSrv.Close()
		csSrv = nil
		csRunning = false
		return err
	}
	csRunning = false
	return nil
}

func CSharedStatusJSON() string {
	csMu.Lock()
	defer csMu.Unlock()
	up := int64(0)
	if csRunning && !csStartTime.IsZero() {
		up = int64(time.Since(csStartTime).Seconds())
	}
	out := map[string]any{
		"running":    csRunning,
		"listen":     csListen,
		"uptime_sec": up,
		"version":    "v2.14.0",
		"error":      csLastErr,
	}
	b, _ := json.Marshal(out)
	return string(b)
}
