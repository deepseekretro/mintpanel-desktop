package main

/*
#include <stdlib.h>
*/
import "C"
import (
	"unsafe"

	"github.com/apernet/hysteria/app/v2/cmd"
)

//export Hy2Start
func Hy2Start(cfgPath *C.char) *C.char {
	if cfgPath == nil {
		return C.CString("nil config path")
	}
	if err := cmd.CSharedStartFile(C.GoString(cfgPath)); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export Hy2StartYAML
func Hy2StartYAML(yamlContent *C.char) *C.char {
	if yamlContent == nil {
		return C.CString("nil yaml content")
	}
	if err := cmd.CSharedStartYAML(C.GoString(yamlContent)); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export Hy2Stop
func Hy2Stop() *C.char {
	if err := cmd.CSharedStop(); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export Hy2StatusJSON
func Hy2StatusJSON() *C.char {
	return C.CString(cmd.CSharedStatusJSON())
}

//export Hy2FreeStr
func Hy2FreeStr(p *C.char) {
	if p != nil {
		C.free(unsafe.Pointer(p))
	}
}

func main() {}
