package main

/*
#include <stdlib.h>
*/
import "C"
import (
	"encoding/json"
	"os"
	"strings"
	"sync"
	"time"
	"unsafe"

	"github.com/xtls/xray-core/core"
	_ "github.com/xtls/xray-core/main/distro/all"
)

var (
	xMu        sync.Mutex
	xSrv       *core.Instance
	xRunning   bool
	xCfgPath   string
	xStartTime time.Time
	xLastErr   string
)

func startFromJSONBytes(b []byte, label string) error {
	xMu.Lock()
	defer xMu.Unlock()

	if xRunning && xSrv != nil {
		_ = xSrv.Close()
		xSrv = nil
		xRunning = false
	}

	cfg, err := core.LoadConfig("json", strings.NewReader(string(b)))
	if err != nil {
		xLastErr = err.Error()
		return err
	}
	inst, err := core.New(cfg)
	if err != nil {
		xLastErr = err.Error()
		return err
	}
	if err := inst.Start(); err != nil {
		_ = inst.Close()
		xLastErr = err.Error()
		return err
	}

	xSrv = inst
	xRunning = true
	xCfgPath = label
	xStartTime = time.Now()
	xLastErr = ""
	return nil
}

//export XrayStart
func XrayStart(cfgPath *C.char) *C.char {
	if cfgPath == nil {
		return C.CString("nil config path")
	}
	p := C.GoString(cfgPath)
	b, err := os.ReadFile(p)
	if err != nil {
		xMu.Lock()
		xLastErr = err.Error()
		xMu.Unlock()
		return C.CString(err.Error())
	}
	if err := startFromJSONBytes(b, p); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export XrayStartJSON
func XrayStartJSON(jsonContent *C.char) *C.char {
	if jsonContent == nil {
		return C.CString("nil json content")
	}
	if err := startFromJSONBytes([]byte(C.GoString(jsonContent)), "memory://json"); err != nil {
		return C.CString(err.Error())
	}
	return nil
}

//export XrayStop
func XrayStop() *C.char {
	xMu.Lock()
	defer xMu.Unlock()
	if xSrv != nil {
		err := xSrv.Close()
		xSrv = nil
		xRunning = false
		if err != nil {
			return C.CString(err.Error())
		}
	}
	xRunning = false
	return nil
}

//export XrayStatusJSON
func XrayStatusJSON() *C.char {
	xMu.Lock()
	defer xMu.Unlock()
	up := int64(0)
	if xRunning && !xStartTime.IsZero() {
		up = int64(time.Since(xStartTime).Seconds())
	}
	out := map[string]any{
		"running":     xRunning,
		"config_path": xCfgPath,
		"uptime_sec":  up,
		"version":     "v" + core.Version(),
		"error":       xLastErr,
	}
	b, _ := json.Marshal(out)
	return C.CString(string(b))
}

//export XrayFreeStr
func XrayFreeStr(p *C.char) {
	if p != nil {
		C.free(unsafe.Pointer(p))
	}
}

func main() {}
