#define _GNU_SOURCE
#include <node_api.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/aio_abi.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

#define DEFAULT_IODEPTH 64

typedef struct {
    int fd;
    size_t block_size;
    size_t num_blocks;
    double duration_sec;
    int iodepth;
    int use_aio;
    uint64_t seed;
    uint64_t read_bytes;
    uint64_t write_bytes;
    uint64_t read_ops;
    uint64_t write_ops;
    int err;
} worker_arg_t;

static inline uint64_t xorshift64(uint64_t *s) {
    uint64_t x = *s;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *s = x;
    return x;
}

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static int sys_io_setup(unsigned nr, aio_context_t *ctx) {
    return (int)syscall(SYS_io_setup, nr, ctx);
}
static int sys_io_destroy(aio_context_t ctx) {
    return (int)syscall(SYS_io_destroy, ctx);
}
static int sys_io_submit(aio_context_t ctx, long nr, struct iocb **iocbpp) {
    return (int)syscall(SYS_io_submit, ctx, nr, iocbpp);
}
static int sys_io_getevents(aio_context_t ctx, long min_nr, long max_nr, struct io_event *events, struct timespec *timeout) {
    return (int)syscall(SYS_io_getevents, ctx, min_nr, max_nr, events, timeout);
}

static void run_psync_worker(worker_arg_t *w) {
    void *buf = NULL;
    if (posix_memalign(&buf, 4096, w->block_size) != 0) {
        w->err = errno;
        return;
    }
    memset(buf, 0xA5, w->block_size);
    uint64_t rng = w->seed ? w->seed : 0x9e3779b97f4a7c15ULL;
    double t_end = now_sec() + w->duration_sec;

    while (now_sec() < t_end) {
        uint64_t r = xorshift64(&rng);
        off_t off = (off_t)((r % w->num_blocks) * w->block_size);
        if (r & 1ULL) {
            ssize_t n = pread(w->fd, buf, w->block_size, off);
            if (n > 0) {
                w->read_bytes += (uint64_t)n;
                w->read_ops++;
            }
        } else {
            ssize_t n = pwrite(w->fd, buf, w->block_size, off);
            if (n > 0) {
                w->write_bytes += (uint64_t)n;
                w->write_ops++;
            }
        }
    }
    free(buf);
}

static void prep_iocb(struct iocb *cb, int fd, void *buf, size_t bs, off_t off, int is_read, uint64_t slot) {
    memset(cb, 0, sizeof(*cb));
    cb->aio_fildes = (uint32_t)fd;
    cb->aio_lio_opcode = is_read ? IOCB_CMD_PREAD : IOCB_CMD_PWRITE;
    cb->aio_buf = (uint64_t)(uintptr_t)buf;
    cb->aio_nbytes = (uint64_t)bs;
    cb->aio_offset = (int64_t)off;
    cb->aio_data = slot;
}

static void *worker_fn(void *arg) {
    worker_arg_t *w = (worker_arg_t *)arg;
    aio_context_t ctx = 0;
    int depth = w->iodepth > 0 ? w->iodepth : DEFAULT_IODEPTH;

    if (!w->use_aio || sys_io_setup((unsigned)depth, &ctx) < 0) {
        w->use_aio = 0;
        run_psync_worker(w);
        return NULL;
    }

    struct iocb *cbs = calloc((size_t)depth, sizeof(struct iocb));
    struct iocb **ptrs = calloc((size_t)depth, sizeof(struct iocb *));
    struct io_event *events = calloc((size_t)depth, sizeof(struct io_event));
    void **bufs = calloc((size_t)depth, sizeof(void *));
    uint8_t *is_read_slot = calloc((size_t)depth, 1);

    for (int i = 0; i < depth; i++) {
        if (posix_memalign(&bufs[i], 4096, w->block_size) != 0) {
            w->err = errno;
            depth = i;
            break;
        }
        memset(bufs[i], 0xA5, w->block_size);
    }

    if (depth <= 0) {
        sys_io_destroy(ctx);
        free(cbs); free(ptrs); free(events); free(bufs); free(is_read_slot);
        return NULL;
    }

    uint64_t rng = w->seed ? w->seed : 0x9e3779b97f4a7c15ULL;
    double t_end = now_sec() + w->duration_sec;
    int inflight = 0;

    for (int i = 0; i < depth; i++) {
        uint64_t r = xorshift64(&rng);
        off_t off = (off_t)((r % w->num_blocks) * w->block_size);
        int rd = (int)(r & 1ULL);
        is_read_slot[i] = (uint8_t)rd;
        prep_iocb(&cbs[i], w->fd, bufs[i], w->block_size, off, rd, (uint64_t)i);
        ptrs[i] = &cbs[i];
    }

    int submitted = sys_io_submit(ctx, depth, ptrs);
    if (submitted > 0) inflight = submitted;

    struct timespec ts = { .tv_sec = 0, .tv_nsec = 50000000L };
    while (inflight > 0) {
        int n = sys_io_getevents(ctx, 1, inflight, events, &ts);
        if (n < 0) {
            if (errno == EINTR) continue;
            break;
        }
        double now = now_sec();
        int to_submit = 0;
        for (int i = 0; i < n; i++) {
            int slot = (int)events[i].data;
            int64_t res = events[i].res;
            if (res > 0) {
                if (is_read_slot[slot]) {
                    w->read_bytes += (uint64_t)res;
                    w->read_ops++;
                } else {
                    w->write_bytes += (uint64_t)res;
                    w->write_ops++;
                }
            }
            inflight--;
            if (now < t_end) {
                uint64_t r = xorshift64(&rng);
                off_t off = (off_t)((r % w->num_blocks) * w->block_size);
                int rd = (int)(r & 1ULL);
                is_read_slot[slot] = (uint8_t)rd;
                prep_iocb(&cbs[slot], w->fd, bufs[slot], w->block_size, off, rd, (uint64_t)slot);
                ptrs[to_submit++] = &cbs[slot];
            }
        }
        if (to_submit > 0) {
            int s = sys_io_submit(ctx, to_submit, ptrs);
            if (s > 0) inflight += s;
        }
    }

    sys_io_destroy(ctx);
    for (int i = 0; i < depth; i++) free(bufs[i]);
    free(cbs); free(ptrs); free(events); free(bufs); free(is_read_slot);
    return NULL;
}

static int open_bench_file(const char *path, size_t file_size, int *used_direct) {
    *used_direct = 1;
    int fd = open(path, O_RDWR | O_CREAT | O_DIRECT, 0644);
    if (fd < 0 && (errno == EINVAL || errno == EOPNOTSUPP)) {
        *used_direct = 0;
        fd = open(path, O_RDWR | O_CREAT | O_SYNC, 0644);
    }
    if (fd < 0) return -1;

    off_t cur = lseek(fd, 0, SEEK_END);
    if (cur < (off_t)file_size) {
        size_t chunk = 1024 * 1024;
        void *zbuf = NULL;
        if (posix_memalign(&zbuf, 4096, chunk) == 0) {
            memset(zbuf, 0x5A, chunk);
            off_t pos = cur > 0 ? (cur & ~4095LL) : 0;
            while (pos < (off_t)file_size) {
                size_t to_write = chunk;
                if ((off_t)file_size - pos < (off_t)chunk) {
                    to_write = (size_t)((off_t)file_size - pos);
                    to_write = (to_write + 4095) & ~4095UL;
                }
                ssize_t n = pwrite(fd, zbuf, to_write, pos);
                if (n <= 0) break;
                pos += n;
            }
            free(zbuf);
        }
    }
    return fd;
}

typedef struct {
    napi_async_work work;
    napi_deferred deferred;
    char path[1024];
    int64_t bs;
    int64_t fs;
    double dur;
    int32_t threads;
    int32_t iodepth;
    int used_direct;
    int used_aio;
    double elapsed;
    uint64_t r_bytes;
    uint64_t w_bytes;
    uint64_t r_ops;
    uint64_t w_ops;
    int err;
    char err_msg[256];
} async_bench_t;

static void execute_bench(napi_env env, void *data) {
    (void)env;
    async_bench_t *ab = (async_bench_t *)data;
    int fd = open_bench_file(ab->path, (size_t)ab->fs, &ab->used_direct);
    if (fd < 0) {
        ab->err = errno;
        snprintf(ab->err_msg, sizeof(ab->err_msg), "%s", strerror(errno));
        return;
    }

    size_t num_blocks = (size_t)ab->fs / (size_t)ab->bs;
    worker_arg_t *wargs = calloc((size_t)ab->threads, sizeof(worker_arg_t));
    pthread_t *tids = calloc((size_t)ab->threads, sizeof(pthread_t));

    double t0 = now_sec();
    for (int i = 0; i < ab->threads; i++) {
        wargs[i].fd = fd;
        wargs[i].block_size = (size_t)ab->bs;
        wargs[i].num_blocks = num_blocks;
        wargs[i].duration_sec = ab->dur;
        wargs[i].iodepth = ab->iodepth;
        wargs[i].use_aio = 1;
        wargs[i].seed = 0x123456789abcdef0ULL ^ ((uint64_t)(i + 1) * 0x9e3779b97f4a7c15ULL) ^ (uint64_t)time(NULL);
        pthread_create(&tids[i], NULL, worker_fn, &wargs[i]);
    }

    ab->used_aio = 1;
    for (int i = 0; i < ab->threads; i++) {
        pthread_join(tids[i], NULL);
        ab->r_bytes += wargs[i].read_bytes;
        ab->w_bytes += wargs[i].write_bytes;
        ab->r_ops += wargs[i].read_ops;
        ab->w_ops += wargs[i].write_ops;
        if (!wargs[i].use_aio) ab->used_aio = 0;
    }
    ab->elapsed = now_sec() - t0;
    if (ab->elapsed <= 0.001) ab->elapsed = ab->dur;

    close(fd);
    free(wargs);
    free(tids);
}

static void complete_bench(napi_env env, napi_status status, void *data) {
    (void)status;
    async_bench_t *ab = (async_bench_t *)data;
    if (ab->err != 0) {
        napi_value msg, err;
        napi_create_string_utf8(env, ab->err_msg, NAPI_AUTO_LENGTH, &msg);
        napi_create_error(env, NULL, msg, &err);
        napi_reject_deferred(env, ab->deferred, err);
    } else {
        napi_value res, v;
        napi_create_object(env, &res);

        double r_mbps = ((double)ab->r_bytes / (1024.0 * 1024.0)) / ab->elapsed;
        double w_mbps = ((double)ab->w_bytes / (1024.0 * 1024.0)) / ab->elapsed;
        double t_mbps = r_mbps + w_mbps;
        double r_iops = (double)ab->r_ops / ab->elapsed;
        double w_iops = (double)ab->w_ops / ab->elapsed;
        double t_iops = r_iops + w_iops;

        napi_create_double(env, r_mbps, &v); napi_set_named_property(env, res, "read_mbps", v);
        napi_create_double(env, w_mbps, &v); napi_set_named_property(env, res, "write_mbps", v);
        napi_create_double(env, t_mbps, &v); napi_set_named_property(env, res, "total_mbps", v);
        napi_create_double(env, r_iops, &v); napi_set_named_property(env, res, "read_iops", v);
        napi_create_double(env, w_iops, &v); napi_set_named_property(env, res, "write_iops", v);
        napi_create_double(env, t_iops, &v); napi_set_named_property(env, res, "total_iops", v);
        napi_get_boolean(env, ab->used_direct != 0, &v); napi_set_named_property(env, res, "direct", v);
        napi_create_string_utf8(env, ab->used_aio ? "libaio" : "psync", NAPI_AUTO_LENGTH, &v);
        napi_set_named_property(env, res, "ioengine", v);
        napi_create_int32(env, ab->used_aio ? ab->iodepth : 1, &v);
        napi_set_named_property(env, res, "iodepth", v);
        napi_create_double(env, ab->elapsed, &v); napi_set_named_property(env, res, "elapsed_sec", v);

        napi_resolve_deferred(env, ab->deferred, res);
    }
    napi_delete_async_work(env, ab->work);
    free(ab);
}

static napi_value bench_block(napi_env env, napi_callback_info info) {
    size_t argc = 6;
    napi_value args[6];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (argc < 5) {
        napi_throw_error(env, NULL, "Expected (path, blockSize, fileSize, durationSec, threads[, iodepth])");
        return NULL;
    }

    async_bench_t *ab = calloc(1, sizeof(async_bench_t));
    size_t path_len = 0;
    napi_get_value_string_utf8(env, args[0], ab->path, sizeof(ab->path), &path_len);

    ab->bs = 4096;
    ab->fs = 128 * 1024 * 1024;
    ab->dur = 2.0;
    ab->threads = 2;
    ab->iodepth = DEFAULT_IODEPTH;
    napi_get_value_int64(env, args[1], &ab->bs);
    napi_get_value_int64(env, args[2], &ab->fs);
    napi_get_value_double(env, args[3], &ab->dur);
    napi_get_value_int32(env, args[4], &ab->threads);
    if (argc >= 6) napi_get_value_int32(env, args[5], &ab->iodepth);

    if (ab->bs < 4096) ab->bs = 4096;
    if (ab->fs < ab->bs * 16) ab->fs = ab->bs * 16;
    if (ab->dur < 0.5) ab->dur = 0.5;
    if (ab->threads < 1) ab->threads = 1;
    if (ab->threads > 8) ab->threads = 8;
    if (ab->iodepth < 1) ab->iodepth = 1;
    if (ab->iodepth > 128) ab->iodepth = 128;

    napi_value promise, work_name;
    napi_create_promise(env, &ab->deferred, &promise);
    napi_create_string_utf8(env, "YabsDiskBench", NAPI_AUTO_LENGTH, &work_name);
    napi_create_async_work(env, NULL, work_name, execute_bench, complete_bench, ab, &ab->work);
    napi_queue_async_work(env, ab->work);
    return promise;
}

static napi_value init(napi_env env, napi_value exports) {
    napi_value fn;
    napi_create_function(env, NULL, 0, bench_block, NULL, &fn);
    napi_set_named_property(env, exports, "benchBlock", fn);
    return exports;
}

NAPI_MODULE(NODE_GYP_MODULE_NAME, init)
