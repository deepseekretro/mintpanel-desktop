#define _GNU_SOURCE
#include <node_api.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char *(*fn_start_t)(const char *);
typedef char *(*fn_stop_t)(void);
typedef char *(*fn_status_t)(void);
typedef char *(*fn_action_t)(const char *, const char *);
typedef void (*fn_free_t)(char *);

static void *g_handle = NULL;
static fn_start_t g_start = NULL;
static fn_start_t g_start_json = NULL;
static fn_stop_t g_stop = NULL;
static fn_status_t g_status = NULL;
static fn_action_t g_action = NULL;
static fn_free_t g_free = NULL;

static int ensure_loaded(const char *so_path, char *errbuf, size_t errlen) {
    if (g_handle) return 0;
    g_handle = dlopen(so_path, RTLD_NOW | RTLD_GLOBAL);
    if (!g_handle) {
        snprintf(errbuf, errlen, "dlopen failed: %s", dlerror());
        return -1;
    }
    g_start = (fn_start_t)dlsym(g_handle, "FFVpnStart");
    g_start_json = (fn_start_t)dlsym(g_handle, "FFVpnStartJSON");
    g_stop = (fn_stop_t)dlsym(g_handle, "FFVpnStop");
    g_status = (fn_status_t)dlsym(g_handle, "FFVpnStatusJSON");
    g_action = (fn_action_t)dlsym(g_handle, "FFVpnActionJSON");
    g_free = (fn_free_t)dlsym(g_handle, "FFVpnFreeStr");
    if (!g_start || !g_start_json || !g_stop || !g_status || !g_action || !g_free) {
        snprintf(errbuf, errlen, "missing symbols in libfirefoxvpn.so");
        return -1;
    }
    return 0;
}

static char *get_utf8_alloc(napi_env env, napi_value val) {
    size_t len = 0;
    napi_get_value_string_utf8(env, val, NULL, 0, &len);
    char *buf = (char *)malloc(len + 1);
    if (!buf) return NULL;
    napi_get_value_string_utf8(env, val, buf, len + 1, &len);
    return buf;
}

static napi_value ff_start(napi_env env, napi_callback_info info) {
    size_t argc = 2;
    napi_value args[2];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (argc < 2) {
        napi_throw_error(env, NULL, "Expected (soPath, configPath)");
        return NULL;
    }
    char *so_path = get_utf8_alloc(env, args[0]);
    char *cfg_path = get_utf8_alloc(env, args[1]);
    char err[512];
    if (ensure_loaded(so_path, err, sizeof(err)) != 0) {
        free(so_path); free(cfg_path);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    char *msg = g_start(cfg_path);
    free(so_path); free(cfg_path);
    if (msg != NULL) {
        snprintf(err, sizeof(err), "%s", msg);
        g_free(msg);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    napi_value ok;
    napi_get_boolean(env, true, &ok);
    return ok;
}

static napi_value ff_start_json(napi_env env, napi_callback_info info) {
    size_t argc = 2;
    napi_value args[2];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (argc < 2) {
        napi_throw_error(env, NULL, "Expected (soPath, jsonContent)");
        return NULL;
    }
    char *so_path = get_utf8_alloc(env, args[0]);
    char *json_str = get_utf8_alloc(env, args[1]);
    char err[512];
    if (ensure_loaded(so_path, err, sizeof(err)) != 0) {
        free(so_path); free(json_str);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    char *msg = g_start_json(json_str);
    free(so_path); free(json_str);
    if (msg != NULL) {
        snprintf(err, sizeof(err), "%s", msg);
        g_free(msg);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    napi_value ok;
    napi_get_boolean(env, true, &ok);
    return ok;
}

static napi_value ff_stop(napi_env env, napi_callback_info info) {
    (void)info;
    if (!g_handle) {
        napi_value ok;
        napi_get_boolean(env, true, &ok);
        return ok;
    }
    char *msg = g_stop();
    if (msg != NULL) {
        char err[512];
        snprintf(err, sizeof(err), "%s", msg);
        g_free(msg);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    napi_value ok;
    napi_get_boolean(env, true, &ok);
    return ok;
}

static napi_value ff_status(napi_env env, napi_callback_info info) {
    size_t argc = 1;
    napi_value args[1];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (!g_handle && argc >= 1) {
        char *so_path = get_utf8_alloc(env, args[0]);
        char err[512];
        int rc = ensure_loaded(so_path, err, sizeof(err));
        free(so_path);
        if (rc != 0) {
            napi_throw_error(env, NULL, err);
            return NULL;
        }
    }
    if (!g_handle) {
        napi_value s;
        napi_create_string_utf8(env, "{\"running\":false,\"error\":\"\"}", NAPI_AUTO_LENGTH, &s);
        return s;
    }
    char *json = g_status();
    napi_value s;
    napi_create_string_utf8(env, json ? json : "{}", NAPI_AUTO_LENGTH, &s);
    if (json) g_free(json);
    return s;
}

static napi_value ff_action(napi_env env, napi_callback_info info) {
    size_t argc = 3;
    napi_value args[3];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (argc < 2) {
        napi_throw_error(env, NULL, "Expected (soPath, action, [payloadJSON])");
        return NULL;
    }
    char *so_path = get_utf8_alloc(env, args[0]);
    char *act = get_utf8_alloc(env, args[1]);
    char *payload = argc >= 3 ? get_utf8_alloc(env, args[2]) : strdup("{}");
    char err[512];
    if (ensure_loaded(so_path, err, sizeof(err)) != 0) {
        free(so_path); free(act); free(payload);
        napi_throw_error(env, NULL, err);
        return NULL;
    }
    char *json = g_action(act, payload);
    free(so_path); free(act); free(payload);
    napi_value s;
    napi_create_string_utf8(env, json ? json : "{}", NAPI_AUTO_LENGTH, &s);
    if (json) g_free(json);
    return s;
}

static napi_value init(napi_env env, napi_value exports) {
    napi_value fn1, fn2, fn3, fn4, fn5;
    napi_create_function(env, NULL, 0, ff_start, NULL, &fn1);
    napi_create_function(env, NULL, 0, ff_start_json, NULL, &fn2);
    napi_create_function(env, NULL, 0, ff_stop, NULL, &fn3);
    napi_create_function(env, NULL, 0, ff_status, NULL, &fn4);
    napi_create_function(env, NULL, 0, ff_action, NULL, &fn5);
    napi_set_named_property(env, exports, "start", fn1);
    napi_set_named_property(env, exports, "startJSON", fn2);
    napi_set_named_property(env, exports, "stop", fn3);
    napi_set_named_property(env, exports, "status", fn4);
    napi_set_named_property(env, exports, "action", fn5);
    return exports;
}

NAPI_MODULE(NODE_GYP_MODULE_NAME, init)
