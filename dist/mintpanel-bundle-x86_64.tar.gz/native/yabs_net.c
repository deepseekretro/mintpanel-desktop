#include <node_api.h>
#include <iperf_api.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static pthread_mutex_t g_iperf_mu = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
    napi_async_work work;
    napi_deferred deferred;
    char host[256];
    int port;
    int dur;
    int parallel;
    int reverse;
    char *json_out;
    int err;
    char err_msg[256];
} async_iperf_t;

static void execute_iperf(napi_env env, void *data) {
    (void)env;
    async_iperf_t *ai = (async_iperf_t *)data;
    pthread_mutex_lock(&g_iperf_mu);

    struct iperf_test *test = iperf_new_test();
    if (!test) {
        ai->err = 1;
        snprintf(ai->err_msg, sizeof(ai->err_msg), "iperf_new_test failed");
        pthread_mutex_unlock(&g_iperf_mu);
        return;
    }

    iperf_defaults(test);
    iperf_set_verbose(test, 0);
    iperf_set_test_role(test, 'c');
    iperf_set_test_server_hostname(test, ai->host);
    iperf_set_test_server_port(test, ai->port);
    iperf_set_test_duration(test, ai->dur);
    iperf_set_test_num_streams(test, ai->parallel);
    iperf_set_test_reverse(test, ai->reverse ? 1 : 0);
    iperf_set_test_json_output(test, 1);
    iperf_set_test_connect_timeout(test, 5000);

    int rc = iperf_run_client(test);
    char *jstr = iperf_get_test_json_output_string(test);
    if (jstr) {
        ai->json_out = strdup(jstr);
    }
    if (rc < 0 && !ai->json_out) {
        ai->err = 1;
        snprintf(ai->err_msg, sizeof(ai->err_msg), "%s", iperf_strerror(i_errno));
    }

    iperf_free_test(test);
    pthread_mutex_unlock(&g_iperf_mu);
}

static void complete_iperf(napi_env env, napi_status status, void *data) {
    (void)status;
    async_iperf_t *ai = (async_iperf_t *)data;
    if (ai->err != 0 || !ai->json_out) {
        napi_value msg, err;
        napi_create_string_utf8(env, ai->err_msg[0] ? ai->err_msg : "iperf_run_client failed", NAPI_AUTO_LENGTH, &msg);
        napi_create_error(env, NULL, msg, &err);
        napi_reject_deferred(env, ai->deferred, err);
    } else {
        napi_value jval;
        napi_create_string_utf8(env, ai->json_out, NAPI_AUTO_LENGTH, &jval);
        napi_resolve_deferred(env, ai->deferred, jval);
    }
    if (ai->json_out) free(ai->json_out);
    napi_delete_async_work(env, ai->work);
    free(ai);
}

static napi_value run_client_json(napi_env env, napi_callback_info info) {
    size_t argc = 5;
    napi_value args[5];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    if (argc < 5) {
        napi_throw_error(env, NULL, "Expected (host, port, durationSec, parallel, reverse)");
        return NULL;
    }
    async_iperf_t *ai = calloc(1, sizeof(async_iperf_t));
    size_t hlen = 0;
    napi_get_value_string_utf8(env, args[0], ai->host, sizeof(ai->host), &hlen);
    bool rev = false;
    napi_get_value_int32(env, args[1], &ai->port);
    napi_get_value_int32(env, args[2], &ai->dur);
    napi_get_value_int32(env, args[3], &ai->parallel);
    napi_get_value_bool(env, args[4], &rev);
    ai->reverse = rev ? 1 : 0;

    if (ai->dur < 1) ai->dur = 1;
    if (ai->dur > 15) ai->dur = 15;
    if (ai->parallel < 1) ai->parallel = 1;
    if (ai->parallel > 16) ai->parallel = 16;

    napi_value promise, work_name;
    napi_create_promise(env, &ai->deferred, &promise);
    napi_create_string_utf8(env, "LibIperfClient", NAPI_AUTO_LENGTH, &work_name);
    napi_create_async_work(env, NULL, work_name, execute_iperf, complete_iperf, ai, &ai->work);
    napi_queue_async_work(env, ai->work);
    return promise;
}

static napi_value init(napi_env env, napi_value exports) {
    napi_value fn;
    napi_create_function(env, NULL, 0, run_client_json, NULL, &fn);
    napi_set_named_property(env, exports, "runClientJson", fn);
    return exports;
}

NAPI_MODULE(NODE_GYP_MODULE_NAME, init)
