#define _GNU_SOURCE
#include <node_api.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX_PRIME 20000

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

typedef struct {
    double dur_sec;
    uint64_t events;
} cpu_worker_t;

/* Standard sysbench --cpu-max-prime=20000 compatible benchmark */
static void *cpu_worker_fn(void *arg) {
    cpu_worker_t *w = (cpu_worker_t *)arg;
    double t_end = now_sec() + w->dur_sec;
    uint64_t events = 0;

    while (now_sec() < t_end) {
        volatile uint64_t primes = 0;
        for (int c = 3; c <= MAX_PRIME; c++) {
            int l = (int)sqrt((double)c);
            int is_p = 1;
            for (int t = 2; t <= l; t++) {
                if (c % t == 0) {
                    is_p = 0;
                    break;
                }
            }
            if (is_p) primes++;
        }
        (void)primes;
        events++;
    }
    w->events = events;
    return NULL;
}

static double run_threads_eps(int n, double dur) {
    cpu_worker_t *ws = calloc((size_t)n, sizeof(cpu_worker_t));
    pthread_t *tids = calloc((size_t)n, sizeof(pthread_t));
    double t0 = now_sec();
    for (int i = 0; i < n; i++) {
        ws[i].dur_sec = dur;
        pthread_create(&tids[i], NULL, cpu_worker_fn, &ws[i]);
    }
    uint64_t total = 0;
    for (int i = 0; i < n; i++) {
        pthread_join(tids[i], NULL);
        total += ws[i].events;
    }
    double el = now_sec() - t0;
    free(ws);
    free(tids);
    return el > 0 ? ((double)total / el) : 0.0;
}

typedef struct {
    napi_async_work work;
    napi_deferred deferred;
    int workers;
    double dur;
    double single_eps;
    double multi_eps;
} async_cpu_t;

static void execute_cpu(napi_env env, void *data) {
    (void)env;
    async_cpu_t *ac = (async_cpu_t *)data;
    ac->single_eps = run_threads_eps(1, ac->dur);
    ac->multi_eps = run_threads_eps(ac->workers, ac->dur);
}

static void complete_cpu(napi_env env, napi_status status, void *data) {
    (void)status;
    async_cpu_t *ac = (async_cpu_t *)data;
    napi_value res, v;
    napi_create_object(env, &res);
    double ratio = ac->single_eps > 0 ? (ac->multi_eps / ac->single_eps) : 1.0;
    napi_create_int32(env, ac->workers, &v); napi_set_named_property(env, res, "workers", v);
    napi_create_double(env, ac->single_eps, &v); napi_set_named_property(env, res, "single_score", v);
    napi_create_double(env, ac->multi_eps, &v); napi_set_named_property(env, res, "multi_score", v);
    napi_create_double(env, ratio, &v); napi_set_named_property(env, res, "ratio", v);
    napi_resolve_deferred(env, ac->deferred, res);
    napi_delete_async_work(env, ac->work);
    free(ac);
}

static napi_value bench_cpu(napi_env env, napi_callback_info info) {
    size_t argc = 2;
    napi_value args[2];
    napi_get_cb_info(env, info, &argc, args, NULL, NULL);
    async_cpu_t *ac = calloc(1, sizeof(async_cpu_t));
    ac->workers = 2;
    ac->dur = 1.5;
    if (argc >= 1) napi_get_value_int32(env, args[0], &ac->workers);
    if (argc >= 2) napi_get_value_double(env, args[1], &ac->dur);
    if (ac->workers < 1) ac->workers = 1;
    if (ac->workers > 16) ac->workers = 16;
    if (ac->dur < 0.5) ac->dur = 0.5;
    if (ac->dur > 5.0) ac->dur = 5.0;

    napi_value promise, work_name;
    napi_create_promise(env, &ac->deferred, &promise);
    napi_create_string_utf8(env, "SysbenchCpu", NAPI_AUTO_LENGTH, &work_name);
    napi_create_async_work(env, NULL, work_name, execute_cpu, complete_cpu, ac, &ac->work);
    napi_queue_async_work(env, ac->work);
    return promise;
}

static napi_value init(napi_env env, napi_value exports) {
    napi_value fn;
    napi_create_function(env, NULL, 0, bench_cpu, NULL, &fn);
    napi_set_named_property(env, exports, "benchCpu", fn);
    return exports;
}

NAPI_MODULE(NODE_GYP_MODULE_NAME, init)
