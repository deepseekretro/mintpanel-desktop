#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
PARENT="$(dirname "$DIR")"
cd "$DIR"
if [ -f .panel.pid ]; then
  OLD_PID=$(cat .panel.pid || true)
  if [ -n "$OLD_PID" ]; then
    kill "$OLD_PID" 2>/dev/null || true
    sleep 0.6
  fi
fi
export PATH="$PARENT/node/bin:$PARENT/opt/node/bin:$PATH"
export NODE_OPTIONS="--openssl-legacy-provider --experimental-sqlite"
export HOST="${HOST:-127.0.0.1}"
export PORT="${PORT:-8090}"
nohup node ./server.mjs </dev/null >"$DIR/panel.log" 2>&1 &
echo $! > .panel.pid
sleep 1.5
tail -n 10 "$DIR/panel.log"
